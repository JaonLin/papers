/* Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
// Put some of the IDA Pro information into an sqlite3 database.
// Limitations: Much more information about variables, arguments, etc. could
//    be extracted and put in the database.
#include <winsock2.h>

#include <ida.hpp>
#include <idp.hpp>
#include <auto.hpp>
#include <frame.hpp>
#include <struct.hpp>
#include <ua.hpp>
#include <nalt.hpp>
#include <entry.hpp>
#include <bytes.hpp>
#include <loader.hpp>
#include <kernwin.hpp>
#include <typeinf.hpp>
#include <demangle.hpp>
#include <strlist.hpp>
#include <sqlite3.h>
#include <llong.hpp>
#include <cstdlib>
#include <fixup.hpp>

//#include <time.h>
//#include <stdint>
typedef long long int64_t;
typedef unsigned long long uint64_t;


// Missing in windows stdlib...
// ascii to unsigned long long
unsigned long long atoull(char *str){
	long long result = 0;
	while (*str >= '0' && *str <= '9') {
		result = (result*10) - (*str++ - '0');
	}
	return result;
}

// ascii to long long
long long atoll(char *str){
	long long result = 0;
	int negative=0;
	
	while (*str == ' ' || *str == '\t')
		str++;
	if (*str == '+')
		str++;
	else if (*str == '-') {
		negative = 1;
		str++;
	}
	
	while (*str >= '0' && *str <= '9') {
		result = (result*10) - (*str++ - '0');
	}

	return negative ? result : -result;
}


#ifndef __WATCOMC__
#include <vector>
using std::vector;
#endif

#define PLUGIN_VERSION 6

#ifndef DJB_DEBUG
#define DJB_DEBUG 0
#endif

static int djb_debug = DJB_DEBUG;
static int sql_debug = 0;


// Given an address, extractdata from that address up to length bytes.
// E.g., called to get strings in the program.
char *get_bytes_as_string(ea_t ea, int length)
{
  uchar *bytes;
  if(length == 0)
    return NULL;
  bytes = (uchar *) qalloc(length);
  memset(bytes, 0, length);
  if(djb_debug)
	  warning("Getting bytes\n");
  if(get_many_bytes(ea, bytes, length) != 1){
    warning("get_many_bytes failed.\n");
    return NULL;
  }
  int myallocsize = length * 4 + 1;
  char *str = (char *) qalloc(myallocsize);
  str[0] = 0;
  int tsz = 0;
  int sz = 0;
  for(int j = 0; j < length; j++){
	sz = _snprintf_s(str+tsz, myallocsize-tsz-1, _TRUNCATE, "%.2x", bytes[j]);
	tsz += sz;
  }
  if(strlen(str) > 0){
    if(str[strlen(str)-1] == ' ')
      str[strlen(str)-1] = 0;
  }
  qfree(bytes);
  return str;
}

int sql_exec(sqlite3 *db,char *format, ...)
{
  assert(db);
  va_list args;
  va_start(args,format);
  char buf[MAXSTR*8]={0,};
  _vsnprintf_s(buf,sizeof(buf)-1,format,args);
  va_end(args);
  
  if(sql_debug)
    msg("sql_exec: %s\n", buf);
  char *err;
  
  int ret = sqlite3_exec(db, buf, NULL, NULL, &err);
  if(ret != SQLITE_OK)
    {
		warning("sql_exec error: %s\n On query: %s", err, buf);
    }
  return ret;
}

// Initialize our database with the tables we need.
// If you update the table defintions here, you will need to
// update the corresponding insert statements later on.
// In addition, if you add a table you will need to go into
// generate_info_entry and add an appropriate delete statement.
//
sqlite3 *init_db()
{
  char *filepath;
  char *err;
  // XXX: Do I have to free filepath? 
  // A quick look at IDA SDK 5 doesn't seem to indicate.
  filepath = askfile_c(1, "*.db", 
		       "Where would you like to save the "
		       "SQLite3 database output file?");
  if(filepath == NULL){
    return NULL;
  }

  sqlite3 *db=NULL;
  int rc=sqlite3_open(filepath,&db);
  if(rc != SQLITE_OK){
    msg("init_db error: %s\n", sqlite3_errmsg(db));
    return NULL;
  }
  sql_exec(db, "BEGIN");
  // Don't worry if we are creating table entries that already exist.
  sqlite3_exec(db,"CREATE TABLE IF NOT EXISTS info (\n"
	       "file_id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "fullname TEXT,\n"
	       "filename TEXT,\n"
	       "filetype TEXT,\n"
		   "img_base INTEGER, \n"
	       "start_ip INTEGER,\n"
	       "start_sp INTEGER,\n"
		   "instruction_size INTEGER,\n"
		   "md5sum TEXT UNIQUE,\n"
		   "generating_host TEXT,\n"
	       "generated_on TEXT,\n"
	       "plugin_version INTEGER\n"
	       ");", NULL, NULL, &err);


  sqlite3_exec(db,"CREATE TABLE IF NOT EXISTS instrs (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "file_id INTEGER NOT NULL,\n"
	       "address INTEGER NOT NULL,\n"
	       "length INTEGER NOT NULL,\n"
	       "bytes TEXT NOT NULL\n"
		   ");", NULL, NULL, &err);

  sqlite3_exec(db,"CREATE TABLE IF NOT EXISTS functions (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "file_id INTEGER NOT NULL REFERENCES info(file_id),\n"
	       "name TEXT,\n"
		   "typedecl TEXT,\n"
	       "flags INTEGER,\n"
	       "start_address INTEGER NOT NULL,\n"
	       "end_address INTEGER NOT NULL,\n"
	       "UNIQUE (file_id, start_address)\n"
	       ");", NULL, NULL, &err);

  sqlite3_exec(db,"CREATE TABLE IF NOT EXISTS ftails (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "function_id INTEGER references functions(id) NOT NULL,\n"
	       "start_address INTEGER NOT NULL,\n"
	       "end_address INTEGER NOT NULL\n"
	       ");", NULL, NULL, &err);


  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS exports (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "file_id INTEGER REFERENCES info(file_id) NOT NULL,\n"
	       "name TEXT,\n"
		   "ordinal INTEGER,\n"
	       "address INTEGER NOT NULL\n"
	       ");", NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS strings (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "file_id INTEGER REFERENCES info(file_id) NOT NULL,\n"
	       "address INTEGER NOT NULL,\n"
	       "typ INTEGER,\n"
	       "length INTEGER NOT NULL,\n"
	       "bytes TEXT NOT NULL\n"
	       ");", NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS vars (\n"
	       "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
	       "file_id INTEGER REFERENCES info(file_id),\n"
	       "function_address INTEGER,\n"
	       "name TEXT,\n"
	       "start_offset INTEGER NOT NULL,\n"
	       "end_offset INTEGER NOT NULL\n"
	       ");", NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS imports (\n"
         "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
         "file_id INTEGER REFERENCES info(file_id),\n"
         "name TEXT,\n"
         "address INTEGER);", NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS segments (\n"
		  "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
		  "file_id INTEGER REFERENCES info(file_id),\n"
		  "name TEXT NOT NULL,\n"
		  "number INTEGER NOT NULL,\n"
		  "start_address INTEGER NOT NULL,\n"
		  "end_address INTEGER NOT NULL,\n"
		  "type INTEGER NOT NULL,\n"
		  "perm INTEGER NOT NULL);",
		  NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS fixup_hack (\n"
		  "file_id INTEGER REFERENCES info(file_id),\n"
		  "address INTEGER NOT NULL,\n"
	          "value INTEGER);",
		  NULL, NULL, &err);

  sqlite3_exec(db, "CREATE TABLE IF NOT EXISTS operands (\n"
		  "id INTEGER PRIMARY KEY AUTOINCREMENT,\n"
		  "file_id INTEGER REFERENCES info(file_id),\n"
		  "insn_addr INTEGER NOT NULL, \n"
		  "offset INTEGER NOT NULL, \n"
		  "type INTEGER,\n"
		  "value INTEGER,\n"
		  "address INTEGER,\n"
		  "is_used INTEGER,\n"
		  "is_modified INTEGER);",
		  NULL, NULL, &err);

  return db;
}

void close_db(sqlite3 *db)
{
  if(db == NULL) return;
  sql_exec(db, "END");
  sqlite3_close(db);
}

// Our callback for querying if a file has already been
// processed. ugh. using a callback is easiest, though.
static int cb_file_id = -1;
static int query_file_id_cb(void *unused, int argc, 
			    char **argv, char **colname)
{
  int i;
  for(i=0; i<argc; i++){
    if(strcmp(colname[i], "file_id")==0){
      if(argv[i] == NULL){
	return -1;
      }
      cb_file_id = atoi(argv[i]);
    }
  }
  return 0;
}


// Get the file id for a given md5sum. Returns -1 if the database
// doesn't have an entry with md5 hash md5sum.
int query_file_id(sqlite3 *db, char md5sum[]){
  char buf[MAXSTR*3];
  char *err;
  cb_file_id = -1;
  
  buf[0] = 0;
  _snprintf_s(buf, sizeof(buf)-1, 
	      "SELECT file_id from info where md5sum=\"%s\";", 
	      md5sum);
  int ret = sqlite3_exec(db,buf,query_file_id_cb,NULL,&err);
  if(ret != SQLITE_OK){
    warning("sql_exec error: %s\nOn query: %s\n", err, buf);
    return -1;
  }
  return cb_file_id;
}

// Our callback for querying a function id
static int query_function_id_cb(void *function_id, int argc, 
			    char **argv, char **colname)
{
  assert(strcmp(colname[0], "id")==0);
  assert(argv[0]);

  *(long long*)function_id = atoll(argv[0]);
  return 0;
}


// Get the function id for a given file_id and start_address
static int64_t query_function_id(sqlite3 *db, int file_id, uint64_t start_address){
  long long cb_function_id = -1;
  char buf[MAXSTR*3];
  char *err;
  
  buf[0] = 0;
  _snprintf_s(buf, sizeof(buf)-1, 
	      "SELECT id from functions "
	      "where file_id = %d and start_address = %lld;", 
	      file_id, (unsigned long long)start_address);
  int ret = sqlite3_exec(db,buf,query_function_id_cb,&cb_function_id,&err);
  if(ret != SQLITE_OK){
    warning("sql_exec error: %s\nOn query: %s\n", err, buf);
    return -1;
  }
  return (int64_t)cb_function_id;
}

// Returns file id for file we are analyzing
// Generates basic information in the info column.
// also, if file has already been seen, deletes
// any old information so we can repopulate.
// in the future, it would be nicer to ask a user what they
// want to do if the md5sum is already in the database.
int generate_info_entry(sqlite3 *db)
{
  char *filetype;
  char fullname[MAXSTR];
  char filename[MAXSTR];
  uchar md5sum[16];
  char md5sum_str[64];
  char elf[] = "elf";
  char pe[] = "pe";
  char type_bin[] = "bin";
  char type_unknown[] = "unknown";
  char *err;
  char hostname[MAXSTR];
  
  fullname[0] =0;
  filename[0] = 0;
  md5sum[0] = 0;
  md5sum_str[0]=0;
  hostname[0] = 0;

  if(inf.filetype == f_ELF){
    filetype = elf;
  } else if (inf.filetype == f_BIN) {
    filetype = type_bin;
  } else if (inf.filetype == f_PE) {
    filetype = pe;
  } else {
    filetype = type_unknown;
  }

  get_input_file_path(fullname, MAXSTR);
  get_root_filename(filename, MAXSTR);
  retrieve_input_file_md5(md5sum);
  char tmp[16];
  md5sum_str[0] = 0;
  for(int i = 0; i < 16; i++){
	  tmp[0] = 0;
    qsnprintf(tmp, sizeof(tmp)-1, "%.2x ", md5sum[i]);
    qstrncat(md5sum_str, tmp, sizeof(md5sum_str));
  }
  if(md5sum_str[strlen(md5sum_str)-1] == ' ')
    md5sum_str[strlen(md5sum_str)-1] = 0;


  int instsize = 32; //assume 32 bit.
  if(inf.is_64bit()) instsize = 64;

  hostname[0] = 0;

  if(::gethostname(hostname, sizeof(hostname) - 1)){
	  warning("gethostname failed. hostname will not be recorded");
  }

  ea_t img_base = get_fileregion_ea(0); // get EA of input file's offset 0

  char insert_buf[MAXSTR*4];
  _snprintf_s(insert_buf, sizeof(insert_buf)-1, 
	      "INSERT INTO info \n"
	      "(fullname, filename,filetype, img_base, start_ip, start_sp, md5sum, "
	      " generated_on,plugin_version,instruction_size, generating_host) \n"
	      " values (\"%s\",\"%s\",\"%s\",%lld, %lld, %lld, \"%s\","
	      " DATETIME('NOW'), %d, %d, \"%s\");",
	      fullname,
	      filename,
	      filetype,
		  (unsigned long long)img_base, 
	      (unsigned long long)inf.startIP,
	      (unsigned long long)inf.startSP,
	      md5sum_str,
	      PLUGIN_VERSION,
		  instsize, 
		  hostname
	      );
  
  if (img_base == BADADDR) {
	warning("Cannot find image base address.\n "
		    "To fix this, get the HEADER segment by loading the image manually.\n");
  } else {
	msg("Found image base address at 0x%llx\n", (unsigned long long) img_base);
  }

  int ret = sqlite3_exec(db, insert_buf, NULL, NULL, &err);
  int current_file_id;
  switch(ret){
  case SQLITE_OK: return query_file_id(db, md5sum_str); break;
  case SQLITE_CONSTRAINT: 
    // Entry already exists.
    // For now, we warn the user and will replace the information
    // This could be more complex.
    msg("Entry with md5sum %s already exists. Replacing...\n", md5sum_str);
    current_file_id = query_file_id(db, md5sum_str);
    sql_exec(db, "DELETE FROM info where md5sum = \"%s\";", md5sum_str);
    sql_exec(db, "DELETE FROM functions where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM instrs where file_id =%d;", current_file_id);
    sql_exec(db, "DELETE FROM exports where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM strings where file_id = %d;", current_file_id);
    sql_exec(db, "DELETE FROM vars where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM imports where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM segments where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM fixup_hack where file_id=%d;", current_file_id);
    sql_exec(db, "DELETE FROM operands where file_id=%d;", current_file_id);

	sqlite3_exec(db, insert_buf, NULL, NULL, &err);
    return query_file_id(db, md5sum_str);
    break;
  default: msg("sql error: %d. Skipping file.\n", ret); return -1; break;
  }
}

void populate_instr_table(sqlite3 *db, int file_id)
{
  if(djb_debug)
    msg("populate_instr_table\n");
  for(int s = 0; s < get_segm_qty(); s++){
    segment_t *seg = getnseg(s);

	char segbuf[MAXSTR];
	segbuf[0] = 0;
	get_segm_name(seg, segbuf, sizeof(segbuf));
	sql_exec(db, "INSERT INTO segments \n"
		" (file_id, name, number, start_address, end_address, type, perm) \n"
		" values (%d, \"%s\", %d, %llu, %llu, %hhu, %hhu);",
	    file_id, segbuf, seg->sel,
		(unsigned long long) seg->startEA, 
		(unsigned long long) seg->endEA,
		seg->type, seg->perm);

    if(seg->type != SEG_CODE)
      continue;

	// FIXME: This loop is run once per code segment, should be run only once

      ea_t addr = seg->startEA;
      // Insert each instruction in the function region.
      while(addr <= seg->endEA){
	    insn_t *inst = NULL;
	    if(ua_code(addr) <= 0){ addr++; continue; }
	    inst = &cmd;
		char *instrstr = get_bytes_as_string(inst->ea, inst->size);
        if(instrstr == NULL){
          instrstr = (char *) qalloc(1);
          instrstr[0] = 0;
        }

		sql_exec(db,
			 "INSERT INTO instrs \n"
		     "(file_id, address, length, bytes) \n"
		     "values (%d, %llu, %u, \"%s\");", (int) file_id, 
			  (unsigned long long) inst->ea, (unsigned) inst->size,
		       instrstr
		);
		qfree(instrstr);

		unsigned long feat = inst->get_canon_feature();
		for(unsigned i = 0; i < UA_MAXOP; i++) {
			op_t *op = &(inst->Operands[i]);
			unsigned long use_mask = 0;
			unsigned long mod_mask = 0;
			switch (i) {
				case 0: use_mask = CF_USE1; mod_mask = CF_CHG1; break;
				case 1: use_mask = CF_USE2; mod_mask = CF_CHG2; break;
				case 2: use_mask = CF_USE3; mod_mask = CF_CHG3; break;
				case 3: use_mask = CF_USE4; mod_mask = CF_CHG4; break;
				case 4: use_mask = CF_USE5; mod_mask = CF_CHG5; break;
				case 5: use_mask = CF_USE6; mod_mask = CF_CHG6; break;
				default: break;
			}

			if (op->type != o_void) {
				int is_used = 0;
				int is_mod = 0;
				if (feat & use_mask) is_used = 1;
				if (feat & mod_mask) is_mod = 1;
				sql_exec(db,
					"INSERT INTO operands \n"
					"(file_id, insn_addr, offset, type, value, address, is_used, is_modified) \n"
					"values (%d, %llu, %hhu, %hhu, %llu, %llu, %hhu, %hhu);",
					(int) file_id, (unsigned long long) inst->ea, (unsigned char) op->offb, 
					(unsigned char) op->type, (unsigned long long) op->value, 
					(unsigned long long) op->addr, (unsigned char) is_used, (unsigned char) is_mod
					);
			}
		}

	   	addr += inst->size;
	  }
  }

  for(unsigned i = 0; i < get_func_qty(); i++){
    func_t *cf = getn_func(i);
    char typbuf[MAXSTR];
    typbuf[0] = 0;
    print_type(cf->startEA, typbuf, sizeof(typbuf), true);
    if(djb_debug)
      msg("Looking at function starting at %a\n",  cf->startEA);
    char function_name[MAXSTR];
    function_name[0] = 0;
    if(get_func_name(cf->startEA, function_name, MAXSTR) == NULL){
      msg("Skipping function...\n");
      continue;
    }
    // demangle name if possible
    char demname[MAXSTR];
    demname[0]= 0;
    if(demangle(demname, sizeof(demname), function_name, long(inf.short_demnames)) > 0){
      if(strcmp(demname, "string") == 0){
	strcpy_s(demname, MAXSTR-1, function_name);
      } 
    } 
    if(!*demname)
      strcpy_s(demname, MAXSTR-1, function_name);

    if(djb_debug) msg("Done getting name.\n");
    if(djb_debug)
      msg("Looking at function %s start: %a end: %a\n", demname,cf->startEA, cf->endEA);

    sql_exec(db, "INSERT INTO functions \n"
	     "(file_id,name,typedecl,flags,start_address,end_address) \n"
	     "values (%d,\"%s\",\"%s\",%d,%llu,%llu);",
	     file_id,
	     demname,
	     typbuf,
	     cf->flags,
	     (unsigned long long) cf->startEA,
	     (unsigned long long) cf->endEA);
    int64_t function_id = query_function_id(db, file_id, cf->startEA);
    // insert function tails:
    func_tail_iterator_t fti(cf);
    for ( bool ok=fti.first(); ok; ok=fti.next() ) {
      const area_t &a = fti.chunk();
      if(djb_debug)
	msg("chunk: %a - %a\n", a.startEA, a.endEA);
      sql_exec(db, "INSERT INTO ftails \n"
	       "(function_id,start_address,end_address) \n"
	       "values (%llu,%llu,%llu);",
	       (unsigned long long) function_id,
	       (unsigned long long) a.startEA,
	       (unsigned long long) a.endEA);
    }
  }

}


// Exports are the entry points in the PE. I don't
// know what happens with elf libraries here...djb
void populate_exports_table(sqlite3 *db, int file_id)
{
  for(unsigned i = 0; i < get_entry_qty(); i++){
    uval_t ord = -1;
    ord = get_entry_ordinal(i);
    ea_t entry_ea = get_entry(ord);
    char name[MAXSTR];
    name[0]= 0;
    get_entry_name(ord, name, sizeof(name));
      // demangle name if possible
      char demname[MAXSTR];
      demname[0] = 0;
      if(demangle(demname, sizeof(demname), name, long(inf.short_demnames)) < 0){
        if(strcmp(demname, "string") == 0){
           strcpy_s(demname, MAXSTR-1, name);
        } 
      } 
      if(strlen(demname) == 0)
        strcpy_s(demname, MAXSTR-1, name);
  
    sql_exec(db, "INSERT INTO exports \n"
	     "(file_id, name, ordinal, address) \n"
	     "values (%d,\"%s\", %d, %llu);",
	     file_id, demname, ord, (unsigned long long) entry_ea);
  }
}

void populate_strings_table(sqlite3 *db, int file_id)
{
  // file_id, address, type, length, bytes
  for(unsigned i= 0; i < get_strlist_qty(); i++){
    string_info_t si;
    get_strlist_item(i, &si);
    char *str = get_bytes_as_string(si.ea, si.length);
    if(str == NULL){
      str = (char *) qalloc(1*sizeof(char));
      str[0] = 0;
    }
	char *str2 = (char *)qalloc((strlen(str)*sizeof(char))+512);
	if(str2 == NULL){ warning("Skipping long string (not enough memory)\n"); qfree(str); continue;}
	_snprintf_s(str2, strlen(str)+512, _TRUNCATE,"INSERT INTO strings \n"
	     "(file_id, address, typ, length, bytes) \n"
	     "values \n"
	     "(%d, %llu, %d, %ld, \"%s\");",
	     file_id,
	     (unsigned long long) si.ea,
	     si.type,
	     si.length,
	     str);
    char * err;
    int ret = sqlite3_exec(db, str2, NULL, NULL, &err);
    if(ret != SQLITE_OK)
    {
		warning("sql_exec error: %s\n On stmt: %s", err, str2);
    }
    qfree(str);
	qfree(str2);
  }
}

void populate_vars_table(sqlite3 *db, int file_id)
{
  for(unsigned i = 0; i < get_func_qty(); i++){
    func_t *cf = getn_func(i);
    struc_t *frame = get_frame(cf);
    if(frame == NULL) continue;
    for(unsigned j = 0; j < frame->memqty; j++){
      char strucname[MAXSTR];
      strucname[0] = 0;
      get_struc_name(frame->members[j].id,strucname,sizeof(strucname));
      sql_exec(db, "INSERT INTO vars \n"
	       "(file_id, function_address, name, start_offset, "
	       "end_offset) \n"
	       "values \n"
	       "(%d, %llu, \"%s\", %ld, %ld);",
	       file_id,
	       (unsigned long long) cf->startEA,
	       strucname,
	       frame->members[j].soff,
	       frame->members[j].eoff);
    }
  }
}

void populate_imports_table(sqlite3 *db, int file_id)
{
  if(djb_debug) msg("Doing imports\n");
  for(int i = 0; i < get_segm_qty(); i++){
      segment_t *seg = getnseg(i);
      char name[MAXSTR];
      char extrainfo[MAXSTR];
	  name[0] = 0;
	  extrainfo[0] = 0;
      get_true_segm_name(seg, name, sizeof(name));

      //msg("Name: %s\n", name);
      if(strcmp(name, ".idata") != 0) continue;
      if(djb_debug) msg("Found Import data!\n");
      ea_t addr = seg->startEA;
      while(addr < seg->endEA && addr != BADADDR){
         name[0] = 0;
         extrainfo[0] = 0;
         flags_t flags = getFlags(addr);
         if(has_any_name(flags)){
           get_name(addr, addr, name, sizeof(name));
         // demangle name if possible
         char demname[MAXSTR];
         demname[0] = 0;
         if(demangle(demname, sizeof(demname), name, long(inf.short_demnames)) > 0){
            if(strcmp(demname, "string") == 0){
               strcpy_s(demname, MAXSTR-1, name);
            } 
         } 
         if(strlen(demname) == 0)
           strcpy_s(demname, MAXSTR-1, name);
      
          //msg("imports: Demangled name: %s orig name: %s\n", demname, name); 

           if(strncmp(demname, FUNC_IMPORT_PREFIX, sizeof(FUNC_IMPORT_PREFIX)-1) == 0){
                 sql_exec(db,"INSERT INTO imports "
                  "(file_id, name, address)"
                  " values (%d, \"%s\", %llu);", file_id, &demname[sizeof(FUNC_IMPORT_PREFIX)-1], (unsigned long long) addr);
           } else {
                 sql_exec(db,"INSERT INTO imports "
                  "(file_id, name, address)"
                  " values (%d, \"%s\", %llu);", file_id, demname, (unsigned long long ) addr);
           }
         }
         addr = nextaddr(addr);
      }     
  }
}


/* This function is labeled as a hack, because rather than storing information
   about fixups, it stores only addresses that have fixup information, and the
   values at those addresses. (Where values are 4 or 8 bytes depending on how IDA
   was compiled... This seems to be what Pongsin and Juan want for some project.
*/
void populate_fixup_hack_table(sqlite3 *db, int file_id)
{
  ea_t curr = get_first_fixup_ea();
  for (; curr != BADADDR; curr = get_next_fixup_ea(curr)) {

#ifdef __EA64__
	ea_t curr_content = (ea_t) get_qword(curr);
#else
	ea_t curr_content = (ea_t) get_long(curr);
#endif

	sql_exec(db,"INSERT INTO fixup_hack "
		 "(file_id, address, value)"
                  " values (%d, \"%llu\", %llu);",
		 file_id, (unsigned long long)curr, (unsigned long long )curr_content);

 	/* Anyone reading the DB can filter for functions in SQL, so no reason
	   to filter here. */
  }


}

int init(void)
{
  if(strncmp(inf.procName, "metapc", 8) != 0
     || inf.filetype != f_ELF && 
     inf.filetype != f_PE && 
     inf.filetype != f_BIN) {
    msg("IDA2SQL only works for ELF, PE, and BIN on x86\n. Skipping...");
    return PLUGIN_SKIP;
  }
  return PLUGIN_OK;
}

void term(void)
{
  return;
}


void run(int arg)
{
  if ( !autoIsOk()
       && askyn_c(-1, "HIDECANCEL\n"
		  "The autoanalysis has not finished yet.\n"
		  "The result might be incomplete. Do you want to continue?") < 0 )
    return;
  
  msg("Starting ida2sql plugin.\n");
  sqlite3 *db = init_db();
  if(db == NULL){
    msg("Database creation failed. Doing nothing.\n");
    return;
  }
  
  int file_id = generate_info_entry(db);
  if(file_id >= 0){
    msg("populate instr\n");
    populate_instr_table(db, file_id);
    msg("populate exports\n");
    populate_exports_table(db, file_id);
    msg("populate strings\n");
    populate_strings_table(db, file_id);
    msg("populate vars\n");
    populate_vars_table(db, file_id);
    msg("populate imports\n");
    populate_imports_table(db, file_id);
    msg("populate fixup_hack\n");
    populate_fixup_hack_table(db, file_id);
    
  }
  close_db(db); 
  db = NULL;
  msg("ida2sql plugin done.");
}


char plugin_name[] = "IDA2SQLite";
char plugin_hotkey[] = "Ctrl-F12";
char plugin_comment[] = "Write IDA disassembly information to an "
"SQLite3 database";
char plugin_help[] = "No help available";

//--------------------------------------------------------------------------
plugin_t PLUGIN =
{
  IDP_INTERFACE_VERSION,
  0,                    // plugin flags
  init,                 // initialize
  term,
  run,                  // invoke plugin
  plugin_comment,
  plugin_help,
  plugin_name,
  plugin_hotkey,
};
