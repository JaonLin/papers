(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
open Protoloops
open Msg
open Prototree
open Trace_loops 
open Vine_util
module TLS=Trace_loops_static

type cmdargs_t = {
  mutable in_tree_l : Prototree.prototree list;
  mutable in_trace_filename : string;
  mutable in_loop_filename : string;
  mutable out_protoloop_file : string;
  mutable in_protoloop_file : string;
  print_protospec : bool ref;
} ;;



let cmdargs = {
  in_tree_l = [];
  in_trace_filename = "";
  in_loop_filename = "";
  out_protoloop_file = "";
  in_protoloop_file = "";
  print_protospec = ref false;
} 
in
let add_tree_wshark s = 
  Printf.printf "Parsing wireshark input %s ...\n" s;
  let t = Prototree.unserialize_wshark s in
    cmdargs.in_tree_l <- t :: cmdargs.in_tree_l;
    Printf.printf "Done\n"
in
let ignore_arg x = (failwith x) in
let rec arg_spec =
  ("-treew", Arg.String add_tree_wshark,
   "<tree_filename> Unserialize wireshark tree from file")
  ::("-trace", Arg.String (fun s -> cmdargs.in_trace_filename <- s),
     "<trace_filename> Trace to extract format or loops")
  ::("-loopfile", Arg.String (fun s -> cmdargs.in_loop_filename <- s),
     "<loop_filename> Input loop file containing full loop info (not just backedges). Use polyglot/traceloop_det -genloopfile")
  ::("-o", Arg.String (fun s -> cmdargs.out_protoloop_file <- s),
     "<binary_fname> Output file to write protocol field info to length mappings.")
  ::("-protospec", Arg.String (fun s -> cmdargs.in_protoloop_file <- s),
     "<binary_fname> Input file which contains protocol field info to length mappings.")
  ::("-print_spec", Arg.Set cmdargs.print_protospec,
     "flag to print out protospec to stdout.")
  ::[]
in
let _ = Arg.parse arg_spec ignore_arg ""
in 
  if !(cmdargs.print_protospec) && cmdargs.in_protoloop_file <> "" then
    begin
      let infile = open_in cmdargs.in_protoloop_file in
      let info = unserialize infile in
      let () = close_in infile in
	print_protoloops stdout info;
	exit 0;
    end;
  let fieldtbl = Hashtbl.create 100 
  in make_field_ranges fieldtbl (try List.hd cmdargs.in_tree_l 
				 with Failure x -> failwith "Supply -treew <.req> file for wireshark input");
  Printf.printf "Reading loops from file ...\n";
  let loop_info_l = (try TLS.read_loop_info_from_file cmdargs.in_loop_filename
		     with Sys_error s -> failwith "Did you supply the -loopfile option fully?") 
  in D.dprintf "Num loops: %d\n" (List.length loop_info_l);
    let outfile = (try (open_out_bin cmdargs.out_protoloop_file) 
		   with _ -> failwith ("Could not open outfile. ")) 
    in if (cmdargs.in_trace_filename <> "") then (
	D.dprintf "Finding loops in trace: %s\n" cmdargs.in_trace_filename;
	let loop_l = TLS.extract_statloops_from_trace loop_info_l cmdargs.in_trace_filename 
	in
	let get_iter_tidset set iter = 
	  let get_ec_tidset set exitcond = List.fold_left (fun set (t,id) -> SetOfInt.add id set) set exitcond.ec_taint_l in
	    List.fold_left (get_ec_tidset) set iter.iec_l 
	in
	let check_range_subset set fieldstart fieldend = 
	  let fldset = SetOfInt.filter (fun x -> ((x >= fieldstart) && (x <= fieldend))) set 
	  in (* Printf.printf "Set size %d\n" (SetOfInt.cardinal fldset); *)
	    ((SetOfInt.cardinal fldset) == (fieldend - fieldstart + 1)) 
	in
	let check_loop loop r =
	  let set_of_seen_taintids = List.fold_left (get_iter_tidset)  SetOfInt.empty loop.iter_list in 
	  let gather_fids fid (name, fstart, fend) (retset : SetOfFieldData.t) = 
	    if (check_range_subset set_of_seen_taintids fstart fend) 
	    then (
	      D.dprintf "Loop Id : %d, depends on Len (%s_%d [%d %d])\n" loop.id name fid fstart fend;
	      let fldlen = (fend - fstart + 1) in
		SetOfFieldData.add (fid, fldlen) retset
	    ) else retset 
	  in 
	  let set_of_fields  = Hashtbl.fold gather_fids fieldtbl SetOfFieldData.empty
	  in (loop, set_of_fields)::r
	in serialize outfile (List.fold_right (check_loop) loop_l [])
      ) 
      else failwith ("Please give in the trace file");
      
;;

