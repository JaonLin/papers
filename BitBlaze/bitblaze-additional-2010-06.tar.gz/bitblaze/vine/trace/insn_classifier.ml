(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  A classifier for x86 instructions
  Includes other generally useful functions to operate with traces such as 
wns_flag:true
    obtaining the list of operands in an instruction or checking if an 
    instruction is tainted
  The x86 classifier can be considered a very basic disassembler for 
    some x86 instructions. 
  It should be replaced by a proper disassembler some time in the future 

*)

module Trace = Temu_trace
open Trace

(* Instruction prefixes *)
type prefixType =
  | ADSIZE
  | OPSIZE
  | REPE
  | REPNE
  | LOCK
  | SEG_CS
  | SEG_DS
  | SEG_ES
  | SEG_FS
  | SEG_GS
  | SEG_SS

(* Instruction mnemonics *)
type insnMnemonic =
  (* Special mnemonics *)
  | UNSUPPORTED (* Instruction not disassembled *)
  | UNASSIGNED (* Opcode does not exist, has not been assigned *)
  | ERROR (* Found incorrect opcode *)
  | FLOAT (* Floating point opcode, individual opcodes not extracted yet *)
  (* Instruction mnemonics *)
  | M_AAA
  | M_AAD
  | M_AAM
  | M_AAS
  | M_ADC
  | M_ADD
  | M_AND
  | M_ARPL
  | M_BOUND
  | M_BSWAP
  | M_BTR
  | M_CALL
  | M_CBW
  | M_CLC
  | M_CLD
  | M_CLI
  | M_CMC
  | M_CMP
  | M_CMPS
  | M_CMPXCHG
  | M_CPUID
  | M_CWD
  | M_DAA
  | M_DAS
  | M_DEC
  | M_DIV
  | M_ENTER
  | M_HLT
  | M_ICALL
  | M_ICEBP
  | M_IDIV
  | M_IJMP
  | M_IMUL
  | M_IN
  | M_INC
  | M_INS
  | M_INT
  | M_INT3
  | M_INTO
  | M_IRET
  | M_JA
  | M_JAE
  | M_JB
  | M_JBE
  | M_JE
  | M_JECX
  | M_JG
  | M_JGE
  | M_JL
  | M_JLE
  | M_JMP
  | M_JNB
  | M_JNBE
  | M_JNE
  | M_JNL
  | M_JNLE
  | M_JNO
  | M_JNP
  | M_JNS
  | M_JNZ
  | M_JO
  | M_JP
  | M_JS
  | M_JZ
  | M_LAHF
  | M_LDS
  | M_LEA
  | M_LEAVE
  | M_LES
  | M_LFS
  | M_LGS
  | M_LODS
  | M_LOOP
  | M_LOOPE
  | M_LOOPNE
  | M_LSS
  | M_MOV
  | M_MOVD
  | M_MOVQ
  | M_MOVS
  | M_MOVZX
  | M_MUL
  | M_NEG
  | M_NOP
  | M_NOT
  | M_OR
  | M_OUT
  | M_OUTS
  | M_POP
  | M_POPA
  | M_POPF
  | M_PUSH
  | M_PUSHA
  | M_PUSHF
  | M_RCL
  | M_RCR
  | M_RDTSC
  | M_RET
  | M_ROL
  | M_ROR
  | M_SAHF
  | M_SAL
  | M_SALC
  | M_SAR
  | M_SBB
  | M_SCAS
  | M_SHL
  | M_SHR
  | M_STC
  | M_STD
  | M_STI
  | M_STOS
  | M_SUB
  | M_SYSENTER
  | M_TEST
  | M_WAIT
  | M_XCHG
  | M_XLAT
  | M_XOR

(* Disassembly information for an instruction *)
type insnInfo = {
  disas_prefix_l : prefixType list; (* List of prefixes *)
  disas_opcode : int; (* Opcode, after removing prefixes *)
  disas_two_byte_opcode : bool; (* If true then opcode is (0x0f,disas_opcode) *)
  disas_maskedmodrm : int; (* Masked modrm *)
}

(* Disassemble the instruction
   Given the rawbytes returns a insnInfo record *)
let disas_insn rawbytes =
  let rec _opcode rawbytes acc idx =
    let curr_byte = int_of_char rawbytes.(idx) in
    match curr_byte with
      (* Lock Prefix *)
      | 0xf0 ->
	_opcode rawbytes (LOCK::acc) (idx+1)
      (* Repeat NE Prefix *)
      | 0xf2 ->
	_opcode rawbytes (REPNE::acc) (idx+1)
      (* Repeat Prefix *)
      | 0xf3 ->
	_opcode rawbytes (REPE::acc) (idx+1)
      (* Segment Override Prefixes *)
      | 0x26 ->
	_opcode rawbytes (SEG_CS::acc) (idx+1)
      | 0x2e ->
	_opcode rawbytes (SEG_GS::acc) (idx+1)
      | 0x36 ->
	_opcode rawbytes (SEG_SS::acc) (idx+1)
      | 0x3e ->
	_opcode rawbytes (SEG_DS::acc) (idx+1)
      | 0x64 ->
	_opcode rawbytes (SEG_FS::acc) (idx+1)
      | 0x65 ->
	_opcode rawbytes (SEG_GS::acc) (idx+1)
      (* Operand Size Prefix *)
      | 0x66 ->
	_opcode rawbytes (OPSIZE::acc) (idx+1)
      (* Address Size Prefix *)
      | 0x67 ->
	_opcode rawbytes (ADSIZE::acc) (idx+1)
      (* No prefix - Two byte opcode *)
      | 0x0f ->
        {
          disas_prefix_l = acc;
          disas_opcode = int_of_char rawbytes.(idx+1);
          disas_two_byte_opcode = true;
          disas_maskedmodrm = try int_of_char rawbytes.(idx+2) with _ -> 0;
        }
      (* No prefix - One byte opcode *)
      | _ ->
        {
          disas_prefix_l = acc;
          disas_opcode = curr_byte;
          disas_two_byte_opcode = false;
          disas_maskedmodrm = ((int_of_char rawbytes.(idx+1)) lsr 3) land 7;
        }
  in
  _opcode rawbytes [] 0

(* Is rep instruction *)
let is_rep_insn insn =
  let insn_info = disas_insn insn#rawbytes in
  List.exists (fun x -> (x = REPE) || (x = REPNE)) insn_info.disas_prefix_l

(* Classify an instruction *)
let insn_class rb =
  let insn_info = disas_insn rb in
  if insn_info.disas_two_byte_opcode
  then
    match insn_info.disas_opcode with
      | 0x31 -> M_RDTSC
      | 0x34 -> M_SYSENTER
      | 0x6e -> M_MOVD
      | 0x6f -> M_MOVQ
      | 0x7e -> M_MOVD
      | 0x7f -> M_MOVQ
      | 0xA2 -> M_CPUID
      | 0x80 -> M_JO
      | 0x81 -> M_JNO
      | 0x82 -> M_JB
      | 0x83 -> M_JNB
      | 0x84 -> M_JZ
      | 0x85 -> M_JNZ
      | 0x86 -> M_JBE
      | 0x87 -> M_JNBE
      | 0x88 -> M_JS
      | 0x89 -> M_JNS
      | 0x8A -> M_JP
      | 0x8B -> M_JNP
      | 0x8C -> M_JL
      | 0x8D -> M_JNL
      | 0x8E -> M_JLE
      | 0x8F -> M_JNLE
      | 0xB0 | 0xB1 -> M_CMPXCHG
      | 0xB2 -> M_LSS
      | 0xB3 -> M_BTR
      | 0xB4 -> M_LFS
      | 0xB5 -> M_LGS
      | 0xB6 | 0xB7 -> M_MOVZX
      | 0xC8 -> M_BSWAP
      | _ -> UNSUPPORTED
  else
    match (insn_info.disas_opcode, insn_info.disas_maskedmodrm)  with
      | (0x80, 0) | (0x81, 0) | (0x82, 0) | (0x83, 0) -> M_ADD
      | (0x80, 1) | (0x81, 1) | (0x82, 1) | (0x83, 1) -> M_OR
      | (0x80, 2) | (0x81, 2) | (0x82, 2) | (0x83, 2) -> M_ADC
      | (0x80, 3) | (0x81, 3) | (0x82, 3) | (0x83, 3) -> M_SBB
      | (0x80, 4) | (0x81, 4) | (0x82, 4) | (0x83, 4) -> M_AND
      | (0x80, 5) | (0x81, 5) | (0x82, 5) | (0x83, 5) -> M_SUB
      | (0x80, 6) | (0x81, 6) | (0x82, 6) | (0x83, 6) -> M_XOR
      | (0x80, 7) | (0x81, 7) | (0x82, 7) | (0x83, 7) -> M_CMP
      | (0xC0, 0) | (0xC1, 0) |(0xD0, 0) | (0xD1, 0) | (0xD2, 0) | (0xD3, 0)
      	-> M_ROL
      | (0xC0, 1) | (0xC1, 1) |(0xD0, 1) | (0xD1, 1) | (0xD2, 1) | (0xD3, 1)
      	-> M_ROR
      | (0xC0, 2) | (0xC1, 2) |(0xD0, 2) | (0xD1, 2) | (0xD2, 2) | (0xD3, 2)
      	-> M_RCL
      | (0xC0, 3) | (0xC1, 3) |(0xD0, 3) | (0xD1, 3) | (0xD2, 3) | (0xD3, 3)
      	-> M_RCR
      | (0xC0, 4) | (0xC1, 4) |(0xD0, 4) | (0xD1, 4) | (0xD2, 4) | (0xD3, 4)
      	-> M_SHL
      | (0xC0, 5) | (0xC1, 5) |(0xD0, 5) | (0xD1, 5) | (0xD2, 5) | (0xD3, 5)
      	-> M_SHR
      | (0xC0, 6) | (0xC1, 6) |(0xD0, 6) | (0xD1, 6) | (0xD2, 6) | (0xD3, 6)
      	-> M_SAL
      | (0xC0, 7) | (0xC1, 7) |(0xD0, 7) | (0xD1, 7) | (0xD2, 7) | (0xD3, 7)
      	-> M_SAR
      | (0xC6, 0) | (0xC7, 0) -> M_MOV
      | (0xC6, _) | (0xC7, _) -> UNASSIGNED
      | (0xF6, 0) | (0xF7, 0) -> M_TEST
      | (0xF6, 1) | (0xF7, 1) -> M_TEST
      | (0xF6, 2) | (0xF7, 2) -> M_NOT
      | (0xF6, 3) | (0xF7, 3) -> M_NEG
      | (0xF6, 4) | (0xF7, 4) -> M_MUL
      | (0xF6, 5) | (0xF7, 5) -> M_IMUL
      | (0xF6, 6) | (0xF7, 6) -> M_DIV
      | (0xF6, 7) | (0xF7, 7) -> M_IDIV
      | (0xFE, 0) -> M_INC
      | (0xFE, 1) -> M_DEC
      | (0xFE, _) -> UNASSIGNED
      | (0xFF, 0) -> M_INC
      | (0xFF, 1) -> M_DEC
      | (0xFF, 2) -> M_ICALL
      | (0xFF, 3) -> M_ICALL
      | (0xFF, 4) -> M_IJMP
      | (0xFF, 5) -> M_JMP
      | (0xFF, 6) -> M_PUSH
      | (0xFF, 7) -> UNASSIGNED
      | (0x00, _) -> M_ADD
      | (0x01, _) -> M_ADD
      | (0x02, _) -> M_ADD
      | (0x03, _) -> M_ADD
      | (0x04, _) -> M_ADD
      | (0x05, _) -> M_ADD
      | (0x06, _) -> M_PUSH
      | (0x07, _) -> M_POP
      | (0x08, _) -> M_OR
      | (0x09, _) -> M_OR
      | (0x0A, _) -> M_OR
      | (0x0B, _) -> M_OR
      | (0x0C, _) -> M_OR
      | (0x0D, _) -> M_OR
      | (0x0E, _) -> M_PUSH
      (* 0x0F -> Two-byte opcode *)
      | (0x10, _) -> M_ADC
      | (0x11, _) -> M_ADC
      | (0x12, _) -> M_ADC
      | (0x13, _) -> M_ADC
      | (0x14, _) -> M_ADC
      | (0x15, _) -> M_ADC
      | (0x16, _) -> M_PUSH
      | (0x17, _) -> M_POP
      | (0x18, _) -> M_SBB
      | (0x19, _) -> M_SBB
      | (0x1A, _) -> M_SBB
      | (0x1B, _) -> M_SBB
      | (0x1C, _) -> M_SBB
      | (0x1D, _) -> M_SBB
      | (0x1E, _) -> M_PUSH
      | (0x1F, _) -> M_POP
      | (0x20, _) -> M_AND
      | (0x21, _) -> M_AND
      | (0x22, _) -> M_AND
      | (0x23, _) -> M_AND
      | (0x24, _) -> M_AND
      | (0x25, _) -> M_AND
      (* 0x26 -> Segment Override Prefix: ES *)
      | (0x27, _) -> M_DAA
      | (0x28, _) -> M_SUB
      | (0x29, _) -> M_SUB
      | (0x2A, _) -> M_SUB
      | (0x2B, _) -> M_SUB
      | (0x2C, _) -> M_SUB
      | (0x2D, _) -> M_SUB
      (* 0x2E -> Segment Override Prefix: CS *)
      | (0x2F, _) -> M_DAS
      | (0x30, _) -> M_XOR
      | (0x31, _) -> M_XOR
      | (0x32, _) -> M_XOR
      | (0x33, _) -> M_XOR
      | (0x34, _) -> M_XOR
      | (0x35, _) -> M_XOR
      (* 0x36 -> Segment Override Prefix: ES *)
      | (0x37, _) -> M_AAA
      | (0x38, _) -> M_CMP
      | (0x39, _) -> M_CMP
      | (0x3A, _) -> M_CMP
      | (0x3B, _) -> M_CMP
      | (0x3C, _) -> M_CMP
      | (0x3D, _) -> M_CMP
      (* 0x3E -> Segment Override Prefix: DS *)
      | (0x3F, _) -> M_AAS
      | (0x40, _) -> M_INC
      | (0x41, _) -> M_INC
      | (0x42, _) -> M_INC
      | (0x43, _) -> M_INC
      | (0x44, _) -> M_INC
      | (0x45, _) -> M_INC
      | (0x46, _) -> M_INC
      | (0x47, _) -> M_INC
      | (0x48, _) -> M_DEC
      | (0x49, _) -> M_DEC
      | (0x4A, _) -> M_DEC
      | (0x4B, _) -> M_DEC
      | (0x4C, _) -> M_DEC
      | (0x4D, _) -> M_DEC
      | (0x4E, _) -> M_DEC
      | (0x4F, _) -> M_DEC
      | (0x50, _) -> M_PUSH
      | (0x51, _) -> M_PUSH
      | (0x52, _) -> M_PUSH
      | (0x53, _) -> M_PUSH
      | (0x54, _) -> M_PUSH
      | (0x55, _) -> M_PUSH
      | (0x56, _) -> M_PUSH
      | (0x57, _) -> M_PUSH
      | (0x58, _) -> M_POP
      | (0x59, _) -> M_POP
      | (0x5A, _) -> M_POP
      | (0x5B, _) -> M_POP
      | (0x5C, _) -> M_POP
      | (0x5D, _) -> M_POP
      | (0x5E, _) -> M_POP
      | (0x5F, _) -> M_POP
      | (0x60, _) -> M_PUSHA
      | (0x61, _) -> M_POPA
      | (0x62, _) -> M_BOUND
      | (0x63, _) -> M_ARPL
      (* 0x64 -> Segment Override Prefix: FS *)
      (* 0x65 -> Segment Override Prefix: GS *)
      (* 0x66 -> Operand Size Prefix *)
      (* 0x67 -> Address Size Prefix *)
      | (0x68, _) -> M_PUSH
      | (0x69, _) -> M_IMUL
      | (0x6A, _) -> M_PUSH
      | (0x6B, _) -> M_IMUL
      | (0x6C, _) -> M_INS
      | (0x6D, _) -> M_INS
      | (0x6E, _) -> M_OUTS
      | (0x6F, _) -> M_OUTS
      | (0x70, _) -> M_JO
      | (0x71, _) -> M_JNO
      | (0x72, _) -> M_JB
      | (0x73, _) -> M_JAE
      | (0x74, _) -> M_JE
      | (0x75, _) -> M_JNE
      | (0x76, _) -> M_JBE
      | (0x77, _) -> M_JA
      | (0x78, _) -> M_JS
      | (0x79, _) -> M_JNS
      | (0x7A, _) -> M_JP
      | (0x7B, _) -> M_JNP
      | (0x7C, _) -> M_JL
      | (0x7D, _) -> M_JGE
      | (0x7E, _) -> M_JLE
      | (0x7F, _) -> M_JG
      | (0x84, _) -> M_TEST
      | (0x85, _) -> M_TEST
      | (0x86, _) -> M_XCHG
      | (0x87, _) -> M_XCHG
      | (0x88, _) -> M_MOV
      | (0x89, _) -> M_MOV
      | (0x8A, _) -> M_MOV
      | (0x8B, _) -> M_MOV
      | (0x8C, _) -> M_MOV
      | (0x8D, _) -> M_LEA
      | (0x8E, _) -> M_MOV
      | (0x8F, _) -> M_POP
      | (0x90, _) -> M_NOP
      | (0x91, _) -> M_XCHG
      | (0x92, _) -> M_XCHG
      | (0x93, _) -> M_XCHG
      | (0x94, _) -> M_XCHG
      | (0x95, _) -> M_XCHG
      | (0x96, _) -> M_XCHG
      | (0x97, _) -> M_XCHG
      | (0x98, _) -> M_CBW
      | (0x99, _) -> M_CWD
      | (0x9A, _) -> M_CALL
      | (0x9B, _) -> M_WAIT
      | (0x9C, _) -> M_PUSHF
      | (0x9D, _) -> M_POPF
      | (0x9E, _) -> M_SAHF
      | (0x9F, _) -> M_LAHF
      | (0xA0, _) -> M_MOV
      | (0xA1, _) -> M_MOV
      | (0xA2, _) -> M_MOV
      | (0xA3, _) -> M_MOV
      | (0xA4, _) -> M_MOVS
      | (0xA5, _) -> M_MOVS
      | (0xA6, _) -> M_CMPS
      | (0xA7, _) -> M_CMPS
      | (0xA8, _) -> M_TEST
      | (0xA9, _) -> M_TEST
      | (0xAA, _) -> M_STOS
      | (0xAB, _) -> M_STOS
      | (0xAC, _) -> M_LODS
      | (0xAD, _) -> M_LODS
      | (0xAE, _) -> M_SCAS
      | (0xAF, _) -> M_SCAS
      | (0xB0, _) -> M_MOV
      | (0xB1, _) -> M_MOV
      | (0xB2, _) -> M_MOV
      | (0xB3, _) -> M_MOV
      | (0xB4, _) -> M_MOV
      | (0xB5, _) -> M_MOV
      | (0xB6, _) -> M_MOV
      | (0xB7, _) -> M_MOV
      | (0xB8, _) -> M_MOV
      | (0xB9, _) -> M_MOV
      | (0xBA, _) -> M_MOV
      | (0xBB, _) -> M_MOV
      | (0xBC, _) -> M_MOV
      | (0xBD, _) -> M_MOV
      | (0xBE, _) -> M_MOV
      | (0xBF, _) -> M_MOV
      | (0xC2, _) -> M_RET
      | (0xC3, _) -> M_RET
      | (0xC4, _) -> M_LES
      | (0xC5, _) -> M_LDS
      | (0xC8, _) -> M_ENTER
      | (0xC9, _) -> M_LEAVE
      | (0xCA, _) -> M_RET
      | (0xCB, _) -> M_RET
      | (0xCC, _) -> M_INT3
      | (0xCD, _) -> M_INT
      | (0xCE, _) -> M_INTO
      | (0xCF, _) -> M_IRET
      | (0xD4, _) -> M_AAM
      | (0xD5, _) -> M_AAD
      | (0xD6, _) -> M_SALC
      | (0xD7, _) -> M_XLAT
      | (0xD8, _) -> FLOAT
      | (0xD9, _) -> FLOAT
      | (0xDA, _) -> FLOAT
      | (0xDB, _) -> FLOAT
      | (0xDC, _) -> FLOAT
      | (0xDD, _) -> FLOAT
      | (0xDE, _) -> FLOAT
      | (0xDF, _) -> FLOAT
      | (0xE0, _) -> M_LOOPNE
      | (0xE1, _) -> M_LOOPE
      | (0xE2, _) -> M_LOOP
      | (0xE3, _) -> M_JECX
      | (0xE4, _) -> M_IN
      | (0xE5, _) -> M_IN
      | (0xE6, _) -> M_OUT
      | (0xE7, _) -> M_OUT
      | (0xE8, _) -> M_CALL
      | (0xE9, _) -> M_JMP
      | (0xEA, _) -> M_JMP
      | (0xEB, _) -> M_JMP
      | (0xEC, _) -> M_IN
      | (0xED, _) -> M_IN
      | (0xEE, _) -> M_OUT
      | (0xEF, _) -> M_OUT
      (* 0xF0 -> Lock Prefix *)
      | (0xF1, _) -> M_ICEBP
      (* 0xF2 -> Repeat NE Prefix *)
      (* 0xF3 -> Repeat Prefix *)
      | (0xF4, _) -> M_HLT
      | (0xF5, _) -> M_CMC
      | (0xF8, _) -> M_CLC
      | (0xF9, _) -> M_STC
      | (0xFA, _) -> M_CLI
      | (0xFB, _) -> M_STI
      | (0xFC, _) -> M_CLD
      | (0xFD, _) -> M_STD
      | (_, _) -> ERROR

(********************  General insn information ************************)

(* Get list of operands used in an instruction *)
let get_operands_in_insn ?(include_memregs=true) ?(include_esp=true) insn =
  let add_op l op =
    if (op#optype <> TNone)
      then op :: l
      else l
  in
  (* Get memory addressing operands *)
  let acc =
    if (include_memregs) then (
      Array.fold_left
        (fun acc op_arr -> Array.fold_left add_op acc op_arr)
        []
        insn#memregs
    )
    else []
  in
  (* Add src,dst,ctr operands *)
  let acc =
    List.fold_left add_op acc (List.rev (Array.to_list insn#operand))
  in
  (* Add esp operand if requested *)
  if (include_esp)
    then add_op acc insn#esp
    else acc

(* Get list of memory operands, with associated memregs, in an instruction *)
let get_mem_operands_in_insn insn =
  let process_op (idx,acc) op =
    match op#optype with
      | TMemLoc -> (idx+1,(op,insn#memregs.(idx)) :: acc)
      | _ -> (idx+1,acc)
  in
  let rev_mem_op_l = snd (Array.fold_left process_op (0,[]) insn#operand) in
  List.rev rev_mem_op_l


(* Get list of operands read and written by instruction
   Returns a pair of lists (read_op_l,write_op_l) *)
let get_rw_operands ?(include_immediates=false) ?(include_esp=false)
    ?(include_memregs=false) insn =
  let op_l =
    get_operands_in_insn ~include_memregs:include_memregs
      ~include_esp:include_esp insn
  in
  let process_op (rl,wl) op =
    match op#optype with
      | TRegister | TMemLoc -> (
          match op#opaccess with
            | A_RW -> (op::rl, op::wl)  (* Read and written *)
            | A_R -> (op::rl, wl)       (* Read-only *)
            | A_W -> (rl, op::wl)       (* Write-only *)
            | A_RCW -> (op::rl,op::wl)  (* Read and conditionally write *)
            | A_CW -> (rl,op::wl)       (* Conditionally written *)
            | A_CRW -> (op::rl,op::wl)  (* Conditionally read, always written *)
            | A_CR -> (op::rl,wl)       (* Conditionally read *)
            | A_Unknown -> (rl,wl)
        )
    | TImmediate when (include_immediates) -> (
          match op#opaccess with
            | A_RW -> (op::rl, op::wl)  (* Read and written *)
            | A_R -> (op::rl, wl)       (* Read-only *)
            | A_W -> (rl, op::wl)       (* Write-only *)
            | A_RCW -> (op::rl,op::wl)  (* Read and conditionally write *)
            | A_CW -> (rl,op::wl)       (* Conditionally written *)
            | A_CRW -> (op::rl,op::wl)  (* Conditionally read, always written *)
            | A_CR -> (op::rl,wl)       (* Conditionally read *)
            | A_Unknown -> (rl,wl)
        )
     | _ -> (rl,wl)
  in
  List.fold_left process_op ([],[]) op_l

(* Get value of byte at index [idx] from operand [op] *)
let get_op_byteval op idx =
  let byte_val = Int32.shift_right op#opvalue (idx*8) in
  Int32.logand byte_val 0xFFl


(************************* Taint functions ********************************)

(* Is operand tainted *)
let is_op_tainted op =
  op#taintflag <> 0L

(* Check if a byte in a operand is tainted *)
let byte_tainted op idx =
    (Int64.logand
       (Int64.shift_right_logical op#taintflag idx) 1L
    ) = 1L

(* Check whether an instruction is tainted, that is if it has any
    tainted operands *)
let is_tainted_instruction insn =
  match insn#tp with
    | Trace.TPUnknown ->
        let op_l = get_operands_in_insn insn in
        List.exists is_op_tainted op_l
    | Trace.TPNone -> false
    | Trace.TPSrc
    | Trace.TPCjmp
    | Trace.TPMemReadIndex
    | Trace.TPMemWriteIndex
    | Trace.TPRepCounter -> true

(* Add taint data used by an instruction, to given list *)
let add_taint_info_in_insn_to_list ?(include_memregs=false) 
      ?(include_esp=false) taint_l insn  =
  match insn#tp with
    | TPNone -> taint_l
    | _ -> (
        (* Load already seen pairs to hashtbl *)
        let tbl_size = (List.length taint_l) * 2 in
        let already_seen_tbl = Hashtbl.create tbl_size in
        List.iter (fun pair -> Hashtbl.replace already_seen_tbl pair true)
          taint_l;
        (* Get list of operands *)
        let op_l = 
          get_operands_in_insn ~include_memregs:include_memregs 
            ~include_esp:include_esp insn
        in
        (* Add (origin,offset) pair to hashtbl *)
        let process_op op =
          if (op#oplen <= 0) then (
            Trace.print_virtual_insn stderr insn;
            failwith "Operand with invalid length"
          );
          for i = 0 to (op#oplen - 1) do
	    if (Int64.logand op#taintflag (Int64.of_int (1 lsl i))) <> 0L
	    then
	      let origin = op#origin.(i) in
              let offset = Int32.to_int op#offset.(i) in
		Hashtbl.replace already_seen_tbl (origin,offset) true
	    else ()
          done;
        in
        List.iter process_op op_l;
        (* Hashtbl to list *)
        Hashtbl.fold (fun pair _ l -> pair :: l) already_seen_tbl []
      )

(* Get taint data accessed by an instruction *)
let get_insn_taint ?(include_memregs=false) ?(include_esp=false) insn = 
  add_taint_info_in_insn_to_list ~include_memregs:include_memregs 
    ~include_esp:include_esp [] insn

(********************** Operand classifier functions *************************)

(* Predicate to determine if an operand is ESP *)
let is_esp_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 136L)

(* Predicate to determine if an operand is EBP *)
let is_ebp_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 137L)

(* Predicate to determine if an operand is EAX *)
let is_eax_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 132L)

(* Predicate to determine if an operand is EBX *)
let is_ebx_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 135L)

(* Predicate to determine if an operand is ECX *)
let is_ecx_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 133L)

(* Predicate to determine if an operand is EDX *)
let is_edx_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 134L)

(* Predicate to determine if an operand is ESI *)
let is_esi_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 138L)

(* Predicate to determine if an operand is EDI *)
let is_edi_op op =
  (op#optype = Temu_trace.TRegister) && (op#opaddr = 139L)


(********************** Instruction classifier functions *********************)

(* Check if an instruction is a call *)
let is_call_raw itype =
  match itype  with
    M_CALL -> true
    | M_ICALL -> true
    | _ -> false
let is_call insn = is_call_raw (insn_class insn#rawbytes)

(* Check if an instruction is a return (ret) *)
let is_ret_raw itype =
  match itype  with
    M_RET -> true
    | _ -> false
let is_ret insn = is_ret_raw (insn_class insn#rawbytes)

(* Check if an instruction is XOR with identical operands *)
let is_xor_identical insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      M_XOR -> (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr)
      | _ -> false

(* Check if an instruction is TEST with identical operands *)
let is_test_identical insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      M_TEST -> (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr)
      | _ -> false

(* Check if an instruction is a substraction with identical operands *)
let is_sub_identical insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      M_SUB -> (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr)
      | _ -> false

(* Check if an instruction is an AND with zero immediate *)
let is_and_with_zero_imm insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      M_AND -> (
	let op_l =
	  get_operands_in_insn ~include_memregs:false ~include_esp:false insn
	in
	try (
	  let imm_op = List.find (fun op -> op#optype = TImmediate) op_l in
	  (imm_op#opvalue = 0l)
	)
	with _ -> false
      )
      | _ -> false

(* Check if an instruction is an OR with minus_one immediate *)
let is_or_with_minus_one_imm insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      M_OR -> (
        let op_l =
          get_operands_in_insn ~include_memregs:false ~include_esp:false insn
        in
        try (
          let imm_op = List.find (fun op -> op#optype = TImmediate) op_l in
(*
	    match imm_op#oplen with
	      | 1 -> 0xFFl
	      | 2 -> 0xFFFFl
	      | 3 -> 0xFFFFFFl
	      | _ -> Int32.minus_one
*)
          (imm_op#opvalue = Int32.minus_one)
        )
        with _ -> false
      )
      | _ -> false

(* Special handling for XOR with 0xff *)
let is_xor_with_minus_one insn =
  let itype = insn_class insn#rawbytes in
  let minus_one_const len =
    match len with
      | 1 -> 0xffl
      | 2 -> 0xffffl
      | 3 -> 0xffffffl
      | 4 -> 0xffffffffl
      | _ -> failwith "Invalid operand length in is_xor_minus_one"
  in
  match itype  with
    | M_XOR when (is_op_tainted insn#operand.(0)) ->
	if (is_op_tainted insn#operand.(1)) then false
	else
	  let moc = minus_one_const insn#operand.(0)#oplen in
	  (insn#operand.(1)#opvalue = moc)
    | M_XOR when (is_op_tainted insn#operand.(1)) ->
	if (is_op_tainted insn#operand.(0)) then false
	else
	  let moc = minus_one_const insn#operand.(1)#oplen in
	  (insn#operand.(0)#opvalue = moc)
    | _ -> false


(* Check if an instruction is float *)
let is_float_raw itype =
  match itype  with
    FLOAT -> true
    | _ -> false
let is_float insn = is_float_raw (insn_class insn#rawbytes)

(* Check if an instruction is preparation:
    mov, lea, pop, push, stos *)
let is_preparation_raw itype =
  match itype  with
    M_MOV | M_MOVS | M_LEA | M_POP | M_POPA | M_POPF
    | M_PUSH | M_PUSHA | M_PUSHF | M_STOS | M_MOVZX -> true
    | _ -> false
let is_preparation insn = is_preparation_raw (insn_class insn#rawbytes)

(* Check if an instruction is a unconditional jump *)
let is_uncond_jump_raw itype =
  match itype  with
    M_JMP -> true
    | M_IJMP -> true
    | _ -> false
let is_uncond_jump insn = is_uncond_jump_raw (insn_class insn#rawbytes)

(* Check if an instruction is a conditional jump *)
let is_cond_jump_raw itype =
  match itype  with
    | M_JO | M_JNO | M_JB | M_JAE | M_JE | M_JNE | M_JBE | M_JA
    | M_JS | M_JNS | M_JP | M_JNP | M_JL | M_JGE | M_JLE | M_JG
    | M_JZ | M_JNZ | M_JNB | M_JNBE | M_JNL | M_JNLE -> true
    | _ -> false
let is_cond_jump insn = is_cond_jump_raw (insn_class insn#rawbytes)

(* Check if an instruction is an indirect jump *)
let is_ind_jump_raw itype =
  match itype  with
    M_IJMP -> true
    | _ -> false
let is_ind_jump insn = is_ind_jump_raw (insn_class insn#rawbytes)

(* Check if an instruction is an indirect call *)
let is_ind_call_raw itype =
  match itype  with
    M_ICALL -> true
    | _ -> false
let is_ind_call insn = is_ind_call_raw (insn_class insn#rawbytes)

(* Check if an instruction is a push *)
let is_push_raw itype =
  match itype  with
    | M_PUSH | M_PUSHA | M_PUSHF -> true
    | _ -> false
let is_push insn = is_push_raw (insn_class insn#rawbytes)

(* Check if an instruction is a comparison:
    cmp, cmps, sub, xor, scas OR
    test with identical operands *)
let is_comparison insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      (* Comparison instructios *)
      M_CMP | M_CMPS | M_SUB | M_SCAS -> true
      (* XOR with identical operands IS NOT a comparison *)
      | M_XOR when (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr) -> false
      (* XOR with 0xff is a negation, NOT a comparison *)
      | M_XOR when (is_xor_with_minus_one insn) -> false
      (* Otherwise XOR IS a comparison *)
      | M_XOR -> true
      (* TEST insn with identical operands IS a comparison *)
      | M_TEST -> (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr)
      (* All others are not comparisons *)
      | _ -> false

(* Check if instruction is system call *)
let is_system_call insn =
  let op0 = int_of_char insn#rawbytes.(0) in
  let op1 = int_of_char insn#rawbytes.(1) in
  (* sysenter *)
  if ((op0 = 0xf) && (op1 = 0x34)) then true
  (* int 2e *)
  else if ((op0 = 0xcd) && (op1 = 0x2e)) then true
  (* int 80 *)
  else if ((op0 = 0xcd) && (op1 = 0x80)) then true
  else false

(* Check if it is an XCHG instruction *)
let is_xchg_raw itype =
  match itype  with
    | M_XCHG -> true
    | _ -> false
let is_xchg insn = is_xchg_raw (insn_class insn#rawbytes)

(* Check if it is a BSWAP instruction *)
let is_bswap_raw itype =
  match itype  with
    | M_BSWAP -> true
    | _ -> false
let is_bswap insn = is_bswap_raw (insn_class insn#rawbytes)

(* Check if an instruction performs arithmetic operations *)
let is_arithmetic_raw itype =
  match itype  with
    (* Addition *)
    | M_ADD | M_ADC | M_INC
    (* Substraction *)
    | M_SBB | M_SUB | M_DEC
    (* Multiplication *)
    | M_MUL | M_IMUL
    (* Division *)
    | M_DIV | M_IDIV
    (* LEA *)
    | M_LEA -> true
    (* All others are not *)
    | _ -> false
let is_arithmetic insn = is_arithmetic_raw (insn_class insn#rawbytes)

(* Check if an instruction performs bitwise operations *)
let is_bitwise_raw itype =
  match itype  with
    (* Arithmetic *)
    | M_OR | M_AND | M_XOR | M_NOT | M_NEG
    (* Shifts *)
    | M_ROL | M_ROR | M_RCL | M_RCR
    | M_SHL | M_SHR | M_SAL | M_SAR -> true
    (* All others are not *)
    | _ -> false
let is_bitwise insn = is_bitwise_raw (insn_class insn#rawbytes)


(* Returns true if instruction sets EFLAGS.
    Ignores floating point instructions and FPU flags
    CALL / RET / INT / IRET instructiona ignored as well *)
let sets_eflags_raw itype =
  match itype  with
    | M_AAA | M_AAD | M_AAM | M_AAS | M_ADC | M_ADD | M_AND
    | M_ARPL | M_CLC | M_CLD | M_CLI | M_CMC | M_CMP
    | M_CMPS | M_DAA | M_DAS | M_DEC | M_IMUL | M_INC
    | M_MUL | M_NEG | M_OR | M_POPF | M_RCL | M_RCR | M_ROL
    | M_ROR | M_SAHF | M_SAL | M_SAR | M_SHL | M_SHR | M_SBB
    | M_SCAS | M_STC | M_STD | M_STI | M_SUB | M_TEST | M_XOR
      -> true
    (* Unsupported instructions that also modify EFLAGS
    | M_BSF | M_BSR | M_BT | M_BTC | M_BTR | M_BTS | M_CMPXCHG
    | M_LAR | M_LSL | M_RSM | M_SHLD | M_SHRD | M_SYSCALL
    | M_SYSENTER | M_SYSRET | M_VERR | M_XADD *)
    | _ -> false
let sets_eflags insn = sets_eflags_raw (insn_class insn#rawbytes)

(* Check if an isntruction generates a constant output *)
let generates_constant_output insn =
  (is_xor_identical insn) ||
  (is_sub_identical insn) ||
  (is_and_with_zero_imm insn) ||
  (is_or_with_minus_one_imm insn)

(* Check if an instruction is a "mov %esp, %ebp" *)
let is_mov_esp_ebp insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      | M_MOV ->
            let is_esp_read op =
              (op#optype = Temu_trace.TRegister) && (op#opaddr = 136L) &&
              (op#opaccess = Temu_trace.A_R)
            in
            let is_ebp_written op =
              (op#optype = Temu_trace.TRegister) && (op#opaddr = 137L) &&
              (op#opaccess = Temu_trace.A_W)
            in
            let process_op (f1,f2) op =
              if (is_esp_read op) then (true,f2)
	      else if (is_ebp_written op) then (f1,true)
              else (f1,f2)
            in
            let (f1,f2) =
	      Array.fold_left process_op (false,false) insn#operand
	    in
            (f1 && f2)
      | _ -> false

(* Check if an instruction is a no-op
   Any instruction without side effects can be used as no-op
   They are not standardize
   This function is based on the ones used by GAS for padding/alignment 
   This can be encoded using mnemonics but the LEA versions are tricky
*)
let is_nop insn =
  let itype = insn_class insn#rawbytes in
    match itype  with
      | M_NOP -> true
      | M_MOV -> 
          (insn#operand.(0)#opaddr = insn#operand.(1)#opaddr)
      | _ -> false

(* Similar to is_nop but on rawbytes. Not exported *)
let is_nop_rb insn =
  let rb_arr = Array.sub insn#rawbytes 0 insn#inst_size in
  let rb_l = 
    Array.to_list (Array.map (fun x -> Char.code x) rb_arr) 
  in
  match rb_l with
        (* 1 byte *)
    (* nop *) (* GAS *)
    | [0x90]
        (* 2 bytes *)
    (* nop *) (* GAS *)
    | [0x66;0x90]
    (* movl %esi,%esi *) (* GAS *)
    | [0x89;0xf6]
    (* movl %edi,%edi *)
    | [0x89;0xff]
    (* movl %eax,%eax *)
    | [0x89;0xc0]
    (* movl %ebx,%ebx *)
    | [0x89;0xdb]
    (* movl %ecx,%ecx *)
    | [0x89;0xc9]
    (* movl %edx,%edx *)
    | [0x89;0xd2]
    (* movl %esp,%esp *)
    | [0x89;0xe4]
    (* movl %ebp,%ebp *)
    | [0x89;0xed]
        (* 3 bytes *)
    (* leal 0(%esi),%esi  *) (* GAS *)
    | [0x8d;0x76;0x00]
    (* nopl (%[re]ax) *) (* GAS *)
    | [0x0f;0x1f; 0x00]
        (* 4 bytes *)
    (* leal 0(%esi,1),%esi  *) (* GAS *)
    | [0x8d;0x74;0x26;0x00]
    (* nopl 0(%[re]ax) *) (* GAS *)
    | [0x0f;0x1f;0x40;0x00]
        (* 5 bytes *)
    (* nopl 0(%[re]ax,%[re]ax,1) *) (* GAS *)
    | [0x0f;0x1f;0x44;0x00;0x00]
        (* 6 bytes *)
    (* leal 0L(%esi),%esi *) (* GAS *)
    | [0x8d;0xb6;0x00;0x00;0x00;0x00]
    (* leal 0L(%edi),%edi *) (* GAS *)
    | [0x8d;0xbf;0x00;0x00;0x00;0x00]
    (* nopw 0(%[re]ax,%[re]ax,1) *) (* GAS *)
    | [0x66;0x0f;0x1f;0x44;0x00;0x00]
        (* 7 bytes *)
    (* leal 0L(%esi,1),%esi *) (* GAS *)
    | [0x8d;0xb4;0x26;0x00;0x00;0x00;0x00]
    (* leal 0L(%edi,1),%edi *) (* GAS *)
    | [0x8d;0xbc;0x27;0x00;0x00;0x00;0x00]
    (* nopl 0L(%[re]ax) *) (* GAS *)
    | [0x0f;0x1f;0x80;0x00;0x00;0x00;0x00]
        (* 8 bytes *)
    (* nopl 0L(%[re]ax,%[re]ax,1) *) (* GAS *)
    | [0x0f;0x1f;0x84;0x00;0x00;0x00;0x00;0x00]
        (* 9 bytes *)
    (* nopw 0L(%[re]ax,%[re]ax,1) *) (* GAS *)
    | [0x66;0x0f;0x1f;0x84;0x00;0x00;0x00;0x00;0x00]
        (* 10 bytes *)
    (* nopw %cs:0L(%[re]ax,%[re]ax,1) *) (* GAS *)
    | [0x66;0x2e;0x0f;0x1f;0x84;0x00;0x00;0x00;0x00;0x00] -> true
    (* Other *)
    | _ -> false

