(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)

module V = Vine

open Exec_utils
open Exec_exceptions
open Frag_simplify
open Formula_manager

module SymbolicDomain : Exec_domain.DOMAIN = struct
  type t = V.exp

  let from_concrete_1 v  = assert(v = 0 || v = 1 || v = -1);    
    V.Constant(V.Int(V.REG_1,  (Int64.of_int (v land 1))))
  let from_concrete_8 v  = assert(v >= -128 && v <= 0xff);
    V.Constant(V.Int(V.REG_8,  (Int64.of_int (v land 0xff))))
  let from_concrete_16 v = assert(v >= -65536 && v <= 0xffff);
    V.Constant(V.Int(V.REG_16, (Int64.of_int (v land 0xffff))))
  let from_concrete_32 v = assert(v >= -4294967296L && v <= 0xffffffffL);
    V.Constant(V.Int(V.REG_32, (Int64.logand v 0xffffffffL)))
  let from_concrete_64 v = V.Constant(V.Int(V.REG_64, v))

  let to_concrete_1 e = match constant_fold_rec e with
    | V.Constant(V.Int(V.REG_1,  v)) -> (Int64.to_int v)
    | V.Constant(V.Int(_,  v)) -> failwith "bad type in to_concrete_1"
    | _ -> raise (NotConcrete e)

  let to_concrete_8 e = match constant_fold_rec e with
    | V.Constant(V.Int(V.REG_8,  v)) -> (Int64.to_int v)
    | V.Constant(V.Int(_,  v)) -> failwith "bad type in to_concrete_8"
    | _ -> raise (NotConcrete e)

  let to_concrete_16 e = match constant_fold_rec e with
    | V.Constant(V.Int(V.REG_16, v)) -> (Int64.to_int v)
    | V.Constant(V.Int(_,  v)) -> failwith "bad type in to_concrete_16"
    | _ -> raise (NotConcrete e)

  let to_concrete_32 e = match constant_fold_rec e with
    | V.Constant(V.Int(V.REG_32, v)) -> v
    | V.Constant(V.Int(_,  v)) -> failwith "bad type in to_concrete_32"
    | _ -> raise (NotConcrete e)

  let to_concrete_64 e = match constant_fold_rec e with
    | V.Constant(V.Int(V.REG_64, v)) -> v
    | V.Constant(V.Int(_,  v)) -> failwith "bad type in to_concrete_64"
    | _ -> raise (NotConcrete e)

  let to_symbolic_1  e = e
  let to_symbolic_8  e = e
  let to_symbolic_16 e = e
  let to_symbolic_32 e = e
  let to_symbolic_64 e = e

  let from_symbolic e = e

  let inside_symbolic fn e = (fn e)

  let measure_size e = expr_size e

  let make_extract t which e =
    V.Cast(V.CAST_LOW, t, 
	   V.BinOp(V.RSHIFT, e,
		   V.Constant(V.Int(V.REG_8,
				    (Int64.mul 8L (Int64.of_int which))))))
      
  let extract_8_from_64 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_64)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_8))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_8, e)
	    | 7 -> V.Cast(V.CAST_HIGH, V.REG_8, e)
	    | _ -> make_extract V.REG_8 which e

  let extract_8_from_32 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_32)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_8))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_8, e)
	    | 3 -> V.Cast(V.CAST_HIGH, V.REG_8, e)
	    | _ -> make_extract V.REG_8 which e

  let extract_8_from_16 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_16)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_8))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_8, e)
	    | 1 -> V.Cast(V.CAST_HIGH, V.REG_8, e)
	    | _ -> failwith "bad which in extract_8_from_16"
		
  let extract_16_from_64 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_64)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_16))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_16, e)
	    | 6 -> V.Cast(V.CAST_HIGH, V.REG_16, e)
	    | _ -> make_extract V.REG_16 which e

  let extract_16_from_32 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_32)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_16))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_16, e)
	    | 2 -> V.Cast(V.CAST_HIGH, V.REG_16, e)
	    | _ -> failwith "bad which in extract_16_from_32"

  let extract_32_from_64 e which =
    match e with
      | V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr)), V.REG_64)) ->
	  let addr' = Int64.add addr (Int64.of_int which) in
	    V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr')), V.REG_32))
      | _ ->
	  match which with
	    | 0 -> V.Cast(V.CAST_LOW, V.REG_32, e)
	    | 4 -> V.Cast(V.CAST_HIGH, V.REG_32, e)
	    | _ -> failwith "bad which in extract_32_from_64"

  let assemble16 e e2 =
    V.BinOp(V.BITOR,
	    V.Cast(V.CAST_UNSIGNED, V.REG_16, e),
	    V.BinOp(V.LSHIFT,
		    V.Cast(V.CAST_UNSIGNED, V.REG_16, e2),
		    (from_concrete_8 8)))
  let assemble32 e e2 =
    V.BinOp(V.BITOR,
	    V.Cast(V.CAST_UNSIGNED, V.REG_32, e),
	    V.BinOp(V.LSHIFT,
		    V.Cast(V.CAST_UNSIGNED, V.REG_32, e2),
		    (from_concrete_8 16)))

  let assemble64 e e2 =
    V.BinOp(V.BITOR,
	    V.Cast(V.CAST_UNSIGNED, V.REG_64, e),
	    V.BinOp(V.LSHIFT,
		    V.Cast(V.CAST_UNSIGNED, V.REG_64, e2),
		    (from_concrete_8 32)))

  let reassemble16 e e2 =
    match (e, e2) with
      | (V.Constant(V.Int(V.REG_8, v1)), V.Constant(V.Int(V.REG_8, v2)))
	-> constant_fold_rec (assemble16 e e2)
      | (V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_8)),
	 V.Lval(V.Mem(v2, V.Constant(V.Int(V.REG_32, addr2)), V.REG_8)))
	  when v1 = v2 && (Int64.sub addr2 addr1) = 1L
	    ->
	  V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_16))
      | _ -> assemble16 e e2

  let reassemble32 e e2 =
    match (e, e2) with
      | (V.Constant(V.Int(V.REG_16, v1)), V.Constant(V.Int(V.REG_16, v2)))
	-> constant_fold_rec (assemble32 e e2)
      | (V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_16)),
	 V.Lval(V.Mem(v2, V.Constant(V.Int(V.REG_32, addr2)), V.REG_16)))
	  when v1 = v2 && (Int64.sub addr2 addr1) = 2L
	    ->
	  V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_32))
      | _ -> assemble32 e e2

  let reassemble64 e e2 =
    match (e, e2) with
      | (V.Constant(V.Int(V.REG_32, v1)), V.Constant(V.Int(V.REG_32, v2)))
	-> constant_fold_rec (assemble64 e e2)
      | (V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_32)),
	 V.Lval(V.Mem(v2, V.Constant(V.Int(V.REG_32, addr2)), V.REG_32)))
	  when v1 = v2 && (Int64.sub addr2 addr1) = 4L
	    ->
	  V.Lval(V.Mem(v1, V.Constant(V.Int(V.REG_32, addr1)), V.REG_64))
      | _ -> assemble64 e e2

  let to_string e = V.exp_to_string e
  let to_string_1  = to_string
  let to_string_8  = to_string
  let to_string_16 = to_string
  let to_string_32 = to_string
  let to_string_64 = to_string

  let uninit = V.Unknown("uninit")

  let binop op e e2 = V.BinOp(op, e, e2)

  let plus1  = binop V.PLUS
  let plus8  = binop V.PLUS
  let plus16 = binop V.PLUS
  let plus32 = binop V.PLUS
  let plus64 = binop V.PLUS

  let minus1  = binop V.MINUS
  let minus8  = binop V.MINUS
  let minus16 = binop V.MINUS
  let minus32 = binop V.MINUS
  let minus64 = binop V.MINUS

  let times1  = binop V.TIMES
  let times8  = binop V.TIMES
  let times16 = binop V.TIMES
  let times32 = binop V.TIMES
  let times64 = binop V.TIMES

  let binop_zero_check op e e2 =
    let e2' = constant_fold_rec e2 in
    match e2' with
      | V.Constant(V.Int(ty, zero))
	  when (ty = V.REG_64 && zero = 0L) ||
	    (ty = V.REG_32 && (fix_u32 zero) = 0L) ||
	    (ty = V.REG_16 && (fix_u16 zero) = 0L) ||
	    (ty = V.REG_8  && (fix_u8  zero) = 0L) ||
	    (ty = V.REG_1  && (fix_u1  zero) = 0L)
	    -> raise DivideByZero
      | _ -> binop op e e2'

  let divide1  = binop_zero_check V.DIVIDE
  let divide8  = binop_zero_check V.DIVIDE
  let divide16 = binop_zero_check V.DIVIDE
  let divide32 = binop_zero_check V.DIVIDE
  let divide64 = binop_zero_check V.DIVIDE

  let sdivide1  = binop_zero_check V.SDIVIDE
  let sdivide8  = binop_zero_check V.SDIVIDE
  let sdivide16 = binop_zero_check V.SDIVIDE
  let sdivide32 = binop_zero_check V.SDIVIDE
  let sdivide64 = binop_zero_check V.SDIVIDE

  let mod1  = binop_zero_check V.MOD
  let mod8  = binop_zero_check V.MOD
  let mod16 = binop_zero_check V.MOD
  let mod32 = binop_zero_check V.MOD
  let mod64 = binop_zero_check V.MOD

  let smod1  = binop_zero_check V.SMOD
  let smod8  = binop_zero_check V.SMOD
  let smod16 = binop_zero_check V.SMOD
  let smod32 = binop_zero_check V.SMOD
  let smod64 = binop_zero_check V.SMOD

  let lshift1  = binop V.LSHIFT
  let lshift8  = binop V.LSHIFT
  let lshift16 = binop V.LSHIFT
  let lshift32 = binop V.LSHIFT
  let lshift64 = binop V.LSHIFT

  let rshift1  = binop V.RSHIFT
  let rshift8  = binop V.RSHIFT
  let rshift16 = binop V.RSHIFT
  let rshift32 = binop V.RSHIFT
  let rshift64 = binop V.RSHIFT

  let arshift1  = binop V.ARSHIFT
  let arshift8  = binop V.ARSHIFT
  let arshift16 = binop V.ARSHIFT
  let arshift32 = binop V.ARSHIFT
  let arshift64 = binop V.ARSHIFT

  let bitand1  = binop V.BITAND
  let bitand8  = binop V.BITAND
  let bitand16 = binop V.BITAND
  let bitand32 = binop V.BITAND
  let bitand64 = binop V.BITAND

  let bitor1  = binop V.BITOR
  let bitor8  = binop V.BITOR
  let bitor16 = binop V.BITOR
  let bitor32 = binop V.BITOR
  let bitor64 = binop V.BITOR

  let xor1  = binop V.XOR
  let xor8  = binop V.XOR
  let xor16 = binop V.XOR
  let xor32 = binop V.XOR
  let xor64 = binop V.XOR

  let eq1  = binop V.EQ
  let eq8  = binop V.EQ
  let eq16 = binop V.EQ
  let eq32 = binop V.EQ
  let eq64 = binop V.EQ

  let neq1  = binop V.NEQ
  let neq8  = binop V.NEQ
  let neq16 = binop V.NEQ
  let neq32 = binop V.NEQ
  let neq64 = binop V.NEQ

  let lt1  = binop V.LT
  let lt8  = binop V.LT
  let lt16 = binop V.LT
  let lt32 = binop V.LT
  let lt64 = binop V.LT

  let le1  = binop V.LE
  let le8  = binop V.LE
  let le16 = binop V.LE
  let le32 = binop V.LE
  let le64 = binop V.LE

  let slt1  = binop V.SLT
  let slt8  = binop V.SLT
  let slt16 = binop V.SLT
  let slt32 = binop V.SLT
  let slt64 = binop V.SLT

  let sle1  = binop V.SLE
  let sle8  = binop V.SLE
  let sle16 = binop V.SLE
  let sle32 = binop V.SLE
  let sle64 = binop V.SLE

  let unop op e = V.UnOp(op, e)

  let neg1  = unop V.NEG
  let neg8  = unop V.NEG
  let neg16 = unop V.NEG
  let neg32 = unop V.NEG
  let neg64 = unop V.NEG

  let not1  = unop V.NOT
  let not8  = unop V.NOT
  let not16 = unop V.NOT
  let not32 = unop V.NOT
  let not64 = unop V.NOT

  let cast kind ty e = V.Cast(kind, ty, e)

  let cast1u8   = cast V.CAST_UNSIGNED V.REG_8 
  let cast1u16  = cast V.CAST_UNSIGNED V.REG_16
  let cast1u32  = cast V.CAST_UNSIGNED V.REG_32
  let cast1u64  = cast V.CAST_UNSIGNED V.REG_64
  let cast8u16  = cast V.CAST_UNSIGNED V.REG_16
  let cast8u32  = cast V.CAST_UNSIGNED V.REG_32
  let cast8u64  = cast V.CAST_UNSIGNED V.REG_64
  let cast16u32 = cast V.CAST_UNSIGNED V.REG_32
  let cast16u64 = cast V.CAST_UNSIGNED V.REG_64
  let cast32u64 = cast V.CAST_UNSIGNED V.REG_64

  let cast1s8   = cast V.CAST_SIGNED V.REG_8
  let cast1s16  = cast V.CAST_SIGNED V.REG_16
  let cast1s32  = cast V.CAST_SIGNED V.REG_32
  let cast1s64  = cast V.CAST_SIGNED V.REG_64
  let cast8s16  = cast V.CAST_SIGNED V.REG_16
  let cast8s32  = cast V.CAST_SIGNED V.REG_32
  let cast8s64  = cast V.CAST_SIGNED V.REG_64
  let cast16s32 = cast V.CAST_SIGNED V.REG_32
  let cast16s64 = cast V.CAST_SIGNED V.REG_64
  let cast32s64 = cast V.CAST_SIGNED V.REG_64

  let cast8l1   = cast V.CAST_LOW V.REG_1 
  let cast16l1  = cast V.CAST_LOW V.REG_1 
  let cast32l1  = cast V.CAST_LOW V.REG_1 
  let cast64l1  = cast V.CAST_LOW V.REG_1 
  let cast16l8  = cast V.CAST_LOW V.REG_8 
  let cast32l8  = cast V.CAST_LOW V.REG_8 
  let cast64l8  = cast V.CAST_LOW V.REG_8 
  let cast32l16 = cast V.CAST_LOW V.REG_16
  let cast64l16 = cast V.CAST_LOW V.REG_16
  let cast64l32 = cast V.CAST_LOW V.REG_32

  let cast8h1   = cast V.CAST_HIGH V.REG_1 
  let cast16h1  = cast V.CAST_HIGH V.REG_1 
  let cast32h1  = cast V.CAST_HIGH V.REG_1 
  let cast64h1  = cast V.CAST_HIGH V.REG_1 
  let cast16h8  = cast V.CAST_HIGH V.REG_8 
  let cast32h8  = cast V.CAST_HIGH V.REG_8 
  let cast64h8  = cast V.CAST_HIGH V.REG_8 
  let cast32h16 = cast V.CAST_HIGH V.REG_16
  let cast64h16 = cast V.CAST_HIGH V.REG_16
  let cast64h32 = cast V.CAST_HIGH V.REG_32

  let get_tag v = 0L
end
