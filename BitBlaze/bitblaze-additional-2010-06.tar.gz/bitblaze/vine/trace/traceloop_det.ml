(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Driver to extract message format from a trace
*)


module Trace = Temu_trace
open Trace_loops
open Trace_loops_static
open Trace_loops_dynamic
module D = Debug.Make(struct let name = "traceloop_det" and default=`NoDebug end)

type cmdlineargs_t = {
  mutable in_trace_filename : string;
  mutable in_ir_filename : string;
  mutable in_loop_filename : string;
  mutable in_db_filename : string;
  mutable in_addr : int64;
  mutable in_modname : string;
  mutable in_ijmptargets : string;
  mutable out_filename : string;
  mutable out_marshal : string;
  mutable get_dynamic_loops : bool;
  mutable get_static_loops : bool;
  mutable gen_loop_file : bool;
  mutable ignore_rep_loops : bool;
  mutable verbose : bool;
  mutable start_ctr : int64;
  mutable end_ctr : int64;
} ;;

(* Parse the command line arguments *)
let parse_cmdline =
  let cmdlineargs = {
    get_dynamic_loops = false;
    get_static_loops = false;
    gen_loop_file = false;
    ignore_rep_loops = false;
    in_trace_filename = "";
    in_ir_filename = "";
    in_db_filename = "";
    in_loop_filename = "";
    in_addr = Int64.minus_one;
    in_modname = "";
    in_ijmptargets = "";
    out_filename = "";
    out_marshal = "";
    verbose = false;
    start_ctr = 1L;
    end_ctr = Int64.max_int;
  } in
  let usage = "USAGE: Check ./extract_format -h" in
  let set_det_method s = 
    match s with
      | "static" -> cmdlineargs.get_static_loops <- true
      | "dynamic" -> cmdlineargs.get_dynamic_loops <- true
      | _ -> failwith "Unknown detection method. Use <static|dynamic>"
  in
  let set_start_ctr s =
    try cmdlineargs.start_ctr <- Int64.of_string s
    with _ -> (
      Printf.fprintf stderr "Invalid instruction number\n%!";
      exit 1
    )
  in
  let set_end_ctr s =
    try cmdlineargs.end_ctr <- Int64.of_string s
    with _ -> (
      Printf.fprintf stderr "Invalid instruction number\n%!";
      exit 1
    )
  in
  let ignore_arg x = () in
  let rec arg_spec =
    ("-addr", Arg.String (fun s -> cmdlineargs.in_addr <- Int64.of_string s),
      "<address> Module's load address. Used with '-genloopfile'")
    ::("-db", Arg.String (fun s -> cmdlineargs.in_db_filename <- s),
      "<db_filename> Input DB file. Used with '-genloopfile'") 
    ::("-det", Arg.String set_det_method,
      "<static|dynamic> Loop detection method to be used") 
    ::("-ir", Arg.String (fun s -> cmdlineargs.in_ir_filename <- s),
      "<ir_filename> Module's IR file")
    ::("-first", Arg.String set_start_ctr,
        "<int> Start instruction number")
    ::("-last", Arg.String set_end_ctr,
        "<int> End instruction number")
    ::("-genloopfile", Arg.Unit (fun b -> cmdlineargs.gen_loop_file <- true),
      "<> Generate a loop file for given IR file")
    ::("-loopfile", Arg.String (fun s -> cmdlineargs.in_loop_filename <- s),
      "<loop_filename> Input loop file. Use with '-loops'")
    ::("-modname", Arg.String (fun s -> cmdlineargs.in_modname <- s),
      "<string> Name of module")
    ::("-ijmps", Arg.String (fun s -> cmdlineargs.in_ijmptargets <- s),
      "<ijmp_filename> File containing a list of indirect jump edges")
    ::("-no-reps", Arg.Unit (fun b -> cmdlineargs.ignore_rep_loops <- true),
      "<> Use with '-loops' to ignore rep type loops")
    ::("-o", Arg.String (fun s -> cmdlineargs.out_filename <- s),
      "<filename> Output file")
    ::("-marshal_out", Arg.String (fun s -> cmdlineargs.out_marshal <- s),
      "<filename> Output marshal loop file")
    ::("-trace", Arg.String (fun s -> cmdlineargs.in_trace_filename <- s),
      "<trace_filename> Trace to extract format or loops")
    ::("-v", Arg.Unit (fun () -> cmdlineargs.verbose <- true),
      "<> Print more loop info")
    ::[]
  in
  let _ = Arg.parse arg_spec ignore_arg usage in
  cmdlineargs
;;

(* main *)
let main () = 
  (* Parse arguments *)
  let args = parse_cmdline in

  (* Initialize function log ouput stream if needed *)
  let out_oc =
    if (args.out_filename <> "")
    then
      try open_out args.out_filename with _ -> stdout
    else
      stdout
  in

  (* Some parameter checks *)
  let has_modname = args.in_modname <> "" in
(*  let has_trace = args.in_trace_filename <> "" in *)
  let has_ir = args.in_ir_filename <> "" in
(*  let has_load_address_source = 
    (args.in_addr <> Int64.minus_one) || (args.in_db_filename <> "")
in *)

  (* Extract loops from trace using dynamic method *)
  if (args.get_dynamic_loops) then (
    D.dprintf "Extracting loops from trace <%s> into <%s>" 
      args.in_trace_filename args.out_filename;

    (* Extract loops *)
    let loop_l = 
      extract_dynloops_from_trace ~ignore_reps:args.ignore_rep_loops 
        ~first_ctr:args.start_ctr ~last_ctr:args.end_ctr
	args.in_trace_filename 
    in

    (* Print loops *)
    print_loops ~print_iters:args.verbose out_oc loop_l;

    if args.out_marshal <> "" then
      Trace_loops.serialize_loops args.out_marshal loop_l;

    exit 0;
  );

  (* Generate loop file from IR *)
  if (args.gen_loop_file) then (
    (* Get load address from DB or command line *)
    let load_addr = 
      if (args.in_addr <> Int64.minus_one) 
	then args.in_addr
	else if (args.in_db_filename <> "") 
	  then (get_mod_load_addr_from_db args.in_db_filename)
	  else failwith ("Need to provide module's load address using " ^ 
	    "'-addr <eip>' or '-db <db_filename>' options")
    in 
    D.dprintf "Module load addr: 0x%08Lx" load_addr; 

    if ((not has_ir) || (not has_modname)) 
      then failwith "Need to provide IR and module name";

    (* Get a list of indirect jumps edges *)
    let ijmps =
      if (args.in_ijmptargets <> "") then
	read_ijmps_from_file args.in_ijmptargets
      else []
    in

    (* Get loops from IR file *)
    D.dprintf "Module name: %s" args.in_modname;
    D.dprintf "IR: %s" args.in_ir_filename;
    let loop_info_l = 
      get_loop_info_from_ir ~ijmps:ijmps 
	load_addr args.in_modname args.in_ir_filename
    in

    (* Print loops *)
    let num_loops = List.length loop_info_l in
    D.dprintf "Number of loops in file %s is %d\n" 
      args.in_ir_filename num_loops;

    (* Write loop file *)
(*
    let out_file = "tmp.loops" in
    let oc = open_out out_file in
*)
    List.iter (fun x -> print_loop_info out_oc x) loop_info_l;
    exit 0
  );

  (* Extract loops from trace using static method. Uses input loop file *)
  if (args.get_static_loops) then (
    (* Read loop info from file *)
    print_endline "Reading loops from file";
    let loop_info_l = read_loop_info_from_file args.in_loop_filename in
    (* D.dprintf "Num loops: %d\n" (List.length loop_info_l); *)
    if (args.in_trace_filename <> "") then (
      D.dprintf "Finding loops in trace: %s\n" args.in_trace_filename;
      let loop_l = 
	extract_statloops_from_trace loop_info_l args.in_trace_filename 
      in
      print_loops ~print_iters:args.verbose out_oc loop_l;
      
      if args.out_marshal <> "" then
	Trace_loops.serialize_loops args.out_marshal loop_l;
    );
    exit 0
  );

  (* Exit *)
  exit 0;;

  main ();;
