(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(** 
  Filter used by Trace_multiplex to compute the block coverage
*)

open Vine_util
open Insn_classifier
module D =
  Debug.Make(struct let name = "coverage" and default=`NoDebug end)


(* A basic block extracted dynamically *)
type block_t = {
  block_start : Libasmir.address_t;
  block_end : Libasmir.address_t;
}

(* A Set of dynamic basic blocks *)
module BlockSetT =
struct
  type t = block_t
  let compare a b = Pervasives.compare a.block_start b.block_start
end
module BlockSet = Set.Make(BlockSetT)

(* The set of dynamic blocks covered by a trace *)
type trace_covset_t = {
  tcov_name : string;
  tcov_mod_l : Temu_trace.mod_info list;
  tcov_bs : BlockSet.t;
}

(* A coverage context *)
type coverage_context = {
  (* Map of all start of block addresses (EIPs) seen so far *)
  coverage_tbl : (Libasmir.address_t,Libasmir.address_t) Hashtbl.t;
  (* End of block insns set this flag, so that we store info at next insn *)
  mutable found_block_end : bool;
  (* Add only instruction that satisfy this predicate to the coverage tbl *)
  mutable add_insn : Temu_trace.instruction -> int64 -> bool;
  (* Start address of current block *)
  mutable block_start_addr : Libasmir.address_t;
}

(* Compare two trace_covset using the number of blocks *)
let compare_tcov a b = 
  Pervasives.compare (BlockSet.cardinal b.tcov_bs) (BlockSet.cardinal a.tcov_bs)

(* Check if an instruction marks the end of a basic block *)   
let is_end_of_block insn =
  is_call insn || is_ret insn || is_uncond_jump insn || is_cond_jump insn ||
  is_system_call insn

(* Extrace module map from trace *)
let get_mod_map_from_trace trace_filename =
  let ti = Temu_trace.open_trace trace_filename in
  let module_base_map = Hashtbl.create 10 in
  let procs = ti#processes in
  let num_procs = List.length procs in
  let _ =
    if (num_procs > 1)
    then failwith "More than one process in trace. Exiting...";
  in
  let proc =
    try List.hd procs
    with _ -> failwith "No processes in trace. Exiting..."
  in
  (* Printf.printf "Process: %s PID: %d\n%!" proc#name proc#pid; *)
  let add_module curr_mod =
    (*  Printf.printf "\t Module: %s @ 0x%08Lx Size: %Ld\n%!" 
        curr_mod#name curr_mod#base curr_mod#size; *)
    Hashtbl.add module_base_map
      curr_mod#name (curr_mod#base,curr_mod#size)
  in
    (* map module info in the reverse order so that it comes in the right
       order when calling with Hashtbl.fold *)
  let _ = List.iter add_module (List.rev proc#modules) in
  let _ = Temu_trace.close_trace ti in
  module_base_map


(* Check if a given instruction belongs to one of the modules in mod_l 
   NOTE: an empty mod_l has special meaning and this function always 
   returns true in that case
*)
let in_selected_modules module_base_map mod_l insn ctr = 
  if (mod_l = []) then true
  else (
    let addr = insn#address in
    let process_mod flag modname = 
      try (
	let (base,size) = Hashtbl.find module_base_map modname in
	(flag || ((addr >= base) && (addr <= (Int64.add base size))))
      )
      with _ -> flag
    in
    List.fold_left process_mod false mod_l
  )

(* Create a coverage_context *)
let create_coverage_ctx ?(add_insn_fun=(fun insn ctr -> true)) size = 
{
  coverage_tbl = Hashtbl.create size;
  found_block_end = true;
  add_insn = add_insn_fun;
  block_start_addr = 0L;
}

(* Extract list of blocks from coverage context *)
let get_blocks_from_cov_ctx ctx = 
  Hashtbl.fold 
    (fun bs be acc -> { block_start=bs; block_end=be; } :: acc) 
    ctx.coverage_tbl []

(* Read module list from trace *)
let read_module_list trace_filepath =
  let tif = Temu_trace.open_trace trace_filepath in
  let proc = List.hd tif#processes in
  let () = Temu_trace.close_trace tif in
  List.rev proc#modules


(* Print list of blocks *)
let print_block_list block_l = 
  List.iter 
    (fun bl -> Printf.printf "0x%08Lx -> 0x%08Lx\n" bl.block_start bl.block_end)
    block_l

(* Print module list *)
let print_module_list oc mod_l = 
  let print_module curr_mod =
    Printf.fprintf oc "\t Module: %s @ 0x%08Lx Size: %Ld\n%!"
      curr_mod#name curr_mod#base curr_mod#size
  in
  List.iter print_module mod_l

(* Check an instruction, if first of block then add address to map *)
let tfold_add_insn_block_to_ctx ctx insn insn_ctr = 
  if ((ctx.found_block_end) && (ctx.add_insn insn insn_ctr)) then (
    ctx.found_block_end <- false;
    ctx.block_start_addr <- insn#address;
  );
  if (is_end_of_block insn) then (
    ctx.found_block_end <- true;
    let end_addr = 
      Int64.pred (Int64.add insn#address (Int64.of_int insn#inst_size)) 
    in
    if (ctx.block_start_addr <> 0L) then
      Hashtbl.replace ctx.coverage_tbl ctx.block_start_addr end_addr;
  );
  ctx

(* Get list of block start addresses present in trace *)
let get_trace_blocks tracename = 
  (* Create coverage context *)
  let cov_ctx = create_coverage_ctx 1000 in
  (* Iterate over trace *)
  let trace = Temu_trace.open_trace tracename in
  let cov_ctx = 
    Temu_trace.trace_fold tfold_add_insn_block_to_ctx cov_ctx trace 
  in
  let _ = Temu_trace.close_trace trace in
  (* Output list of block start addresses *)
  get_blocks_from_cov_ctx cov_ctx

(* Print the list of blocks in a trace to a binary file *)
let trace_blocks_to_file ?(block_l=[]) ?(blocks_filepath="") trace_filepath =
  (* Get module names *)
  let tif = Temu_trace.open_trace trace_filepath in
  let proc = List.hd tif#processes in
  let mod_l = proc#modules in
  let num_modules = List.length mod_l in
  let () = Temu_trace.close_trace tif in
  (* Get trace blocks *)
  let trace_block_l =
    match block_l with
      | [] -> get_trace_blocks trace_filepath
      | _ -> block_l
  in
  (* Output file path *)
  let out_filepath =
    if (blocks_filepath <> "")
      then blocks_filepath
      else (change_ext trace_filepath "blocks")
  in
  (* Output channel *)
  let oc = open_out_bin out_filepath in
  let ioc = IO.output_channel oc in
  (* Output module list *)
  IO.write_i32 ioc num_modules;
  List.iter (fun minfo -> minfo#serialize ioc) mod_l;
  (* Output blocks *)
  let process_addr bl =
    IO.write_real_i32 ioc (Int64.to_int32 bl.block_start);
    IO.write_real_i32 ioc (Int64.to_int32 bl.block_end)
  in
  List.iter process_addr trace_block_l;
  (* Close output channel *)
  IO.close_out ioc

(* Read the list of blocks in a trace to a binary file 
   Returns a (module_list,block_l) pair *)
let trace_blocks_from_file blocks_filepath =
  let rec read_list acc f n =
    match n with
      | 0 -> acc
      | _ -> read_list ((f ()) :: acc) f (n-1)
  in
  let read_module tc =
    let minfo = new Temu_trace.mod_info in
      minfo#unserialize tc; minfo
  in
  (* Get input channel *)
  let ic = open_in_bin blocks_filepath in
  let ioc = IO.input_channel ic in
  (* Read modules *)
  let num_modules = IO.read_i32 ioc in
  let mod_l = List.rev (read_list [] (fun () -> read_module ioc) num_modules) in
  (* Read blocks *)
  let rec read_address acc =
    try (
      let bs = Int64.of_int32 (IO.read_real_i32 ioc) in
      let be = Int64.of_int32 (IO.read_real_i32 ioc) in
      let block = { block_start = bs; block_end = be; } in
      read_address (block :: acc)
    )
    with IO.No_more_input -> acc
  in
  let l = read_address [] in
  let () = IO.close_in ioc in
  (mod_l,List.rev l)

(* Convert a block list into a block set *)
let block_list_to_set block_l = 
  List.fold_left (fun bs b -> BlockSet.add b bs) BlockSet.empty block_l

(* Get a set with all the blocks in the given binary file *)
let trace_coverage_from_file blocks_filepath =
  let (mod_l,block_l) = trace_blocks_from_file blocks_filepath in
  let bs = block_list_to_set block_l in
  { tcov_name = blocks_filepath; tcov_mod_l = mod_l; tcov_bs = bs; }


(* Compute set cover for a list of BlockSet.t using the greedy algorithm
   This algorithm is O(n)
   This corresponds to the SET COVERING 1 algorithm in the following paper: 
    "Approximation algorithms for Combinatorial Problems"
    by David S. Jonhn (MIT), 1974 *)
let get_set_cover tcov_l = 
  (* Uncovered set; Initialized with union of all blocks seen *)
  let uncov = 
    List.fold_left (fun s t -> BlockSet.union s t.tcov_bs) BlockSet.empty tcov_l
  in
  (* Sub; List of inputs in the current cover set; Initialized to empty *)
  let sub = [] in
  (* Apply greedy algorithm *)
  let rec greedy_select uncov sub tc_l = 
    if (BlockSet.is_empty uncov) then sub
    else (
      (* Sort remaining trace coverage sets *)
      let sorted_tc_l = List.sort compare_tcov tc_l in
      (* Select one with largest coverage *)
      match sorted_tc_l with
        | max_tcov :: tl -> (
            (* Remove blocks in selected set from uncovered set *)
            let updated_uncov = BlockSet.diff uncov max_tcov.tcov_bs in
            D.dprintf "Selected set: %s |Uncovered| = %d -> %d%!" 
              max_tcov.tcov_name (BlockSet.cardinal uncov) 
              (BlockSet.cardinal updated_uncov);
            (* Print blocks removed *)
            (* BlockSet.iter 
              (fun b -> D.dprintf "\t0x%08Lx --> 0x%08Lx\n" 
                  b.block_start b.block_end) 
              max_tcov.tcov_bs; *)
            (* Remove blocks in selected set from other sets *)
            let updated_tc_l = 
              let update_tcov t = 
                let bs = BlockSet.diff t.tcov_bs max_tcov.tcov_bs in
                { t with tcov_bs = bs; }
              in
              List.map update_tcov tl
            in
            greedy_select updated_uncov (max_tcov :: sub) updated_tc_l
          )
        | _ -> failwith "get_set_cover: No more sets but uncov not empty"
    )
  in 
  let l = greedy_select uncov sub tcov_l in
  List.rev l

(* Compute set cover for a list of BlockSet.t using the greedy algorithm 
   This algorithm is O(n^2)
   This corresponds to the SET COVERING 2 algorithm in the following paper: 
    "Approximation algorithms for Combinatorial Problems"
    by David S. Jonhn (MIT), 1974 *)
let get_set_cover2 tcov_l = 
  (* Uncovered set; Initialized with union of all blocks seen *)
  let uncov = 
    List.fold_left (fun s t -> BlockSet.union s t.tcov_bs) BlockSet.empty tcov_l
  in
  (* Sub; List of inputs in the current cover set; Initialized to empty *)
  let sub = [] in
  (* Apply greedy algorithm *)
  let rec greedy_select uncov sub tc_l = 
    if (BlockSet.is_empty uncov) then sub
    else (
      (* Compute ratio for remaining trace coverage sets *)
      let ratio s = 
        let numerator = BlockSet.cardinal (BlockSet.diff s uncov) in
        let denominator = BlockSet.cardinal (BlockSet.inter s uncov) in
        if denominator = 0 
          then max_int
          else numerator / denominator
      in
      let pair_l = List.map (fun tc -> (ratio tc.tcov_bs),tc) tc_l in
      (* Sort remaining trace coverage sets according to ratio *)
      let sorted_pair_l = List.sort Pervasives.compare pair_l in
      (* Select one with minimum ratio *)
      match sorted_pair_l with
        | (_,min_ratio_tcov) :: tl -> (
            (* Remove blocks in selected set from uncovered set *)
            let updated_uncov = BlockSet.diff uncov min_ratio_tcov.tcov_bs in
            D.dprintf "Selected set: %s |Uncovered| = %d -> %d%!" 
              min_ratio_tcov.tcov_name (BlockSet.cardinal uncov) 
              (BlockSet.cardinal updated_uncov);
            (* Print blocks removed *)
            (* BlockSet.iter 
              (fun b -> D.dprintf "\t0x%08Lx --> 0x%08Lx\n" 
                  b.block_start b.block_end) 
              min_ratio_tcov.tcov_bs; *)
            let updated_tc_l = List.map snd tl in
            greedy_select updated_uncov (min_ratio_tcov :: sub) updated_tc_l
          )
        | _ -> failwith "get_set_cover: No more sets but uncov not empty"
    )
  in 
  let l = greedy_select uncov sub tcov_l in
  List.rev l

