(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
module type PoolType = 
sig
  val addr : Unix.inet_addr * int
  type t
  val name : string
  val key: t -> int
  val key_name : string
  val compare : t -> t -> int
  val marshal_object : Unix.file_descr -> t -> unit
  val unmarshal_object : Unix.file_descr -> t
  val cond_func : t -> bool
  val reject : t -> bool
  val print : t -> unit
  val should_print : bool
end;;

module Server =
  functor (Pt : PoolType) ->
struct

  module PtOrder =
  struct
    type t = Pt.t
    let compare = Pt.compare
  end;;
  
  module PoolSet = Set.Make(PtOrder);;

  class priority_queue =
  object(self)

    val mutable pool = PoolSet.empty
    val m = Mutex.create ()
    val c = Condition.create ()

    method count () =
	let counter item curr_count =
	    if (Pt.cond_func item) then (curr_count + 1)
	    else curr_count;
	in
	let total = PoolSet.fold counter pool 0 in
	total

    method print () =
	Mutex.lock m;
	Printf.printf "Queue contents: %!";
	PoolSet.iter Pt.print pool;
	Printf.printf "\n%!";
	Mutex.unlock m

    method add i = 
      Mutex.lock m;
      pool <- PoolSet.add i pool;
      Condition.signal c;
      Mutex.unlock m

    method remove i = 
      Mutex.lock m;
      pool <- PoolSet.remove i pool;
      Mutex.unlock m

    method size =
      PoolSet.cardinal pool

    method private wait () =
      Mutex.lock m;
      while (self#size = 0) do Condition.wait c m done;

    method next () =
      self#wait (); 
      let el = PoolSet.max_elt pool in
        pool <- PoolSet.remove el pool;
        Mutex.unlock m;
        el
  end

  let pool_queue = new priority_queue;;

  let handle_get socket run = 
    let _ = Printf.fprintf stderr "%d: GET %s\n%!" run Pt.name in
    let obj = pool_queue#next () in
    let _ = Pt.marshal_object socket obj in
    let _ = Printf.fprintf stderr "%d: GOT %s with %s %d\n%!" run Pt.name Pt.key_name (Pt.key obj) in
    if Pt.should_print then pool_queue#print ();;

  let handle_put socket run =
    let obj = Pt.unmarshal_object socket in
    if not (Pt.reject obj) then begin
	let _ = pool_queue#add obj in 
	Printf.fprintf stderr "%d: PUT %s with %s %d\n%!" run Pt.name Pt.key_name (Pt.key obj);
    end
    else Printf.fprintf stderr "%d: REJECTED PUT %s with %s %d\n%!" run Pt.name Pt.key_name (Pt.key obj);
    if Pt.should_print then pool_queue#print ();;

  let handle_get_size socket run =
    let () = Printf.fprintf stderr "%d: GETSIZE %s\n%!" run Pt.name in
    let size = pool_queue#count () in
    let _ = Netcomm.write_i32 socket size in
    let _ = Printf.fprintf stderr "%d: GETSIZE %s with %d\n%!" run Pt.name size in
      ();;

  let handle_disconnect socket run =
     let () = Unix.close socket in
     let () = Printf.fprintf stderr "%d: DISCONNECT %s %!" run Pt.name in
     ();;

  let handle_connection conn_pair =
    let (socket, num) = conn_pair in
    while true do
    let cmd = Netcomm.read_byte socket in
    let _ = Printf.fprintf stderr "%d: Received command %d\n%!" num cmd in
    match cmd with
	0 -> handle_disconnect socket num
      | 5 -> handle_get socket num
      | 10 -> handle_put socket num
      | 15 -> handle_get_size socket num
      | _ -> Printf.fprintf stderr "%d: Received unrecognized command %d\n%!" num cmd;
    done;;

  let retry_bind server_socket =
      let connected = ref false in
      let numAttempts = ref 0 in
      while not !connected do
        try let _ = Unix.bind server_socket (Unix.ADDR_INET ((fst Pt.addr), (snd Pt.addr))) in
	   connected := true;
	with e ->
	  if !numAttempts < 10 then (
	   numAttempts := !numAttempts + 1;
	   let _ = print_string "Retrying...\n" in
           let _ = flush stdout in
       	   Unix.sleep(5);
	   connected := false;
	   )
	 else raise e
      done;
      Printf.printf "Registering handler...\n%!";
      let handler signal =
          let () = Unix.shutdown server_socket Unix.SHUTDOWN_ALL in
	  let () = Unix.close server_socket in
	  let () = Printf.printf "Exiting!%!" in
	  exit 0
      in
      Sys.set_signal Sys.sigint (Sys.Signal_handle handler);;

  let run_server () =
    let server_socket = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
      let _ = retry_bind server_socket in
      Unix.listen server_socket 10;
      Printf.fprintf stderr "Pool server: %s\n%!" Pt.name;
      let num = ref 0 in
      let accept_connection () =
	while true do
	  begin
            num := !num + 1;
            let (sock, clientaddr) = Unix.accept server_socket in
            let (clientname, port) = match clientaddr with
	      | Unix.ADDR_INET (addr, port) -> (Unix.string_of_inet_addr addr, port)
	      | _ -> assert false
            in
            let _ = Printf.fprintf stderr "%d: Connection from %s:%d [%d objects in pool]\n%!" !num clientname port pool_queue#size in
               let _ = Thread.create handle_connection (sock, !num) in 
           (* let _ = handle_connection (sock, !num) in *)
              ()
	  end
	done
      in
	accept_connection ();
        Printf.fprintf stderr "Exiting [%d objects in pool]\n%!" pool_queue#size;
end;;

