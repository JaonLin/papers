(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
   Common functios used by input generation functionality
*)

open Vine
open Vine_util
open Trace_slice
open Common_utils
module D =
  Debug.Make(struct let name = "inputs" and default=`NoDebug end)

(* Replace substring in message string with new value. *)
(* NOTE: sub_size is the size of the original substring being replaced *)
let replace_substring original_str sub_start sub_size new_sub_value = 
  let originallen = String.length original_str in
  (* Warn if replacing a substring with a chunk of different size *)
  if ((String.length new_sub_value) <> sub_size) then (
    D.wprintf ("Replacing substring of length: %d with chunk of length %d\n" ^^
      " Original_str_len: %d SubStart: %d SubSize: %d SubVal: %s\n%!")
      sub_size (String.length new_sub_value) 
      originallen sub_start sub_size (String.escaped new_sub_value);
  );
  (* Try replacement *)
  try (
    let before = String.sub original_str 0 sub_start in
    let after = String.sub original_str (sub_start+sub_size)
      (originallen-sub_start-sub_size)
    in
    before ^ new_sub_value ^ after
  )
  (* Log and ignore if something goes wrong *)
  with _ -> (
    D.wprintf ("Ignoring incorrect substring replacement." ^^ 
      " Original_str_len: %d SubStart: %d SubSize: %d SubVal: %s\n%!")
      originallen sub_start sub_size (String.escaped new_sub_value);
    original_str
  )

(* Read message from file *)
let read_msg filepath =
  let ic = open_in filepath in
  let inputsize = in_channel_length ic in
  let msg = String.create inputsize in
  let _ = input ic msg 0 inputsize in
  let _ = close_in ic in
  msg
