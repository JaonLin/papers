(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Common types and functions for extracting loops from a trace
    (i.e. from straight line code, where loops are unrolled)

  Currently we have two different methods:

  1) Dynamic method (trace_loop_dynamic.ml)
    Extracts loops directly from the trace without any static information.
    Looks at the value of the EIP to decide if there is a loop.
    This method is superseed by the static method below.

  2) Static method (trace_loop_static.ml)
    Uses the Affine loop extraction mode to find loops in a trace
    It requires: 
      a) identifying all modules (dll and exe files) present in the trace, 
      b) extracting IDAPro DB files for those modules,
      c) generating an IR for those modules,
      d) extracting loops in those IRs
      e) find loops in trace using information from step e)
*)

module Trace = Temu_trace
open Trace
open Insn_classifier
open Vine_util

type loop_t =
  | Pre_tested
  | Post_tested
  | Rep
  | Unknown

type exitcond = {
  ec_addr : int32; (* Address of the exit condition (cjmp) *)
  ec_line : int64; (* Instruction number for exit condition (cjmp) *)
  ec_taint_l : (int32*int) list; (* Taint for exit condition *)
  ec_setflags_addr : int32; (* Address of instruction setting cjmp flags *)
  ec_setflags_line : int64; (* Address of instruction setting cjmp flags *)
}

type loop_iteration = {
  istart : int32;      (* first address in iter. Should be the loop head *)
  mutable iend : int32;        (* backedge address *)
  istart_line : int64;   (* line in trace for istart *) 
  mutable iend_line : int64;     (* line in trace for iend (backedge) *)
  mutable iec_l : exitcond list; (* list of exit conditions in the iteration *)
  mutable itaint_data : (int32*int) list; (* tainted data used in iteration *)
}

type loop = {
  id : int;
  mutable ltype : loop_t; 
  lstart : int32;
  mutable lend : int32;
  mutable num_iter : int;
  lstart_line : int64;
  mutable lend_line : int64;
  mutable iter_list : loop_iteration list;
  mutable nest_depth : int;
  mutable nest_inner : int option;
  mutable nest_outer : int option;
}

type loop_info = {
  module_name : string;
  fun_name : string;
  header_eip : int64;
  exit_edges : (int64*int64) list;
  back_edges : int64 list;
  iv_info_l : (int64*string) list;
}

(* Information per function instance *)
type dynloop_function_info = {
  (* Table containing all EIP seen in function instance 
       EIP -> Instruction counters where EIP appears in function instance *) 
  eip_tbl : (int32, int64) Hashtbl.t;
  (* Last EIP seen in function *)
  mutable last_eip : int32;
  (* Current loop ID for this function instance *)
  mutable curr_loop_id : int;
}

type dynloop_context = {
  (* Loop counter, incremented every time a new loop is created *)
  mutable dc_loop_ctr : int;
  (* Table of all loops indexed by loop ID. ID -> Loop *)
  dc_loop_tbl : (int, loop) Hashtbl.t;
  (* A callstack context *)
  dc_cs_ctx : dynloop_function_info Callstack.callstack_context;
  (* Last instruction executed *)
  mutable dc_last_inst : Trace.instruction option;
  (* Table containing information about each instruction 
      in the function instance.
        Insn_ctr -> (EIP, insn_itype, taint_list) *)
  dc_insn_info_tbl : 
    (int64, (int32 * Insn_classifier.insnMnemonic * (int32*int) list)) 
      Hashtbl.t;
}

type statloop_context = {
  sc_module_map : (string, (int64*int64)) Hashtbl.t;
  sc_entry_map : (int64,loop_info) Hashtbl.t;
  sc_exit_cond_map: (int64,loop_info) Hashtbl.t;
  sc_exit_map: (int64,loop_info) Hashtbl.t;
  sc_iv_map: (int64,loop_info) Hashtbl.t;
  mutable sc_eflags_info : (int32*int64*(int32*int) list);
  mutable sc_loop_idx : int;
  mutable sc_loop_found_l : loop list;
  mutable sc_loop_open_l : loop list;
  mutable sc_curr_loop : loop;
  mutable sc_last_inst : Trace.instruction option;
  mutable sc_last_inst_ctr : int64;
}

let empty_loop = 
  { 
    id = 0;
    ltype = Unknown;
    lstart = 0l;
    lend = 0l;
    num_iter = 0;
    lstart_line = 0L;
    lend_line = 0L;
    iter_list = [];
    nest_depth = 0;
    nest_inner = None;
    nest_outer = None;
  }


(*=========================== globals ========================== *)
  let context_stack_size = 100

(*========================= functions ========================== *)

(* Does the loop handle taint data? *)
let loop_handles_taint loop =
  let iter_pred iter = (List.length iter.itaint_data > 0) in
  List.exists iter_pred loop.iter_list

(* Order loops by size *)
let loop_cmp loop1 loop2 = 
  let size1 = Int64.succ (Int64.sub loop1.lend_line loop1.lstart_line) in
  let size2 = Int64.succ (Int64.sub loop2.lend_line loop2.lstart_line) in
  Pervasives.compare size1 size2

(* Get all loops containing an instruction *)
let get_insn_loops insn_ctr loop_l = 
  List.filter
    (fun l -> (insn_ctr >= l.lstart_line) && (insn_ctr <= l.lend_line))
    (List.sort loop_cmp loop_l)

(* Get the innermost loop containing an instruction *)
let get_insn_inner_loop insn_ctr loop_l = 
  List.find
    (fun l -> (insn_ctr >= l.lstart_line) && (insn_ctr <= l.lend_line))
    (List.sort loop_cmp loop_l)

(* Check if an instruction belongs to a loop *)
let insn_in_loop insn_ctr loop_l =
  List.exists
    (fun l -> (insn_ctr >= l.lstart_line) && (insn_ctr <= l.lend_line))
    loop_l

(* Convert loop type to string *)
let string_of_ltype = function 
  | Pre_tested -> "Pre-tested"
  | Post_tested -> "Post-tested"
  | Rep -> "Rep"
  | Unknown -> "Unknown"

(* Get all taint data accessed by loop *)
let get_taint_in_loop loop = 
  let tmp_tbl = Hashtbl.create (loop.num_iter * 5) in
  let process_iter iter = 
    List.iter (fun pair -> Hashtbl.replace tmp_tbl pair true) iter.itaint_data
  in
  List.iter process_iter loop.iter_list;
  let pair_l = get_hash_keys tmp_tbl in
  let pair_l = List.sort (Pervasives.compare) pair_l in
  pair_l

(* Print a loop iteration *)
let print_iter oc ctr iter = 
  let num_ec = List.length iter.iec_l in
  Printf.fprintf oc ("\tIter: %d Start=0x%08lx (%Ld) End=0x%08lx (%Ld) " ^^ 
    "NumEC: %d\n")
    ctr iter.istart iter.istart_line iter.iend iter.iend_line num_ec;
  (* Print taint data accessed in iteration *)
  if (List.length iter.itaint_data > 0) then (
    Printf.fprintf oc "\t\tTaint: ";
    let print_taint (origin,offset) = 
      Printf.fprintf oc "(%ld,%d) " origin offset;
    in
    List.iter print_taint iter.itaint_data;
    Printf.fprintf oc "\n";
  );
  (* Print exit condition info *)
  let print_ec ec = 
    Printf.fprintf oc "\t\tEC: 0x%08lx (%Ld) Flags: 0x%08lx (%Ld) TAINT: " 
      ec.ec_addr ec.ec_line ec.ec_setflags_addr ec.ec_setflags_line;
    let print_pair pair =
      let (origin,offset) = pair in
      Printf.fprintf oc "(%ld,%d) " origin offset;
    in
    List.iter print_pair ec.ec_taint_l;
    Printf.fprintf oc "\n"
  in
  List.iter print_ec iter.iec_l;
  ctr + 1


(* Print loop *)
let print_loop ?(print_iters=false) oc loop = 
  Printf.fprintf oc "ID: %d\n" loop.id;
  Printf.fprintf oc "\tType: %s\n" (string_of_ltype loop.ltype);
  Printf.fprintf oc "\tStart: %08lx\n" loop.lstart;
  Printf.fprintf oc "\tEnd: %08lx\n" loop.lend;
  Printf.fprintf oc "\tNum_iter: %d\n" loop.num_iter;
  Printf.fprintf oc "\tStartLine: %Ld\n" loop.lstart_line;
  Printf.fprintf oc "\tEndLine: %Ld\n" loop.lend_line;
  Printf.fprintf oc "\tNest_depth: %d\n" loop.nest_depth;
  let inner_str = 
    match loop.nest_inner with
      | Some(d) -> Printf.sprintf "%d" d
      | None -> "none"
  in
  let outer_str = 
    match loop.nest_outer with
      | Some(d) -> Printf.sprintf "%d" d
      | None -> "none"
  in
  Printf.fprintf oc "\tNest_inner: %s\n" inner_str;
  Printf.fprintf oc "\tNest_outer: %s\n" outer_str;
  (* Print loop taint accessed data *)
  let taint_data_l = get_taint_in_loop loop in
  if (List.length taint_data_l > 0) then (
    Printf.fprintf oc "\tTaint:\n";
    let print_pair (origin,offset) = 
      Printf.fprintf oc "\t\t(%ld,%d)\n" origin offset;
    in
    List.iter print_pair taint_data_l;
  );
  (* Print the loop iteration *)
  if (print_iters) 
    then ignore(List.fold_left (print_iter oc) 1 loop.iter_list)
    else ()

(* Print a loop list *)
let print_loops ?(print_iters=false) oc loop_l = 
  List.iter (fun l -> print_loop ~print_iters:print_iters oc l) loop_l

(* Get the type of loop by looking at the last instruction *)
let get_loop_type last_loop_inst = 
  match last_loop_inst with
    Some(inst) -> 
      if (is_rep_insn inst) then Rep
      else if (is_cond_jump inst) then Post_tested
      else if (is_uncond_jump inst) then Pre_tested
      else Unknown
    | None -> Unknown

(* Serialize loop list *)
let serialize_loops filename loop_l =
  let oc =
    try open_out_bin filename
    with _ -> failwith "Could not serialize loop list"
  in
  let _ = Marshal.to_channel oc loop_l [] in
    close_out oc

(* Unserialize loop list *)
let unserialize_loops filename =
  let ic =
    try open_in_bin filename
    with _ -> failwith "Could not unserialize loop list"
  in
  let loop_l = Marshal.from_channel ic in
  let _ = close_in ic in
    loop_l
