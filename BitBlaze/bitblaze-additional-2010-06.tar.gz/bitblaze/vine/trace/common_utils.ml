(*
  Copyright (C) BitBlaze, 2009-2010, and copyright (C) 2010 Ensighta
  Security Inc.  

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)

open Vine
module D = Debug.Make(struct let name = "common_utils" and default=`NoDebug end)

(* Check if expression is boolean *)
let is_bool_exp e =
  match (Vine_typecheck.infer_type None e) with
    | REG_1 -> true
    | _ -> false

(* Determine if a Vine.var is symbolic, i.e. is INPUT *)
let is_input_var vine_var =
  let (_,var_str,var_type) = vine_var in
  if ((String.length var_str) < 5) then false
  (* else (((String.sub var_str 0 5) = "INPUT") && (var_type = REG_8)) *)
  else ((String.sub var_str 0 5) = "INPUT")

(* Get origin and offset from INPUT var *)
let get_info_from_input vine_var =
  let (_,var_str,var_type) = vine_var in
  if (not (is_input_var vine_var)) then (
    D.wprintf "Not an INPUT variable: %s\n"
      (var_to_string vine_var);
    failwith "Exiting...";
  );
    let token_list = Str.split (Str.regexp "_") var_str in
  if (List.length token_list < 3)
  then failwith "INPUT missing origin or offset";
      let (origin_str,offset_str) =
    if ((List.nth token_list 1) = "missed")
    then ((List.nth token_list 2),(List.nth token_list 3))
    else ((List.nth token_list 1),(List.nth token_list 2))
      in
      let origin = Int64.to_int32 (Int64.of_string origin_str) in
      let offset = int_of_string offset_str in
  (origin,offset)

(* Query STP and return a pair (boolean answer,counterxample as stmt list) *)
let query_stp vc ctx query =
  (* Save STP state *)
  let _ = Libstp.vc_push vc in

  (* Query STP *)
  (* Printf.printf "STP Query: %s\n" (Vine.exp_to_string query);flush stdout; *)
  let stp_exp = Vine_stpvc.vine_to_stp vc ctx query in
  let stp_exp = Stpvc.e_bvbitextract vc stp_exp 0 in
  (* let _ = stp_exp_to_file "query.stp" vc stp_exp in *)
  let answer = Stpvc.query vc stp_exp in
  (* Printf.printf "Answer: %s\n" (string_of_bool answer); *)
  let ce_l = 
    if (not answer) then (
      let stp_ce_l = Stpvc.get_true_counterexample vc in
      let process_stp_ce l (lval_stp,val_stp) = 
	let vine_lval = Vine_stpvc.stp_to_vine lval_stp in
	let vine_val = Vine_stpvc.stp_to_vine val_stp in
	let stmt = 
	    match vine_lval with 
	      | Lval(lv) -> Move(lv,vine_val)
	      | _ -> failwith "STP returned something different than a Lval"
	in
	  stmt :: l
      in 
      List.fold_left process_stp_ce [] stp_ce_l
    )
    else []
  in
  (* Restore previous STP state *)
  let _ = Libstp.vc_pop vc in
  (answer,ce_l)

(* Given a binary expression, negate it and get a counterexample from STP 
Returns a list of (var,value) pairs *)
let get_ce vc ctx exp =
  (* Check that expression is boolean *)
  if (not (is_bool_exp exp)) then failwith "Not a boolean exp in get_ce";

  (* Query STP for counterexample *)
  let (answer,ce_l) = query_stp vc ctx exp in

  (* Print counterxample list *)
  (*List.iter (fun x -> pp_stmt print_string x; print_newline ();) ce_l;*)

  let process_stmt l stmt = 
    match stmt with 
      Move(Temp(var),Constant(Int(_,val64))) -> (var,val64) :: l
      | _ -> l
	(* let stmt_str = stmt_to_string stmt in
	let _ = D.dprintf "%s\n" stmt_str in
	failwith "Incorrect answer from query_stp" *)
  in
  List.fold_left process_stmt [] ce_l

(* Get sequences from counterexample *)
let get_ce_sequences ?(already_sorted=false) ce_l =
  (* Sort counterexamples *)
  let ce_l = 
    if (already_sorted) 
      then ce_l
      else List.sort Pervasives.compare ce_l
  in
  (* Find sequences *)
  let buf = Buffer.create 8 in
  let process_ce (curr_sub,l) ce =
    let (origin,offset,value) = ce in
    let (curr_orig,curr_sub_start,curr_sub_len,curr_sub_val) = curr_sub in
    let curr_sub_end = curr_sub_start + curr_sub_len -1 in
      if (curr_sub_start = -1) then (
	let _ = Buffer.add_char buf (Char.chr (Int64.to_int value)) in
	((origin,offset,1,Buffer.contents buf),l)
      )
      else if ((curr_orig <> origin) || (offset > (curr_sub_end + 1)))
	(* Found new substring.
	  Store previous substring and add offset to current substring *)
	then (
	  let _ = Buffer.clear buf in
	  let _ = Buffer.add_char buf (Char.chr (Int64.to_int value)) in
	    (origin,offset,1,Buffer.contents buf), curr_sub :: l
	  )
	else if (offset = curr_sub_end + 1) then (
	  (* Still the same substring. Add new offset *)
	  let _ = Buffer.add_char buf (Char.chr (Int64.to_int value)) in
	  ((curr_orig,curr_sub_start,curr_sub_len+1,Buffer.contents buf),l)
	)
        else (curr_sub,l) (* Duplicated pair, ignore *)
  in
  let dummy_sub = (Int32.minus_one,-1,-1,"") in
  let (last_sub,sub_l) = List.fold_left process_ce (dummy_sub,[]) ce_l in
  let rev_seq_l =
    if (last_sub <> dummy_sub)
      then last_sub :: sub_l
      else []
  in
  List.rev rev_seq_l

type 'a fork_and_perform_type = Result of 'a | Timed_out | Failed

(** Fork another process and perform the function [f].
    If [f] is complete, it returns Some (return value of [f]).
    Otherwise, returns None.
*)
let fork_and_perform ?(timeout=None) (f:unit -> 'a) =
  let (pipe_input_pid, pipe_output_pid) = Unix.pipe () in
  let child_pid = Unix.fork () in
    if child_pid = 0 then (
      (* child *)
      let pipe_output = Unix.out_channel_of_descr pipe_output_pid in
      let result_of_f = f () in
        Marshal.to_channel pipe_output result_of_f [];
        exit 0
    ) else (
      (* parent *)
      let pipe_input = Unix.in_channel_of_descr pipe_input_pid in
        (* setup alarm *)
      let orig_handler = match timeout with
          None -> Sys.Signal_default
        | Some t ->
            let handler = Sys.signal Sys.sigalrm (
              Sys.Signal_handle (fun _ -> Unix.kill child_pid Sys.sigkill))
            in
              ignore(Unix.alarm t);
              handler
      in
        (* clean up child process *)
      let (term_child, status) = 
        try
          Unix.waitpid [] child_pid 
        with Unix.Unix_error (Unix.EINTR,_,_) ->
          (* it will fail first time if got interrupted by the timeout *)
          Unix.waitpid [] child_pid
      in
        (* cleanup alarm *)
      let () = match timeout with
          None -> ()
        | Some _ ->
            ignore(Unix.alarm 0);
            Sys.set_signal Sys.sigalrm orig_handler
      in
      let ret_val =
        match status with
          | Unix.WEXITED i when i = 0 ->
              let result_of_f = Marshal.from_channel pipe_input in
                Result result_of_f
          | Unix.WSIGNALED i when i = Sys.sigkill -> Timed_out
          | _ -> Failed
      in
        Unix.close pipe_output_pid;
        Unix.close pipe_input_pid;
        ret_val
    )
