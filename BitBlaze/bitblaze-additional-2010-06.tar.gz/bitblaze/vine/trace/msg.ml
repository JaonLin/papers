(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Types and common functions for polyglot
*)

open Vine
open Vine_util
open Trace_slice

(** The field type as used by Wireshark *)
type fieldenc =
        FT_UNKNOWN (* FT_NONE *)
    |   FT_PROTOCOL
    |   FT_BOOLEAN
    |   FT_UINT8
    |   FT_UINT16
    |   FT_UINT24
    |   FT_UINT32
    |   FT_UINT64
    |   FT_INT8
    |   FT_INT16
    |   FT_INT24
    |   FT_INT32
    |   FT_INT64
    |   FT_FLOAT
    |   FT_DOUBLE
    |   FT_ABSOLUTE_TIME
    |   FT_RELATIVE_TIME
    |   FT_STRING
    |   FT_STRINGZ
    |   FT_UINT_STRING
    |   FT_ETHER
    |   FT_BYTES
    |   FT_UINT_BYTES
    |   FT_IPv4
    |   FT_IPv6
    |   FT_IPXNET
    |   FT_FRAMENUM
    |   FT_PCRE
    |   FT_GUID
    |   FT_OID
    |   FT_NUM_TYPES

let fieldenc_of_int = function
    |   1 -> FT_PROTOCOL
    |   2 -> FT_BOOLEAN
    |   3 -> FT_UINT8
    |   4 -> FT_UINT16
    |   5 -> FT_UINT24
    |   6 -> FT_UINT32
    |   7 -> FT_UINT64
    |   8 -> FT_INT8
    |   9 -> FT_INT16
    |   10 -> FT_INT24
    |   11 -> FT_INT32
    |   12 -> FT_INT64
    |   13 -> FT_FLOAT
    |   14 -> FT_DOUBLE
    |   15 -> FT_ABSOLUTE_TIME
    |   16 -> FT_RELATIVE_TIME
    |   17 -> FT_STRING
    |   18 -> FT_STRINGZ
    |   19 -> FT_UINT_STRING
    |   20 -> FT_ETHER
    |   21 -> FT_BYTES
    |   22 -> FT_UINT_BYTES
    |   23 -> FT_IPv4
    |   24 -> FT_IPv6
    |   25 -> FT_IPXNET
    |   26 -> FT_FRAMENUM
    |   27 -> FT_PCRE
    |   28 -> FT_GUID
    |   29 -> FT_OID
    |   30 -> FT_NUM_TYPES
    |   _ -> FT_UNKNOWN

(* Convert a fieldtype into a string *)
let fieldenc_str = function
        FT_UNKNOWN -> "FT_UNKNOWN"
    |   FT_PROTOCOL -> "FT_PROTOCOL"
    |   FT_BOOLEAN -> "FT_BOOLEAN"
    |   FT_UINT8 -> "FT_UINT8"
    |   FT_UINT16 -> "FT_UINT16"
    |   FT_UINT24 -> "FT_UINT24"
    |   FT_UINT32 -> "FT_UINT32"
    |   FT_UINT64 -> "FT_UINT64"
    |   FT_INT8 -> "FT_INT8"
    |   FT_INT16 -> "FT_INT16"
    |   FT_INT24 -> "FT_INT24"
    |   FT_INT32 -> "FT_INT32"
    |   FT_INT64 -> "FT_INT64"
    |   FT_FLOAT -> "FT_FLOAT"
    |   FT_DOUBLE -> "FT_DOUBLE"
    |   FT_ABSOLUTE_TIME -> "FT_ABSOLUTE_TIME"
    |   FT_RELATIVE_TIME -> "FT_RELATIVE_TIME"
    |   FT_STRING -> "FT_STRING"
    |   FT_STRINGZ -> "FT_STRINGZ"
    |   FT_UINT_STRING -> "FT_UINT_STRING"
    |   FT_ETHER -> "FT_ETHER"
    |   FT_BYTES -> "FT_BYTES"
    |   FT_UINT_BYTES -> "FT_UINT_BYTES"
    |   FT_IPv4 -> "FT_IPv4"
    |   FT_IPv6 -> "FT_IPv6"
    |   FT_IPXNET -> "FT_IPXNET"
    |   FT_FRAMENUM -> "FT_FRAMENUM"
    |   FT_PCRE -> "FT_PCRE"
    |   FT_GUID -> "FT_GUID"
    |   FT_OID -> "FT_OID"
    |   FT_NUM_TYPES -> "FT_NUM_TYPES"


(* Field Semantics as appeared in the paper *)
type fieldsem =
    FS_UNKNOWN (* FS_NONE *)
  | FS_MIXED
  | FS_COOKIE
  | FS_IP_ADDRESS
  | FS_ERROR_CODE
  | FS_FILE_DATA
  | FS_FILE_INFO (* As seen in Apache, e.g. *)
  | FS_FILENAME
  | FS_HASH    (* Include hash and checksum *)
  | FS_HOST_INFO (* As seen in MegaD *)
  | FS_HOSTNAME
  | FS_KEYBOARD_INPUT
  | FS_KEYWORD
  | FS_LENGTH
  | FS_PADDING
  | FS_PORT
  | FS_REGISTRY_DATA
  | FS_SLEEP_TIMER
  | FS_STORED_DATA
  | FS_TIMESTAMP

(* Convert a field semantic into a string *)
let fieldsem_str = function
    FS_UNKNOWN -> "FS_UNKNOWN"
  | FS_MIXED -> "FS_MIXED"
  | FS_COOKIE -> "FS_COOKIE"
  | FS_IP_ADDRESS -> "FS_IP_ADDRESS"
  | FS_ERROR_CODE -> "FS_ERROR_CODE"
  | FS_FILE_DATA -> "FS_FILE_DATA"
  | FS_FILE_INFO -> "FS_FILE_INFO"
  | FS_FILENAME -> "FS_FILENAME"
  | FS_HASH -> "FS_HASH"
  | FS_HOST_INFO -> "FS_HOST_INFO"
  | FS_HOSTNAME -> "FS_HOSTNAME"
  | FS_KEYBOARD_INPUT -> "FS_KEYBOARD_INPUT"
  | FS_KEYWORD -> "FS_KEYWORD"
  | FS_LENGTH -> "FS_LENGTH"
  | FS_PADDING -> "FS_PADDING"
  | FS_PORT -> "FS_PORT"
  | FS_REGISTRY_DATA -> "FS_REGISTRY_DATA"
  | FS_SLEEP_TIMER -> "FS_SLEEP_TIMER"
  | FS_STORED_DATA -> "FS_STORED_DATA"
  | FS_TIMESTAMP -> "FS_TIMESTAMP"

type range = {
  rstart: int;
  rend : int;
  rlen : int;
}

type separator_t =
  | Infld_sep
  | Fld_sep
  | Msg_sep
  | Unknown_sep

type separator = {
  sep_val : int64;
  sep_val_arr : int array;
  sep_len : int;
  sep_scope : range list;
  sep_type : separator_t;
}

type keyword = {
  keyval : string;
  keyval_arr : int array;
  keylen : int;
}

type direction_t = 
  | DIR_LENGTH
  | DIR_POINTER
  | DIR_ARRAY_CTR

type direction = {
  dir_type : direction_t;
  dir_target_pos : range;
}

type end_of_fld_marker_t = 
  | END_SEP (* End of varlen field marked with separator *)
  | END_DIR (* End of varlen field marked with direction field *)
  | END_UNKNOWN (* Don't know yet how end of varlen is marked *)

type field_t = 
  | VarLen of end_of_fld_marker_t
  | FixLen of int

type field = {
  fld_type : field_t;
  (* Offset of keyword from start of field * Keyword itself *)
  fld_keyword_l : (int * keyword) list;  
}

type msg = {
  msg_id : int;
  msg_orig : int32;
  msg_size : int;
}

type element_t = 
  | Dir of direction (* Terminal *)
  | Fld of field     (* Terminal *)
  | Sep of separator (* Terminal *)
  | Array            (* Non-terminal *)
  | Record           (* Non-terminal *)
  | Msg of msg       (* Non-terminal *)

type element = { 
  pos : range;
  el_id : int;
  el_encoding : fieldenc;
  mutable el_semantic : fieldsem;
  el_name : string;
  content : element_t;
}

type msg_fmt = {
  elements : element list;
}

type msg_ctx = {
  (* Origin is mutable so it can set the first time it's seen for convenience *)
  mutable msg_origin : int32;
  (* Max offset is mutable so it can update as the trace/cond are visited *)
  mutable msg_max_offset : int;
  (* field_start_pos_tbl : offset -> element *)
  fld_startpos_tbl : (int, element) Hashtbl.t;
  (* msg_tbl : element_start -> element *)
  msg_tbl : (int, element) Hashtbl.t;
}

let septype_to_str = function
  | Infld_sep -> "In-field sep"
  | Fld_sep -> "Field sep"
  | Msg_sep -> "Message sep"
  | Unknown_sep -> "Unknown sep"

let direction_to_str = function
  | DIR_LENGTH -> "length"
  | DIR_POINTER -> "pointer"
  | DIR_ARRAY_CTR -> "array counter"


(* Compare two ranges *)
let compare_range r1 r2 =
  let cstart = Pervasives.compare r1.rstart r2.rstart in
  if (cstart <> 0) then cstart
  else (
    let clen = Pervasives.compare r1.rlen r2.rlen in
    if (clen > 0) then -1
    else if (clen = 0) then 0
    else 1
  )

(* Compare two elements *)
let compare_elems e1 e2 = 
  let elcontent_to_int = function 
    | Sep _ -> 0
    | Fld(fld) -> (
	match fld.fld_type with 
	| VarLen _ -> 2
	| FixLen _ -> 3)
    | Dir _ -> 1
    | Record -> 4
    | Array -> 5
    | Msg _ -> 6
  in
  let et1 = elcontent_to_int e1.content in
  let et2 = elcontent_to_int e2.content in
  let ct = Pervasives.compare et1 et2 in
  if (ct  <> 0) then ct
  else compare_range e1.pos e2.pos


(* Convert an int64 to an array of ints *)
let val_to_arr val64 = 
  let tmp_arr = Array.make 8 0 in
  let last_non_zero = ref (-1) in
  let process_pos i _ = 
    let mask64 = Int64.shift_left 0xFFL (8*i) in
    let byte_val64 = Int64.shift_right (Int64.logand val64 mask64) (8*i) in
    let byte_val = Int64.to_int byte_val64 in
    if (byte_val <> 0) then last_non_zero := i;
    Array.set tmp_arr i byte_val
  in
  Array.iteri process_pos tmp_arr;
  if (!last_non_zero = -1) 
    then Array.make 1 0
    else Array.sub tmp_arr 0 (!last_non_zero + 1)

(* Convert an array int to a int64 *)
let arr_to_val arr = 
  let item_l = Array.to_list arr in
  let process_elem (pos,val64) curr_val = 
    let curr_val64 = Int64.of_int curr_val in
    let tok64 = Int64.shift_left curr_val64 (8*pos) in
    let new_val = Int64.logor tok64 val64 in 
    (pos+1,new_val)
  in
  let (_,result) = List.fold_left process_elem (0,0L) item_l in
  result

(* Check if an element is a terminal *)
let is_terminal el = 
  match el.content with
    | Msg _ | Record | Array -> false
    | _ -> true

(* Range to string *)
let range_to_string ?(print_length=false) r = 
  if (r.rlen = 0) then "unknown"
  else if (print_length)
    then Printf.sprintf "%03d -> %03d (%d)" r.rstart r.rend r.rlen
    else Printf.sprintf "%03d -> %03d" r.rstart r.rend

(* Print a range *)
let print_range ?(print_length=false) oc r = 
  Printf.fprintf oc "%s " (range_to_string r)

(* Print a separator element *)
let print_separator oc sep = 
  Printf.fprintf oc "SEPARATOR:\n\tValue: 0x%Lx\n" sep.sep_val;
  Printf.fprintf oc "\tNum_bytes: %d\n" sep.sep_len;
  Printf.fprintf oc "\tType: %s\n" (septype_to_str sep.sep_type);
  Printf.fprintf oc "\tElem: ";
  Array.iter (fun x -> Printf.fprintf oc "0x%02x " x) sep.sep_val_arr;
  Printf.fprintf oc "\n\tScope: ";
  List.iter (print_range oc) sep.sep_scope;
  Printf.fprintf oc "\n"

(* Separator to string *)
let sep_to_string sep = 
  let scope_str str range = 
    let cs = Printf.sprintf "%s; " (range_to_string range) in
    str ^ cs
  in
  let scope_str = List.fold_left scope_str "" sep.sep_scope in
    Printf.sprintf "Sep (0x%02Lx) Scope: %s" sep.sep_val scope_str

(* Keyword to string *)
let key_to_string key = 
  let buf = Buffer.create 80 in
  Buffer.add_string buf "KEYWORD: 0x";
  Array.iter (fun x -> Buffer.add_string buf (Printf.sprintf "%02x" x)) 
    key.keyval_arr;
  Buffer.add_string buf (Printf.sprintf " '%s' L: %d" key.keyval key.keylen);
  Buffer.contents buf

(* Size to string *)
let size_str = function
    | FixLen(x) -> Printf.sprintf "Fixlen (%d)" x
    | VarLen(END_SEP) -> Printf.sprintf "Varlen (sep)"
    | VarLen(END_DIR) -> Printf.sprintf "Varlen (dir)"
    | VarLen(END_UNKNOWN) -> Printf.sprintf "Varlen (?)"


(* Field to string *)
let fld_to_string fld = size_str fld.fld_type 

(* Direction to string *)
let dir_to_string dir = 
  let dir_type_str = direction_to_str dir.dir_type in
  Printf.sprintf "Direction (%s) Targetpos: %s" 
    dir_type_str (range_to_string dir.dir_target_pos)

(* Message to string *)
let msg_to_string msg = 
  Printf.sprintf "MSG ID: %d Size: %d Origin: 0x%lx"
    msg.msg_id msg.msg_size msg.msg_orig

(* Print a keyword *)
let print_key oc key = 
  Printf.fprintf oc "%s\n" (key_to_string key)

(* Print a separator *)
let print_sep oc sep = 
  Printf.fprintf oc "%s\n" (sep_to_string sep)

(* Print a field element *)
(* NOTE: not printing keywords yet *)
let print_fld oc fld = 
  Printf.fprintf oc "%s" (fld_to_string fld)

(* Print a direction element *)
let print_dir oc dir = 
  Printf.fprintf oc "%s\n" (dir_to_string dir)

(* Print a message element *)
let print_msg oc dir = 
  Printf.fprintf oc "%s\n" (msg_to_string dir)

(* Element to string *)
let elem_to_string elem = 
  let range_str = range_to_string elem.pos in
  let elem_str = 
    match elem.content with 
      | Dir (dir) -> dir_to_string dir
      | Fld (fld) -> fld_to_string fld
      | Sep (sep) -> sep_to_string sep
      | Record -> "Record"
      | Array -> "Array"
      | Msg (msg) -> msg_to_string msg
  in
    match elem.el_semantic with
	FS_UNKNOWN ->
	  Printf.sprintf "%s %s %s" range_str elem_str elem.el_name
      | _ -> 
	  let sem_str = fieldsem_str elem.el_semantic 
	  in
	    Printf.sprintf "%s %s %s %s" 
	      range_str elem_str elem.el_name sem_str

(* Print an element *)
let print_element oc elem = 
  Printf.fprintf oc "%s\n" (elem_to_string elem)

(* Print a message format *)
let print_msg_fmt oc msg_ctx = 
  let startpos_l = get_hash_keys msg_ctx.msg_tbl in
  let startpos_l = List.sort (Pervasives.compare) startpos_l in
  let print_el startpos = 
    let elem = Hashtbl.find msg_ctx.msg_tbl startpos in
    print_element oc elem
  in
  List.iter print_el startpos_l

