(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Functions to extract loop information from a trace without 
    any static information
  This method of findind loops is less reliable than the one in 
    trace_loops_static.ml, because it has problems finding the 
    exit conditions of loops
  On the other hand, it can be used when the static information 
    is not available or is incomplete (e.g., packed malware)

  Limitations: 
    -Can only find loops with a single entry point
    -Cannot find loops where only one iteration is executed
       (except rep loops that can be identified even if they don't iterate)
*)

module Trace = Temu_trace
open Trace
open Trace_loops
open Insn_classifier
open Vine_util
open Callstack

module D =
  Debug.Make(struct let name = "trace_loops_dynamic" and default=`NoDebug end)

type loop_jump_t =
  | Same_loop
  | Parent_loop
  | New_loop
  | Ignore

(* Loop jump string *)
let loop_jump_str = function
  | Same_loop -> "Same_loop"
  | Parent_loop -> "Parent_loop"
  | New_loop -> "New_loop"
  | Ignore -> "Ignore"

(* Get current loop. Raises Not_found *)
let get_curr_loop gctx fun_info =
  Hashtbl.find gctx.dc_loop_tbl fun_info.curr_loop_id

(* jump to *)
let find_jump_destination gctx fun_info dst = 
  if (dst <= 0L) then Ignore
  else (
    try (
      let curr_loop = get_curr_loop gctx fun_info in
      D.dprintf "Dst: %06Ld Curr end_line: %06Ld Curr start_line: %06Ld\n" 
        dst curr_loop.lend_line curr_loop.lstart_line;
      if (dst = (Int64.succ curr_loop.lend_line)) then Same_loop
      else if(dst < curr_loop.lstart_line) then Parent_loop
      else if (dst > (Int64.succ curr_loop.lend_line)) then New_loop
      else Ignore
    )
    with Not_found -> New_loop
  )


(* Get iteration exit condition taint info 
  NOTE There is no clear way to detect what an exit condition is dynamically, 
  thus we'll consider any conditional jump inside the loop as an 
  exit condition. 
  This is conservative and will mark as exit conditions, conditional jumps that 
  do not lead outside the loop.
*)
let get_iter_ec_l gctx iter_startline iter_endline =
  let set_eflags_info_l = ref (0l,0L,[]) in
  let rec process_line ec_acc linenum = 
    if linenum > iter_endline then ec_acc
    else (
      let (insn_eip,insn_type,insn_taint_l) =
	try Hashtbl.find gctx.dc_insn_info_tbl linenum
	with _ -> (0l,ERROR,[])
      in
      let sets_eflags = sets_eflags_raw insn_type in
      if (sets_eflags) 
        then set_eflags_info_l := (insn_eip,linenum,insn_taint_l);
      let new_ec_acc = 
        if (is_cond_jump_raw insn_type) then (
          let (sets_flags_eip,sets_flags_ctr,sets_flags_taint_l) = 
            !set_eflags_info_l
          in
          let ec = {
            ec_addr = insn_eip;
            ec_line = linenum;
            ec_taint_l = sets_flags_taint_l;
            ec_setflags_addr = sets_flags_eip;
            ec_setflags_line = sets_flags_ctr;
          }
          in
          ec :: ec_acc
        )
        else ec_acc
      in
      process_line new_ec_acc (Int64.succ linenum)
    )
  in
  process_line [] iter_startline

(* Get iteration taint info *)
let get_iter_taint_info gctx iter_startline iter_endline = 
  let tbl_size = Int64.to_int (Int64.sub iter_endline iter_startline) in
  let iter_tbl : ((int32*int),bool) Hashtbl.t = Hashtbl.create tbl_size in
  let rec process_line linenum =
    if linenum > iter_endline then ()
    else (
      let (_,_,insn_taint_l) = 
	try Hashtbl.find gctx.dc_insn_info_tbl linenum
	with _ -> (0l,ERROR,[])
      in
      List.iter (fun pair -> Hashtbl.replace iter_tbl pair true) insn_taint_l;
      process_line (Int64.succ linenum)
    )
  in
  process_line iter_startline;
  let pair_l : (int32*int) list = get_hash_keys iter_tbl in
  let pair_l = List.sort Pervasives.compare pair_l in
  pair_l

(* Get taint information for Rep instruction
   Checks if ECX is tainted in instruction *)
let get_rep_taint insn = 
  let op_l = 
    get_operands_in_insn ~include_memregs:false ~include_esp:false insn
  in
  let process_op acc op = 
    if (not (is_ecx_op op)) then acc
    else (
      let rec process_byte acc2 idx =
        if (idx > op#oplen - 1) then acc2
        else (
            if (Int64.logand op#taintflag (Int64.of_int (1 lsl idx))) <> 0L
            then
              let origin = op#origin.(idx) in
              let offset = Int32.to_int op#offset.(idx) in
              process_byte ((origin,offset) :: acc2) (idx+1)
            else process_byte acc2 (idx+1)
        )
      in
      process_byte [] 0
    )
  in
  List.fold_left process_op [] op_l

(* Add instruction to current context *)
let tfold_add_dynloop_insn_info gctx insn insn_ctr = 
  (* Update callstack information *)
  let cs_ctx = tfold_add_fun_to_callstack_ctx gctx.dc_cs_ctx insn insn_ctr in

  (* Get current address *)
  let curr_eip = Int64.to_int32 insn#address in

  (* Get taint information *)
  let taint_data_l =  get_insn_taint insn in

  D.dprintf "(%06Ld) EIP: 0x%08lx Tainted: %s\n" 
    insn_ctr curr_eip (string_of_bool (List.length taint_data_l > 0));

  (* Get the function info for this thread *)
  let fun_info = 
    try (
      let (fun_info,fun_loop_info_opt) = 
        get_thread_info cs_ctx insn#thread_id 
      in
      match fun_loop_info_opt with
        | Some(c) -> c
        | None -> 
            D.dprintf "Could not find function information ->  New function\n";
            { 
              eip_tbl = Hashtbl.create 100;
              last_eip = Int32.minus_one;
              curr_loop_id = -1;
            } 
    )
    with Not_found -> failwith "Unknown thread ID"
  in

  (* Update context *)
  let updated_ctx = 
    (* Handle rep loops *)
    if (is_rep_insn insn) then (
      D.dprintf "Found rep instruction\n";
      let ec =
	{
	  ec_addr = curr_eip;
	  ec_line = insn_ctr;
	  ec_taint_l = []; (* get_rep_taint insn; *)
          ec_setflags_addr = curr_eip;
          ec_setflags_line = insn_ctr;
	}
      in
      let iter =
	{
	  istart = curr_eip;
	  iend = curr_eip;
	  istart_line = insn_ctr;
	  iend_line = insn_ctr;
	  iec_l = [ec];
	  itaint_data = ec.ec_taint_l;
	}
      in
      (* Check if it is a new iteration of current loop *)
      let last_eip = 
	match gctx.dc_last_inst with 
	  | Some(last_insn) -> Int64.to_int32 (last_insn#address)
	  | None -> 0l
      in
      if (curr_eip = last_eip) then (
	let curr_loop = get_curr_loop gctx fun_info in
	curr_loop.num_iter <- curr_loop.num_iter + 1;
	curr_loop.lend_line <- iter.iend_line;
	curr_loop.iter_list <- 
	  List.rev (iter :: (List.rev curr_loop.iter_list));
	gctx
      )
      (* Otherwise, it is a new Rep loop *)
      else (
	let loop_id = gctx.dc_loop_ctr + 1 in
	gctx.dc_loop_ctr <- loop_id;
	let new_loop = 
	  {
	    id = loop_id;
	    ltype = Rep;
	    lstart = curr_eip;
	    lend = curr_eip;
	    num_iter = 1;
	    lstart_line = insn_ctr;
	    lend_line = insn_ctr;
	    iter_list = [iter];
	    nest_depth = 0;
	    nest_inner = None;
	    nest_outer = None;
	  } 
	in
	(* print_loop new_loop; *)
	Hashtbl.replace gctx.dc_loop_tbl loop_id new_loop;
        (* Update current loop id *)
        fun_info.curr_loop_id <- loop_id;
	(* Add current instruction to current context *)
	Hashtbl.add fun_info.eip_tbl curr_eip insn_ctr;
	gctx
      )
    )

    (* Check for backedge *)
    else (
      let _ = 
	(* We have found a loop iteration if the address has already been 
	    seen in this context *) 
	if (Hashtbl.mem fun_info.eip_tbl curr_eip) 
	then (
          D.dprintf "Found backedge\n";
	  let prev_app = 
	    try Hashtbl.find fun_info.eip_tbl curr_eip 
	    with Not_found -> Int64.minus_one 
	  in 
	  (* Found loop iteration *)
	  let iter = 
            {
              istart = curr_eip; 
              iend = fun_info.last_eip; 
              istart_line = prev_app;
              iend_line = (Int64.pred insn_ctr);
              iec_l = [];
                (* get_iter_ec_l gctx prev_app (Int64.pred insn_ctr); *)
              itaint_data = []
                (* get_iter_taint_info gctx prev_app (Int64.pred insn_ctr); *)
            }
	  in
          D.dprintf "Possible Iter: %06Ld -> %06Ld\n" 
            iter.istart_line iter.iend_line;
          let jump_target = find_jump_destination gctx fun_info prev_app in
          D.dprintf "Jump target: %s\n" (loop_jump_str jump_target);
	  match jump_target with 
	    | Same_loop -> (
                (* Same loop, update mutable fields *)
                let curr_loop = get_curr_loop gctx fun_info in 
                curr_loop.num_iter <- curr_loop.num_iter + 1;
                curr_loop.lend_line <- iter.iend_line;
                curr_loop.iter_list <- 
		  List.rev (iter :: (List.rev curr_loop.iter_list));
              )
	    | Parent_loop -> (
                (* Parent loop. Create new loop and update nesting *)
                let curr_loop = get_curr_loop gctx fun_info in 
                let loop_id = gctx.dc_loop_ctr + 1 in 
                gctx.dc_loop_ctr <- loop_id;
                let parent_loop = 
                  {
                    id = loop_id;
                    ltype = get_loop_type gctx.dc_last_inst;
                    lstart = iter.istart;
                    lend = iter.iend;
                    num_iter = 1;
                    lstart_line = iter.istart_line;
                    lend_line = iter.iend_line;
                    iter_list = [iter];
                    nest_depth = curr_loop.nest_depth + 1;
                    nest_inner = Some(curr_loop.id);
                    nest_outer = None;
                  } 
                in 
                curr_loop.nest_outer <- Some(loop_id);
                (* print_loop parent_loop; *)
                Hashtbl.replace gctx.dc_loop_tbl loop_id parent_loop;
                (* Update current loop id *)
                fun_info.curr_loop_id <- loop_id
              )

	    | New_loop -> (
                (* New loop, not parent. Create new loop *)
                let loop_id = gctx.dc_loop_ctr + 1 in 
                gctx.dc_loop_ctr <- loop_id;
                let new_loop = 
                  {
                    id = loop_id;
                    ltype = get_loop_type gctx.dc_last_inst;
                    lstart = iter.istart;
                    lend = iter.iend;
                    num_iter = 1;
                    lstart_line = iter.istart_line;
                    lend_line = iter.iend_line;
                    iter_list = [iter];
                    nest_depth = 0;
                    nest_inner = None;
                    nest_outer = None;
                  } 
                in
                (* print_loop new_loop; *)
                Hashtbl.replace gctx.dc_loop_tbl loop_id new_loop;
                (* Update current loop id *)
                fun_info.curr_loop_id <- loop_id
              )
	    | Ignore -> ()
	)
      in
      (* Add current instruction to current context *)
      Hashtbl.add fun_info.eip_tbl curr_eip insn_ctr;
      gctx
    )
  in

  (* Store last instruction *)
  updated_ctx.dc_last_inst <- Some(insn);

  (* Update function information: 
       1) last eip for function 
       2) information about instruction
  *)
  let () = 
    let itype = insn_class insn#rawbytes in
    Hashtbl.add gctx.dc_insn_info_tbl insn_ctr (curr_eip,itype,taint_data_l);
    let new_info = { fun_info with last_eip = curr_eip } in
    update_optional_info gctx.dc_cs_ctx insn#thread_id (Some(new_info))
  in
  (* Return global context *)
  updated_ctx

(* Create dynamic loop context *)
let create_dynloops_ctx function_map module_base_map = 
  {
    dc_loop_ctr = -1; 
    dc_loop_tbl = Hashtbl.create 30;
    dc_last_inst = None;
    dc_insn_info_tbl = Hashtbl.create 10000;
    dc_cs_ctx = 
      create_callstack_ctx function_map module_base_map
  }

(* Get loop list from dynamic loop context *)
let get_loops_from_dynamic_ctx ?(ignore_reps=false) dyn_ctx =
  let process_loop idx loop l =
    if (ignore_reps && (loop.ltype = Rep)) then l
    else loop :: l
  in
  let loop_l = Hashtbl.fold process_loop dyn_ctx.dc_loop_tbl [] in
  List.sort Pervasives.compare loop_l


(* Extract all loops from trace using dynamic method *)
let extract_dynloops_from_trace ?(ignore_reps=false) 
    ?(stack_size=context_stack_size) ?(first_ctr=1L) ?(last_ctr=Int64.max_int) 
    ?(trace_fmap_filename="") trace_filename =

  (* Read function map from file *)
  let fun_map = 
    if (trace_fmap_filename <> "") then read_function_map trace_fmap_filename 
    else Hashtbl.create 0
  in

  (* Open trace *)
  let trace = Trace.open_trace trace_filename in

  (* Read module base map from trace file *)
  let mod_map = 
    if (trace_fmap_filename <> "") then read_module_addresses trace 
    else Hashtbl.create 0
  in

  (* Create a global context *)
  let global_ctx = create_dynloops_ctx fun_map mod_map in

  (* Iterate through trace *)
  let trace = Trace.open_trace trace_filename in
  let global_ctx = 
    Trace.trace_fold_from_until_ctr first_ctr last_ctr 
      tfold_add_dynloop_insn_info global_ctx trace 
  in
  let _ = Trace.close_trace trace in

  (* Get loop list from context *)
  get_loops_from_dynamic_ctx ~ignore_reps:ignore_reps global_ctx

