(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Functions to create and manage a planar tree (implemented as a customary tree)
*)

(* The message format tree *)

open Msg
module D =
  Debug.Make(struct let name = "prototree" and default=`NoDebug end)

(** Triggered when an error is found when extracting info from prototree *)
exception Malformed_prototree

(** Triggered when trying to extract info from an empty prototree *)
exception Empty_prototree

type relation_t = 
  | Equals
  | Contains
  | IsContained
  | ExtendsLeft
  | ExtendsRight
  | ToRight
  | ToLeft

let relation_str = function
  | Equals -> "equals"
  | Contains -> "contains"
  | IsContained -> "is contained"
  | ExtendsLeft -> "extends left"
  | ExtendsRight -> "extends right"
  | ToRight -> "to right"
  | ToLeft -> "to left"

(* Check relationship of element2 to element1 *)
let relation (elem1 : Msg.element) (elem2 : Msg.element) = 
  if (elem1.pos = elem2.pos) then Equals
  else (
    let start1 = elem1.pos.rstart in
    let start2 = elem2.pos.rstart in
    let end1 = elem1.pos.rend in
    let end2 = elem2.pos.rend in
    if (start2 > end1) then ToRight
    else if (end2 < start1) then ToLeft
    else if (start2 > start1) && (end2 > end1) then ExtendsRight
    else if (end2 < end1) && (start2 < start1) then ExtendsLeft
    else if (start2 >= start1) && (end2 <= end1) then IsContained
    else Contains
  )

(* Check if element1 contains element 2 *)
let contains elem1 elem2 = 
  (elem2.pos.rstart >= elem1.pos.rstart) && 
    (elem2.pos.rend <= elem1.pos.rend)


(** The protocol tree module *)
module type PROTOTREE = 
  sig
    type prototree = 
	Empty 
	| Node of Msg.element * prototree * prototree
    (* General methods *)
    val create : unit -> prototree
    val singleton : Msg.element -> prototree
    val is_empty : prototree -> bool
    val size : prototree -> int
    val insert : Msg.element -> prototree -> prototree
    (* Iteration methods *)
    val iter : (Msg.element -> unit) -> prototree -> unit
    val fold : ('a -> Msg.element -> 'a) -> 'a -> prototree -> 'a
    (* Print methods *)
    val print : out_channel -> prototree -> unit
    val print_preorder : ?indent_flag:bool -> out_channel -> prototree -> unit
    val print_leaves : out_channel -> prototree -> unit
    val print_format : out_channel -> prototree -> unit
    (* Search methods *)
    (* The head of the list is always the innermost node and 
	  the tail the outermost *)
    val search_fields_by_id : prototree -> int -> Msg.element list
    val search_fields_by_offset : prototree -> int -> Msg.element list
    val search_fields_by_name : prototree -> string -> Msg.element list
    (* Serialization methods *)
    val serialize : string -> prototree -> unit
    val unserialize : string -> prototree
    val unserialize_wshark : string -> prototree
    (* Other methods *)
    val get_format_as_list : prototree -> Msg.element list
    val get_dir_elems : prototree -> Msg.element list
    val get_msg_tree : int -> prototree -> prototree
    val get_msg_origin : prototree -> int32
    (* val delete : Msg.element -> prototree -> prototree
    val mem : Msg.element -> prototree -> bool
    val height : prototree -> int *)
  end
;;

module Prototree : PROTOTREE = 
  struct

    type prototree = 
	Empty 
	| Node of Msg.element * prototree * prototree

    (** Create an empty tree *)
    let create () = Empty

    let prototree_str = function
      | Empty -> "empty"
      | Node (a,_,_) -> "node"

    (** Create a tree with a given element *)
    let singleton elem = Node(elem,Empty,Empty)

    (** Test to see if the tree is empty *)
    let is_empty = function Empty -> true | _ -> false

    (** Insert an element in the tree *)
    let rec insert elem = function
      | Empty -> Node(elem,Empty,Empty)
      | (Node(a,child,next) as n) ->
	  let rel = relation a elem in
	  D.dprintf "Node: %s %s of tree elem: %s\n" (elem_to_string elem) 
	    (relation_str rel) (elem_to_string a);
	  match rel with 
	    (* | Equals -> n (* same scope, keep the one inserted earliest *) *)
	    | Equals -> 
		if (a.content = elem.content) 
		then n (* If same scope and content, do not insert *)
		else (
		match a.content with
		  | Msg _ -> n (* If same scope as MSG element, do not insert *)
		  | _ -> Node(elem,insert a child,next) (* Insert as child *)
		)
	    | ToRight -> (* is next *)
		Node(a,child,insert elem next)
	    | IsContained -> (* is child *)
		Node(a,insert elem child,next)
	    | ToLeft -> (* is predecessor *)
		Node(elem,Empty,n)
	    | ExtendsRight | ExtendsLeft -> ( (* error overlap *)
		let error_str = 
		  Printf.sprintf "Node: %s %s of tree elem: %s\n" 
		    (elem_to_string elem) (relation_str rel) (elem_to_string a);
		in
		D.wprintf "ERROR: Failed to insert overlapping node: %s" 
		  error_str;
		n)
		(* failwith "Inserting node with overlap") *)
	    | Contains -> ( (* error in insertion *)
                match next with 
		  | Node(b,_,_) when ((relation b elem) = ToRight) -> 
		      Node(elem,Node(a,child,Empty),next)
		  | _ -> Node(elem,n,Empty)
		(* failwith "Error inserting node" *)
		)

    (** Apply function f to all elements of the tree 
          Performs an in-order depth-first search on the binary tree         
    *)
    let rec iter f t = match t with
      | Empty -> ()
      | Node(a,child,next) -> (
	  iter f child;
	  f a;
	  iter f next)

    (** Apply function f to all elements of the tree 
          Performs a pre-order depth-first search on the binary tree         
    *)
    let rec iter_preorder f t = match t with
      | Empty -> ()
      | Node(a,child,next) -> (
          f a;
          iter_preorder f child;
          iter_preorder f next)

    (** Apply function f to the leaves of the tree *)
    let rec iter_leaves f t = match t with
      | Empty -> ()
      | Node(a,Empty,next) -> (
          f a;
          iter_leaves f next)
      | Node(a,child,next) -> (
          iter_leaves f child;
          iter_leaves f next)

    (** Apply function f to the topmost level of the tree *)
    let rec iter_top_level f t = match t with
      | Empty -> ()
      | Node(a,child,next) -> (
	  f a;
          iter_top_level f next)

    (** Apply function f to all elements of the tree *)
    let rec fold f init t = match t with
      | Empty -> init
      | Node(a,child,next) ->
          let v = f init a in
          let v = fold f v child in
          fold f v next

    (** Return the number of elements in the tree *)
    let size t = fold (fun ctr el -> 1 + ctr) 0 t

    (** Print the tree by iterating over all the elements *)
    let print oc t = 
      iter (Msg.print_element oc) t;
      flush oc

    (** Print the tree by iterating over all the elements *)
    let print_preorder ?(indent_flag=false) oc t =
      let rec print_preorder_indent oc t level =
	match t with
	  | Empty -> ()
	  | Node(a,Empty,next) ->
	      Printf.fprintf oc "%sL %s\n" 
		(String.make (2*level) ' ') 
		(Msg.elem_to_string a);
	      print_preorder_indent oc next level
	  | Node(a,child,next) ->
	      Printf.fprintf oc "%sH %s\n" 
		(String.make (2*level) ' ')
		(Msg.elem_to_string a);
	      print_preorder_indent oc child (level+1);
	      print_preorder_indent oc next level
      in
	if indent_flag then begin
	  print_preorder_indent oc t 0;
	  flush oc
	end
	else begin
	  iter_preorder (Msg.print_element oc) t;
	  flush oc
	end

    (** Print the tree with the leave/hierarchical info *)


    (** Print the leaf nodes in the tree *)
    let print_leaves oc t = 
      iter_leaves (Msg.print_element oc) t;
      flush oc

    (** Print the message format by iterating over topmost level *)
    let print_format oc t = 
      iter_top_level (Msg.print_element oc) t;
      flush oc

    (** Find the list of nodes that contain the given offset *)
    let search_fields_by_offset t offset = 
      let process_node acc n = 
	if ((offset >= n.pos.rstart) && (offset <= n.pos.rend))
	  then (n :: acc)
	  else acc
      in
      fold process_node [] t

    (** Find the list of nodes with the given name *)
    let search_fields_by_name t name = 
      let process_node acc n = 
        if (name = n.el_name) then (n :: acc)
        else acc
      in
      fold process_node [] t

    (** Find the list of nodes with the given id *)
    let search_fields_by_id t id =
      let process_node acc n =
        if (id = n.el_id) then (n :: acc)
        else acc
      in
      fold process_node [] t

    (** Get message format as a list of elements *)
    let get_format_as_list t = 
      let acc = ref [] in
      iter_top_level (fun el -> acc := el :: !acc) t;
      List.rev !acc

    (** Replace top level elements with msg elements *)
    let replace_top_level origin t = 
      let rec replace_node ctr t = 
	match t with
	    Empty -> Empty
	  | Node(a, child, next) ->
	      let next = replace_node (ctr+1) next in
	      let msg = 
		{ msg_id = ctr; msg_orig = origin; msg_size = a.pos.rlen; }
	      in
              let n = {a with content = Msg(msg)} in
              Node(n,child,next)
      in
      replace_node 0 t

    (** Serialize prototree to file *)
    let serialize filename t =
      let oc =
	try open_out filename
	with _ -> failwith "Could not serialize protocol tree"
      in
      let _ = Marshal.to_channel oc t [] in
      close_out oc

    (** Unserialize prototree from file *)
    let unserialize filename =
      let ic =
	try open_in filename
	with _ -> failwith "Did not find prototree file"
      in
      let (tree : prototree) =
	Marshal.from_channel ic
      in
      let _ = close_in ic in
      tree

    (* Rename field name so that is does not have any underscore *)
    let normalize_name name = 
      let token_l = Str.split (Str.regexp "[_ ]+") name in
      let to_upper token = 
        try (
          let uc = Char.uppercase (String.get token 0) in
          let _ = String.set token 0 uc in
          token
        )
        with _ -> token
      in
      let token_l = List.map to_upper token_l in
      String.concat "" token_l

    (* Read a list of elements from a Wireshark format file *)
    let unserialize_wshark_elements filename = 
      let map = Hashtbl.create 1000 in
      let ic =
        try open_in filename
        with _ -> failwith "Did not find prototree file"
      in
      let parse_line line = 
	D.dprintf "Parsing line: '%s'\n%!" line; 
        let create_element id start size ftype depid name manual =
          let fld_name = normalize_name name in
          let fld_type = fieldenc_of_int ftype in
          let fld_end = start + size -1 in
          let range = { rstart = start; rlen = size; rend = fld_end; } in
          let cont = 
	    let ftype =
	      match manual with
	       | "FIXLEN" -> FixLen(size)
	       | "VARLEN" when (depid = 0) -> VarLen(END_SEP)
	       | "VARLEN" -> VarLen(END_DIR)
	       | _ -> failwith "Unknown manual field"
	    in
	    let fld = { fld_type = ftype; fld_keyword_l = []; } in
	    Fld(fld)
          in
          let el = {
            pos = range;
            el_id = id;
            el_encoding = fld_type;
	    el_semantic = FS_UNKNOWN;
            el_name = fld_name;
            content = cont;
          }
          in
          (el,depid)
        in
        try (
	  let (el,depid) =
	    Scanf.sscanf line "%d %d %d %d %d %s %s" create_element
	  in
	  if (depid <> 0) then (
	    (* Find last time the depid was seen and add direction field *)
            try (
	      let parent = Hashtbl.find map depid in
	      let dir =
		{ dir_type = DIR_LENGTH; dir_target_pos = el.pos; }
	      in
	      let dir_el = {parent with content = Dir(dir)} in
	      Hashtbl.add map depid dir_el
	    )
	    with Not_found -> ()
	  );
	  Hashtbl.add map el.el_id el;
        )
        with _ -> ()
      in
      let rec buildtree ic = 
        try (
	  let line = input_line ic in 
	  let _ = parse_line line in
	  buildtree ic
	)
	with End_of_file -> ()
      in
      let _ = buildtree ic in
      Hashtbl.fold (fun k d acc -> d :: acc) map []

    (** Read a prototree from a Wireshark format file *)
    let unserialize_wshark filename =
      let elem_l = unserialize_wshark_elements filename in
      let elem_l = List.sort (Msg.compare_elems) elem_l in
      (* List.iter (print_element stdout) elem_l; *)
      let num_elems = List.length elem_l in
      D.dprintf "Num_elems: %d\n" num_elems;
      let process_el t el = 
	D.dprintf "Inserting: %s\n" (elem_to_string el);
	let nt = insert el t in
	D.dprintf "Size: %d\n" (size nt);
	nt
      in
      let t = List.fold_left process_el Empty elem_l in
      (* replace_top_level 0l t *)
      t

    (** Get direction fields in tree as list of elements *)
    let get_dir_elems t =
      let process_elem acc el = 
        match el.content with 
          | Dir _ -> el :: acc
          | _ -> acc
      in
      fold process_elem [] t

    (** Get the protocol subtree for the message [id] *)
    let get_msg_tree id t = 
      let rec check_node t = 
	match t with
	  | Empty -> t
	  | Node(a,child,next) -> (
	      match a.content with 
		| Msg(msg) -> 
		    if (id = msg.msg_id) then Node(a,child,Empty)
                    else check_node next
		| _ -> check_node next
	    )
      in
      check_node t

    (** Get the origin for the message represented by this tree 
        Raises Empty_prototree if tree is empty
        Raises Malformed_prototree if root node is not of type Msg *)
    let get_msg_origin t =
      match t with
        | Empty -> raise Empty_prototree
        | Node(a,_,_) -> (
            match a.content with
              | Msg(msg) -> msg.msg_orig
              | _ -> raise Malformed_prototree
          )

  end
;;
