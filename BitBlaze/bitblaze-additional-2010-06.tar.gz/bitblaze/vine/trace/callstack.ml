(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(** 
  Code to replicate the call stack of the process as it processes the 
    execution trace
  Allows the user to keep its own information in the replicated stack

*)

open Vine_util
open Insn_classifier
module D =
  Debug.Make(struct let name = "callstack" and default=`NoDebug end)

(* Globals *)
let stack_start_size = 100

(* Function instance information *)
type function_info_t = {
  fi_modname : string; (* Module name *)
  fi_funname : string; (* Function name *)
  fi_start_addr : Libasmir.address_t; (* Address of function's entry point *)
  fi_start_ctr : int64; (* Instruction counter for function's entry point *)
  fi_retaddr : Libasmir.address_t; (* Return address for function *)
}

(* Callstack information for one thread *)
type 'a thread_callstack_t = {
  thread_id : int32;
  mutable thread_found_call : bool;
  mutable thread_found_ret : bool;
  mutable thread_next_inst : Libasmir.address_t;
  mutable thread_is_entry_inst : bool;
  mutable thread_is_exit_inst : bool;
  mutable thread_ret_was_spurious : bool;
  mutable thread_pop_l : (function_info_t*'a option) list;
  thread_fun_stack : (function_info_t*'a option) Stack.t;
}

(* Callstack context (for one given process) *)
type 'a callstack_context = {
  (* Starting size for each thread callstack *)
  stack_size : int;
  (* Compute callstack digest *)
  compute_cs_digest : bool;
  (* Map of the callstack for each thread in the process: 
    ThreadID -> ThreadInfo *)
  function_stack_map : (int32,'a thread_callstack_t) Hashtbl.t;
  (* Exported functions information: 
      FunctionStartAddr -> (ModuleName,FunctionName,OffsetInModule) *)
  function_map : (Libasmir.address_t,(string*string*int)) Hashtbl.t;
  (* Module information:
      ModuleName -> (ModuleBaseAddr,ModuleByteSize) *)
  module_base_map : (string,(Libasmir.address_t*int64)) Hashtbl.t;
  (* List of ranges in trace belonging to same function: 
    (fun_len,fun_start,fun_end,MD5) list *)
  mutable range_l : (int64*int64*int64*Digest.t option) list;
}

(* Initialize thread information *)
let init_thread_info tid stack_size =
  let st =
    (Stack.create () : ((function_info_t*'a option)  Stack.t))
  in
  let empty_st_item = 
    {
      fi_modname = "unseen";
      fi_funname = "unseen";
      fi_start_addr = 0L;
      fi_start_ctr = 0L;
      fi_retaddr = 0L;
    }
  in
  let _ =
    for i = 0 to stack_size do
      Stack.push (empty_st_item,None) st;
    done
  in
  {
    thread_id = tid;
    thread_found_call = false;
    thread_found_ret = false;
    thread_ret_was_spurious = false;
    thread_next_inst = 0L;
    thread_fun_stack = st;
    thread_is_entry_inst = false;
    thread_is_exit_inst = false;
    thread_pop_l = [];
  }

(* Create callstack context *)
let create_callstack_ctx ?(stack_size=stack_start_size) 
      ?(compute_cs_digest=false) known_fun_map module_base_map =
  {
    stack_size = stack_size;
    compute_cs_digest = compute_cs_digest;
    function_stack_map = Hashtbl.create 10; (* Thread # usually small *)
    function_map = known_fun_map;
    module_base_map = module_base_map;
    range_l = [];
  }


(* Walk the stack and get an MD5 hash *)
let compute_call_stack_digest st =
  let st_len = Stack.length st in
  let buf = Buffer.create (st_len * 10) in
  let process_record (fun_info,_) = 
    let eip_str = Printf.sprintf "0x%08Lx_" fun_info.fi_retaddr in
    Buffer.add_string buf eip_str
  in
  Stack.iter process_record st;
  let st_str = Buffer.contents buf in
  (* D.dprintf "\tCS_str: %s\n%!" st_str; *)
  Digest.string st_str


(* Read function map from file *)
let read_function_map filename =
  (* Size proportionate to number of exported functions in fmap file *)
  let function_map = Hashtbl.create 20000 in 
  let ic =
    try open_in filename
    with Not_found -> failwith "Netlog file not found"
  in
  let ic = IO.input_channel ic in
  let rec read_all_lines () =
    let line = IO.read_line ic in
    (* process line *)
    let re = Str.regexp "[ \t]+" in
    let param_list = Str.split re line in
    let eip = Int64.of_string (List.nth param_list 0) in
    let mod_name = (List.nth param_list 1) in
    let fun_name = (List.nth param_list 2) in
    let offset = int_of_string (List.nth param_list 3) in
    Hashtbl.replace function_map eip (mod_name,fun_name,offset);
    read_all_lines ()
  in
  let _ =
    try
      read_all_lines ()
    with
      IO.No_more_input -> IO.close_in ic
  in function_map

(* Print function map *)
let print_function_map function_map =
  let keys = get_hash_keys function_map in
  let keys = List.sort Pervasives.compare keys in
  let process_eip last_eip curr_eip =
    if (last_eip <> curr_eip) then
      (
        let (mod_name,fun_name,offset) =
          try Hashtbl.find function_map curr_eip
          with Not_found -> ("","",-1)
        in
        let _ = match offset with
          (-1) -> ()
          | _ ->
            Printf.printf "%s::%s @ 0x%08Lx (0x%04x)\n"
              mod_name fun_name curr_eip offset
        in
        curr_eip
      )
      else last_eip
  in
  let _ = List.fold_left process_eip 0L keys
  in ()

(* Read module base addresses from the header of the trace *)
let read_module_addresses ti =
  let module_base_map = Hashtbl.create 200 in
  let procs = ti#processes in
  let num_procs = List.length procs in
  let _ =
    if (num_procs > 1)
    then failwith "More than one process in trace. Exiting...";
  in
  let proc =
    try List.hd procs
    with _ -> failwith "No processes in trace. Exiting..."
  in
  (* Printf.printf "Process: %s PID: %d\n%!" proc#name proc#pid; *)
  let add_module curr_mod =
    (*  Printf.printf "\t Module: %s @ 0x%08Lx Size: %Ld\n%!" 
        curr_mod#name curr_mod#base curr_mod#size; *)
    Hashtbl.add module_base_map
      curr_mod#name (curr_mod#base,curr_mod#size)
  in
    (* map module info in the reverse order so that it comes in the right
       order when calling with Hashtbl.fold *)
  let _ = List.iter add_module (List.rev proc#modules) in
  module_base_map

(* Read module base addresses from the header of the trace *)
let read_module_base_map_from_trace trace_file = 
  let tif = Temu_trace.open_trace trace_file in
  let map = read_module_addresses tif in
  let () = Temu_trace.close_trace tif in
  map

(* Read process information from the header of the trace *)
let read_process_info_from_trace trace_file =
  let tif = Temu_trace.open_trace trace_file in
  let proc_info = List.hd tif#processes in
  let () = Temu_trace.close_trace tif in
  proc_info


(* Return the module information for the given EIP *)
let find_module module_base_map addr =
  let check_module modname (base,size) in_module =
    if (in_module <> "unknown")
    then in_module
    else
      if ((addr >= base) && (addr <= (Int64.add base size))) then modname
      else "unknown"
  in
  Hashtbl.fold check_module module_base_map "unknown"

(* Add function to function map *)
let add_fun_to_funmap map mod_name fun_name insn_ctr =
  Hashtbl.add map (mod_name,fun_name) insn_ctr

(* Check if corresponding call is in stack *)
let check_for_call function_stack address =
  let flag = ref false in
  let process_call (fun_info,_) =
    if (fun_info.fi_retaddr = address) then flag := true
  in
  Stack.iter process_call function_stack;
  !flag

(* Check if address is known entry point of function *)
let is_funentry function_map addr =
  Hashtbl.mem function_map addr

(* Read the optional information for the current function instance in
     the given thread 
   Raises Not_found if it does not know the thread id *)
let get_thread_info cs_ctx thread_id =
  let tinfo = Hashtbl.find cs_ctx.function_stack_map thread_id in
  Stack.top tinfo.thread_fun_stack
    

(* Update the optional information for the current function instance in 
     the given thread. Does not modify function information. 
   Raises Not_found if it does not know the thread id *)
let update_optional_info cs_ctx thread_id optional_info_opt =
  let tinfo = Hashtbl.find cs_ctx.function_stack_map thread_id in
  let (fun_info,_) = Stack.pop tinfo.thread_fun_stack in
  Stack.push (fun_info,optional_info_opt) tinfo.thread_fun_stack


(* Update the callstack information for an instruction *)
let tfold_add_fun_to_callstack_ctx ctx insn insn_ctr =

  (* Get the function info for this thread *)
  let tinfo =
    try Hashtbl.find ctx.function_stack_map insn#thread_id
    with Not_found ->
      let info = init_thread_info insn#thread_id ctx.stack_size in
      Hashtbl.add ctx.function_stack_map insn#thread_id info;
      info
  in
  let function_stack = tinfo.thread_fun_stack in

  (* Unset flags *)
  tinfo.thread_ret_was_spurious <- false;
  tinfo.thread_is_exit_inst <- false;
  tinfo.thread_pop_l <- [];

  (* Check if this address corresponds to a known function entry point *)
  let is_entry_point = 
      (is_funentry ctx.function_map insn#address) ||
      (tinfo.thread_found_call && (not (is_ind_jump insn)))
  in
  tinfo.thread_is_entry_inst <- is_entry_point;

  let _ =
    (* If known entry point or previous instruction was call, add function *)
    if is_entry_point then (
      (* Get module and function name *)
      let (mod_name,fun_name) =
        try (
          let (mod_name,fun_name,_) =
            Hashtbl.find ctx.function_map insn#address
          in
          (mod_name,fun_name)
        )
        with Not_found -> (
          let mod_name = find_module ctx.module_base_map insn#address in
          let eip_str = Printf.sprintf "%Lx" insn#address in
          let fun_name = Printf.sprintf "sub_%s" (String.uppercase eip_str) in
          (mod_name,fun_name)
        )
      in
      (* The return address is only set if the function was reached through
           a call instruction, otherwise leave as unknown *)
      let retaddr = 
        if tinfo.thread_found_call 
          then tinfo.thread_next_inst
          else 0L
      in
      (* Add function to thread's callstack 
          unless entry point is a ret instruction, 
          which happens with ntdll.dll::KiFastSystemCallRet *)
      let fun_info =
	{
	  fi_modname = mod_name;
	  fi_funname = fun_name;
	  fi_start_ctr = insn_ctr;
	  fi_start_addr = insn#address;
	  fi_retaddr = retaddr;
	}
      in
      if (not (is_ret insn)) then (
        Stack.push (fun_info,None) function_stack;
        D.dprintf "Found function entry: %s::%s (%d)%!"
          mod_name fun_name (Stack.length function_stack);
      )
      else (
        D.dprintf "Found function entry in return instruction: %s::%s (%d)%!"
          mod_name fun_name (Stack.length function_stack);
      );

      (* Update *)
      tinfo.thread_found_call <- false;
    );
    (* Found a return, check if it corresponds to previously seen function 
       It turns out that at least in Linux ret instructions are sometimes 
        called without a corresponding call, specially in the context 
        of system calls.
        Thus need to handle spurious ret instructions *)
    if (tinfo.thread_found_ret) then (
      let curr_len = Stack.length function_stack in
      let (fin,fin_stats_opt) =
        try Stack.pop function_stack
        with Stack.Empty ->
          Printf.printf "Current depth index: %d\n%!" curr_len;
          failwith "Try increasing function_stack_start_size?"
      in
      (* Check if this instruction is the one we were expecting, 
          i.e., the one that follows the call *)
      let (mod_name,fun_name,curr_len,pop_l) =
        let pop_l = [(fin,fin_stats_opt)] in
        if ((fin.fi_funname = "unseen") || (insn#address = fin.fi_retaddr))
          then (fin.fi_modname,fin.fi_funname,curr_len,pop_l)
          else (
            (* Check if we are missing some calls, by scanning the stack 
                 for the corresponding call *)
            let in_stack = check_for_call function_stack insn#address in
            (* If there is a corresponding call in the stack, 
                that should mean we missed some rets, pop the stack till 
                the corresponding call, inclusive *)
            if (in_stack) then (
              let rec pop_stack acc ctr =
                let (fun_info,fun_info_stats) = Stack.pop function_stack in
                let pop_l = (fun_info,fun_info_stats) :: pop_l in
                if (fun_info.fi_retaddr = insn#address) then (
                  let cl = Stack.length function_stack in
                  (fun_info.fi_modname,fun_info.fi_funname,cl+1,pop_l)
                )
                else pop_stack pop_l (ctr+1)
              in
              pop_stack pop_l 0
            )
            else (
              (* Otherwise, it is an spurious ret, keep old info *)
              Stack.push (fin,fin_stats_opt) function_stack;
              tinfo.thread_ret_was_spurious <- true;
              ("spurious","spurious",0,[])
            )
          )
      in
      D.dprintf "(%08Ld) Found function return %s::%s (%d)"
        insn_ctr mod_name fun_name curr_len;

      (* Compute callstack digest and add it to table *)
      let md5_opt = 
	if ctx.compute_cs_digest then (
	  let md5 = compute_call_stack_digest tinfo.thread_fun_stack in
	  (* D.dprintf " \tMD5: %s\n%!" (Digest.to_hex md5); *)
	  Some(md5)
	)
	else None
      in
      let fun_size = Int64.succ (Int64.sub insn_ctr fin.fi_start_ctr) in
      ctx.range_l <- 
	(fun_size,fin.fi_start_ctr,insn_ctr,md5_opt) :: ctx.range_l;

      (* Update *)
      tinfo.thread_next_inst <- 0L;
      tinfo.thread_found_ret <- false;
      tinfo.thread_is_exit_inst <- true;
      tinfo.thread_pop_l <- pop_l
    );

    (* Check if it is a call or ret instruction *)
    if (is_call insn) then (
      tinfo.thread_next_inst <-
        Int64.add insn#address (Int64.of_int insn#inst_size);
      tinfo.thread_found_call <- true
    )
    else if (is_ret insn) then (
      tinfo.thread_found_ret <- true
    )
    (* Special case for calls without ret. Flag if this case is found *)
    else if (insn#address = tinfo.thread_next_inst) then (
      D.wprintf "(%08Ld) Found call without ret at 0x%Lx\n%!"
        insn_ctr insn#address;
    )
    else ()
  in
  ctx


(* Given a callstack context and an instruction counter, get the callstack 
    digest for that instruction 
   Raise Not_found if instruction counter not found in range list *)
let cs_map_digest_function ctx insn_ctr = 
  (* Sort ranges by length *)
  let range_l = List.sort (Pervasives.compare) ctx.range_l in
  (* Find innermost range *)
  let (fun_size,fun_start,fun_end,h) = 
    let pred = (fun (len,s,e,h) -> (insn_ctr >= s) && (insn_ctr <= e)) in
    List.find pred range_l
  in
  let md5_str = 
    match h with
      | None -> ""
      | Some(md5) -> Digest.to_hex md5
  in
  D.dprintf "Innermost Range: (%Ld,%Ld,%Ld)\n\tMD5: %s\n%!" 
     fun_size fun_start fun_end md5_str;
  h

(* Given a callstack context and an instruction counter, get the first 
    line of the instruction (unique identifies function in trace)
   Raise Not_found if instruction counter not found in range list *)
let cs_map_start_function ctx insn_ctr =
  (* Sort ranges by length *)
  let range_l = List.sort (Pervasives.compare) ctx.range_l in
  (* Find innermost range *)
  let (fun_size,fun_start,fun_end,h) =
    let pred = (fun (len,s,e,h) -> (insn_ctr >= s) && (insn_ctr <= e)) in
    List.find pred range_l
  in
  let md5_str = 
    match h with
      | None -> ""
      | Some(md5) -> Digest.to_hex md5
  in
  D.dprintf "Innermost Range: (%Ld,%Ld,%Ld)\n\tMD5: %s\n%!"
     fun_size fun_start fun_end md5_str;
  fun_start


(* Iterate over trace and return callstack context *) 
let get_trace_callstack_ctx ?(start_ctr) ?(stop_ctr) trace_fmap_file trace_file = 
  (* Read function map from file *)
  let fun_map = read_function_map trace_fmap_file in

  (* Open trace *)
  let trace = Temu_trace.open_trace trace_file in

  (* Read module base map from trace file *)
  let mod_map = read_module_addresses trace in

  (* Create callstack context *)
  let cs_ctx = create_callstack_ctx fun_map mod_map in

  (* Pick appropriate trace_fold. x represents the fact that it's a function;
     not necessary that it has one argument (and it actually has 3).
  *)
  let trace_fold x =
    match start_ctr, stop_ctr with
        None, None -> Temu_trace.trace_fold x
      | Some start_ctr, None -> Temu_trace.trace_fold ~start_ctr:start_ctr x
      | None, Some stop_ctr -> Temu_trace.trace_fold ~stop_ctr:stop_ctr x
      | Some start_ctr, Some stop_ctr -> 
          Temu_trace.trace_fold ~start_ctr:start_ctr ~stop_ctr:stop_ctr x
  in

  (* Iterate over trace *)
  let cs_ctx = 
    trace_fold tfold_add_fun_to_callstack_ctx cs_ctx trace
  in
  let _ = Temu_trace.close_trace trace in
  cs_ctx

(* Serialize callstack context to file *)
let serialize_cs_ctx filename cs_ctx =
  let oc =
    try open_out_bin filename
    with _ -> failwith "Could not open output file to serialize"
  in
  let _ = Marshal.to_channel oc cs_ctx [] in
  close_out oc

(* Unserialize callstack context from file *)
let unserialize_cs_ctx filename =
  let ic =
    try open_in_bin filename
    with _ -> failwith "Could not open file to unserialize"
  in
  let ctx = Marshal.from_channel ic in
  let _ = close_in ic in
  ctx

(* Print ranges *)
let my_print_ranges oc range_l = 
  let print_range range = 
    let (fun_size,fun_start,fun_end,md5_opt) = range in
    let md5_str = 
       match md5_opt with
	 | Some(md5) -> Digest.to_hex md5
	 | None -> ""
    in
    Printf.fprintf oc "Range: (%Ld,%Ld,%Ld)\n\tMD5: %s\n" 
      fun_size fun_start fun_end md5_str;
  in
  List.iter print_range range_l;
  flush oc

(* Get a function that given a instruction number in the trace, 
     returns the Callstack Digest for the function that contained
     the instruction *)
let get_trace_callstack_digest_fun trace_fmap_file trace_file = 
  (* Get callstack context by iterating trace *)
  let cs_ctx = get_trace_callstack_ctx trace_fmap_file trace_file in
  (* Print the ranges *)
  if D.debug then my_print_ranges stdout cs_ctx.range_l;
  (* Return function *)
  cs_map_digest_function cs_ctx

(* Get a function that given a instruction number in the trace, 
     returns the Callstack Digest for the function that contained
     the instruction *)
let get_trace_callstack_start_fun trace_fmap_file trace_file =
  let cs_ctx = get_trace_callstack_ctx trace_fmap_file trace_file in
  (* Print the ranges *)
  if D.debug then my_print_ranges stdout cs_ctx.range_l;
  (* Return function *)
  cs_map_start_function cs_ctx


