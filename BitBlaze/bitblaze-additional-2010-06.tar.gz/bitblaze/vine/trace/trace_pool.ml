(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
let addr = (Unix.inet_addr_of_string "127.0.0.1", 12001);;

type trace_info = {
  ti_path : string;  (* Directory where trace files are stored *)
  ti_input : string;     (* input used to generate this trace *)
  ti_id : int;          (* Unique ID for the trace *)
  ti_result : int;   (* Return code by TEMU *) 
  ti_coverage : int;    (* Number of new blocks discovered *)
}

type t = trace_info

let key t =
  t.ti_coverage;;

let name = "trace";;
let key_name = "coverage";;

let should_print = false;;

let print ti = ();;

let compare a b =
  let comp = Pervasives.compare a.ti_coverage b.ti_coverage in
  if (comp <> 0) then comp
  else Pervasives.compare b.ti_path a.ti_path;;

let marshal_object sd ti =
  let _ = Netcomm.write_file sd ti.ti_path in
  let _ = Netcomm.write_string sd ti.ti_input in
  let _ = Netcomm.write_i32 sd ti.ti_id in
  let _ = Netcomm.write_i32 sd ti.ti_result in
  let _ = Netcomm.write_i32 sd ti.ti_coverage in
  ();;

let unmarshal_object sd =
  let ti_path = Netcomm.read_file sd in
  let ti_input = Netcomm.read_string sd in
  let ti_id = Netcomm.read_i32 sd in
  let ti_result = Netcomm.read_i32 sd in
  let ti_coverage = Netcomm.read_i32 sd in
    { ti_path = ti_path;
      ti_input = ti_input;
      ti_id = ti_id;
      ti_result = ti_result;
      ti_coverage = ti_coverage;
    };;

let cond_func item = item.ti_coverage != 0;;



let reject ti = false;; (*(ti.ti_coverage = 0);*)

