(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
open Vine
open Vine_tovine
open Exectrace;;
module Trace = Temu_trace;;
module POSTDOM = Dominator.Make (
  struct 
    type t = Vine_cfg.G.t
    module V = Vine_cfg.G.V
    let pred = Vine_cfg.G.succ
    let succ = Vine_cfg.G.pred
    let fold_vertex = Vine_cfg.G.fold_vertex
    let iter_vertex = Vine_cfg.G.iter_vertex
    let nb_vertex = Vine_cfg.G.nb_vertex
  end
);;
module I = Int64;;
module SetOfInt32 = Set.Make(Int32);;

let startfunc = ref false

let readfile fname openfn =
  let cin = openfn fname in 
  let rec aux acc = try aux ((input_line cin)::acc)
  with End_of_file -> close_in cin; List.rev acc
  in aux [];;


let parse_target_files dyntarget_file =    
  let parse_tfile  ret file =       (    
    Printf.printf "Parsing jmp targetfile %s ... \n" file;
    let contentlist = readfile file open_in in
    let doline h t = (h,t) in
    let l = List.map (fun line -> Scanf.sscanf line "0x%Lx 0x%Lx" doline) contentlist 
    in ret@l
  ) in 
    if (dyntarget_file <> "") then (
      parse_tfile [] dyntarget_file
    ) else ([])

type cmdlineargs_t = {
    mutable trace_file : string; 
    mutable ijmptarget_file : string; 
    mutable elf_list :  string list;
    mutable ida_list :  string list;
    mutable ida_idlist : int list;
    mutable allocations_file : string;
    mutable input_ijmptarget_file : string;
    mutable dyntargetlist : (int64 * int64) list;
};;
    
let parsecmdline = 
  let cmdlineargs = {
    trace_file = "";
    ijmptarget_file = "";
    elf_list = [];
    ida_list = [];
    ida_idlist = [];
    allocations_file = "";
    input_ijmptarget_file = "";
    dyntargetlist = [];
  }
  in
    (*  let speclist = Vine_tovine.speclist in   *)
  let speclist = [] in
  let arg_spec = [
    ("-input_ijmptarget", Arg.String (fun s -> cmdlineargs.input_ijmptarget_file <- s),
     "Name of the input file to read indirect jmp edges taken in the trace."); 
    ("-startfunc", Arg.Set (startfunc),
     "Use this flag if the first instruction in the trace is a function start, for which allocations should be computed."); 
    ("-insttrace", Arg.String (fun s -> cmdlineargs.trace_file <- s),
     "Name of instruction trace file"); 
    ("-out_ijmptarget", Arg.String (fun s -> cmdlineargs.ijmptarget_file <- s),
     "Name of the output file to write indirect jmp edges taken in the trace."); 
    ("-input_ijmptarget", Arg.String (fun s -> cmdlineargs.input_ijmptarget_file <- s),
     "Name of the input file to read indirect jmp edges taken in the trace."); 
    ("-elf", Arg.String (fun s -> cmdlineargs.elf_list <- s::cmdlineargs.elf_list),
     "<Elf file name>");
    ("-ida", Arg.Tuple [
       Arg.String (fun s -> cmdlineargs.ida_list <- s::cmdlineargs.ida_list);
       Arg.Int (fun i -> cmdlineargs.ida_idlist <- i::cmdlineargs.ida_idlist)],
     "<IDA file> 1");
    ("-allocations", Arg.String (fun s -> cmdlineargs.allocations_file <- s),
     "<filename> where memory activation information is stored");
  ] 
  in 
  let arg_spec = arg_spec @ speclist in 
  let () =
    Arg.parse arg_spec (fun s -> ()) 
      "Usage: traceanalysis [options] trace"
  in
  let dynlist = parse_target_files cmdlineargs.input_ijmptarget_file in
    cmdlineargs.dyntargetlist <- dynlist; 
    cmdlineargs

(*============================= Main Body ==============================*)

(* ------------------------- Call Acitvation Graph -----------------------*)


type activation = {
  mutable func_id : int64 ;
  mutable activation_id : int64 ;
};;

let print_it (finfo : Vine_tovine.funinfo_t)  = 
  let _ = Printf.printf "Start Address : %08Lx End Address : %08Lx\n" 
    (finfo.start_address) (finfo.end_address)
  in ()
;;

let rec has_label stmts lbl =
    List.exists
      (function x -> match x with 
           Label y -> 
             if ((String.compare y lbl) == 0) then  true else false
         | _ -> false)
      stmts

;;


(* Is indirect jump? *)
let is_ijmp_insn insn =
  let opcode = int_of_char insn#rawbytes.(0) in
  let intrm = (((int_of_char insn#rawbytes.(1)) lsr 3) land 7) in
  match (opcode,intrm) with
    | (0xff, 4) -> true
    | _ -> false
;;    

let check_if_sl_has_pclabel funsl eip =
  has_label funsl (addr_to_label eip)
;;

let get_function_body_by_address eip sl funinfos =
  try 
    let x = List.find (fun x -> match x with 
			   Function(a,b,c,d, Some(Block (_, funsl))) ->
			     (check_if_sl_has_pclabel funsl eip)
			   | _ -> false) sl
    in Some (x)
  with Not_found -> None

;;

let get_statcfg_from_addr fsaddr funinfos sl = 
  
  let fbody1 = (get_function_body_by_address fsaddr sl funinfos) in
    match fbody1 with 
	Some(fbody) -> 
	  let fcfg = (Vine_cfg.func_to_cfg fbody) in 
	  let _ = Vine_cfg.remove_unreachable fcfg ~consider_ind:false in
	    (match fbody with 
		 Function (a, _, _, _, _) -> 
		   Printf.printf "Doing CFG for function %s (0x%Lx) ... \n" a fsaddr;
		   Some(fcfg)
	       | _ -> None
	    ) 
      | _ -> None
;;
      
let find_function_start_by_eip eip funinfos =
  let containing_func_sa = 
    (List.fold_left (fun sa x -> 
		      if (( x.start_address <= eip) &&  (x.end_address > eip)) 
		      then x.start_address 
		      else sa
		    ) (Int64.of_int 0)  funinfos)
  in
    containing_func_sa
;;


let find_function_name_by_eip eip funinfos =
  let containing_func_sa = 
    (List.fold_left (fun sa x -> 
		      if (( x.start_address <= eip) &&  (x.end_address > eip)) 
		      then x.name 
		      else sa
		    ) ""  funinfos)
  in
    containing_func_sa
;;

let to64 (v:int32) =
  let bits = 64 - 32 in
    Int64.shift_right_logical (Int64.shift_left (I.of_int32 v) bits) bits
;;

(* sign extend to 64 bits*)
let to64 (v:int32) =
  let bits = 64 - 32 in
    Int64.shift_right (Int64.shift_left (I.of_int32 v) bits) bits
;;

let print_stackpartitions insn_counter fstart stack_partitions oc =
  match oc with
      Some (f) -> (
	(* 	Printf.fprintf f "%d %Lx " insn_counter fstart; *)
	(* 	SetOfInt32.iter (fun x -> Printf.fprintf f " 0x%lx " x) !stack_partitions; *)
	(* 	Printf.fprintf f "\n"; *)
	Marshal.to_channel f (Int64.to_int insn_counter, fstart, !stack_partitions) [];
      )
    | None -> ()
;;

let allocation_map_update func_entry_or_exit stack_partitions newsp funstart tid sl funinfos =
  let newstackoffsets = 
    if (func_entry_or_exit) then (
      (* Allocation of a new function activation record *)
      let fbody = get_statcfg_from_addr funstart funinfos sl  in
      let all_higher x = if (I.sub (to64 newsp) (to64 x) < 0L) then true else false  in
      let stack_partitions = SetOfInt32.filter all_higher stack_partitions  in
      let newset = (
	match fbody with 
	    Some (fcfg) -> 
	      let offsetlist = Vine_dataflow.get_local_vars fcfg  in
	      let convert_s64_to_s32 x l = SetOfInt32.add (Int32.add newsp (I.to_int32 x)) l in
	      let adjustedoffsets = Vine_dataflow.SetOfInt64.fold convert_s64_to_s32 offsetlist SetOfInt32.empty in
		SetOfInt32.fold (fun x s -> SetOfInt32.add x s) stack_partitions adjustedoffsets 
	  | None -> SetOfInt32.add newsp stack_partitions) in
	newset
    ) else (stack_partitions) 
  in
    Printf.printf "TID : %Ld StackOffsets : ESP 0x%lx ->>" tid newsp;
    SetOfInt32.iter (fun x -> Printf.printf " 0x%lx, " x) newstackoffsets;
    Printf.printf "\n";
    newstackoffsets
;;

let build_activation_tree args funinfos sl allocfile  =
  (* Mapping from activation -> List of trace offset pairs. Pair [A,B)
     :-> A is inclusive, B is 1 over the included in the range *)
  let (activ_history :  (int64, (int64 * int64) array) Hashtbl.t ) = Hashtbl.create 200 in
  let call_insn = ref 0L in
  let curr_range_start = ref 1L in
  let found_call = ref false in
  let found_ijmp = ref false in
  let ijmp_from = ref 0L in
  let ijmp_to = ref 0L in
  let curr_fstart = ref (0L, 0L) in
  let stack_partitions = ref SetOfInt32.empty in
  let record_esp = ref false in
  let (retaddr_stack : (int64 (*RA*)* (int64 (*FStart*)* int64(*TraceID*)) * int32(*StartESP*))  Stack.t) = Stack.create ()   in
  let (activ_stack : int64  Stack.t) = Stack.create ()   in

  let allocated_activ_no = ref (Int64.of_int (-1)) in
  let trace= Trace.open_trace args.trace_file in

  let ijmp_file = if (args.ijmptarget_file <> "") then Some(open_out args.ijmptarget_file) else None in
  let print_activ_history l = 
    Printf.printf "Printing activation history\n-------------------------\n";
    Hashtbl.iter (fun x y -> 
		    Printf.printf "%08Lx ->" x;
		    Array.iter (fun (a,b) -> Printf.printf " [%Ld, %Ld] " a b) y ;
		    Printf.printf "\n"
		 ) activ_history
  in

  let update_range x y = (
    let ano = try Stack.top activ_stack 
    with Stack.Empty -> -1L
    in 
    let newelem = try 
      let elem = Hashtbl.find activ_history ano in
	Array.append elem (Array.make 1 (x,y));
    with 
	Not_found ->  (Array.make 1 (x,y));
    in Hashtbl.replace activ_history ano newelem
  ) in
    
  let rec handle_inst trace2 =
    let inst_o =
      try
	Some(trace2#read_instruction)
      with
          IO.No_more_input -> None
    in match inst_o with
	None -> ()
      | Some(inst) ->
	  let _ = (
	    if (!startfunc) then (
	      startfunc := false;
	      let newesp = inst#esp#opvalue in
	      let fstart = inst#address in
		stack_partitions := allocation_map_update true !stack_partitions newesp fstart  (trace2#insn_counter) sl funinfos;
		print_stackpartitions trace2#insn_counter fstart stack_partitions allocfile; 
		
	    );

	    if (!found_call && (I.compare inst#address !call_insn == 0))
	    then (Printf.fprintf stderr "TEMU Bug : Multiple call insn records at trace id : %Ld\n" trace2#insn_counter)
	    else (
	      (* Update the range of addresses as belonging to the curr_activ*)
	      if (!found_call)   then (
		update_range (!curr_range_start) (trace2#insn_counter);
		Printf.printf "Entered function %08Lx(%s) from %08Lx\n" 
		  (inst#address) (find_function_name_by_eip (inst#address) funinfos) !call_insn;
		found_call := false;  
		curr_fstart := (inst#address, trace2#insn_counter);
		allocated_activ_no := (Int64.add (!allocated_activ_no) (Int64.of_int 1));
		let get_new_activ_number = !allocated_activ_no in 
 		  Stack.push (get_new_activ_number) activ_stack; 
		  curr_range_start := (trace2#insn_counter);
		  if (not(Stack.is_empty retaddr_stack)) then (
		    let (a, (b1,b2), c) = Stack.pop retaddr_stack in
		      Stack.push (a, !curr_fstart , c) retaddr_stack;
		  );
	      );
	      
	      (* Record the first ESP value known in this function *)
	      if (!record_esp) then (
		if (inst#esp#opvalue <> 0l && not(Stack.is_empty retaddr_stack)) then ( 
		  record_esp := false;
		  let newesp = inst#esp#opvalue in
		  let (a,(fstart,t),c) = Stack.pop retaddr_stack in
		    Stack.push (a,(fstart,t),newesp) retaddr_stack;
		    stack_partitions := allocation_map_update true !stack_partitions newesp fstart (trace2#insn_counter) sl funinfos;
		    print_stackpartitions trace2#insn_counter fstart stack_partitions allocfile; 
		);
	      );
	      
	      (* Record that we have found a call *)
	      if (Reg_x86.is_call inst#rawbytes) then (  
		found_call := true;
		call_insn := inst#address;
		record_esp := true;
		let insnlen = 5 (* Need an interface to read the instruction length -- Libasmir.get_i386_insn_length inst#rawbytes  *) in
		let ra = I.add inst#address (I.of_int (insnlen)) in
		  Stack.push (ra, (0L, -1L), 0l) retaddr_stack;
	      );
	      
	      
	      (* Record indirect jumps and targets seen in the trace *)
	      if (!found_ijmp) then (
		ijmp_to := inst#address;
		found_ijmp := false;
		match ijmp_file with 
		    Some (f) -> Printf.fprintf f "0x%Lx 0x%Lx\n" !ijmp_from !ijmp_to
		  | None -> ()
	      );
	      if (is_ijmp_insn inst)  then (
		found_ijmp := true;
		ijmp_from := inst#address;
	      );
	      
	      let dummy = (0L,(0L, 0L),0l) in
	      let (exitfid, (exitfstart, _), espfst) = 
		try Stack.top retaddr_stack with Stack.Empty -> dummy in
		if (exitfid <> inst#address) 
		then () 
		else (
		  update_range (!curr_range_start) (trace2#insn_counter);
		  Printf.printf "Leaving function : returning at (%s) PC : %08Lx, with expected ESP :0x%lx\n" 
		    (find_function_name_by_eip (inst#address) funinfos) (exitfid) (espfst);
		  curr_fstart := (exitfstart, trace2#insn_counter); 
		  record_esp := false;
		  stack_partitions := allocation_map_update false !stack_partitions espfst exitfstart (trace2#insn_counter) sl funinfos;
		  print_stackpartitions trace2#insn_counter inst#address stack_partitions allocfile; 
		  
		  let _ = try Stack.pop retaddr_stack with Stack.Empty -> dummy  in 
		  let _ = try Stack.pop activ_stack with Stack.Empty -> 0L in ();
		    curr_range_start := (trace2#insn_counter);
		);
	    ) 
	  )
	  in 
	    handle_inst trace2
  in
  let l = handle_inst trace in
    Trace.close_trace trace;
    print_activ_history l;
    let () = (match ijmp_file with 
		  Some (f) -> close_out f
		| None -> ()) in
      (activ_stack, retaddr_stack, activ_history)
	
;;

(* ------------------------- Call Acitvation Graph End -----------------------*)

(* The idea is to add paths to the trace incrementally. Here are the
   steps :

   1. Get a list of active activations at the point of the
   vulnerability.

   2. For each branch condition in the trace, find the join point in
   the trace. This forms an address pair (B,J).

   3. Compute a chop C on (B,J)

   4. Eliminate paths in C that are already taken ,have calls , have
   symbolic memory accesses, or those that traverse the back-edge of
   loops.

   5. Augment the IR with if-else structures and Pass it to Zhenkai's
   module for converting to IR.
   
*)


let write_cfg cfg os =
  Vine_graphviz.VineStmtsDot.output_graph os cfg
;;

let output_cfg file cfg =
  let fd = open_out file in
    write_cfg cfg fd
;;


let print_execinsnlist alist =
  Printf.printf "Executed Insn Addresses : \n";
  let _ =  List.iter (fun x -> Printf.printf " %08Lx ," x) alist in
    Printf.printf "\n";
    ()
;;

let find_addrlbl_in_cfg cfg label =
  let retlist = ref [] in
    cfg#iter_bb (fun bb ->
		   if (has_label (cfg#get_info bb) label) 
		   then (
		     retlist := !retlist @ [bb]; ()
		   )
		   else ()
		);
    !retlist
;;

let print_postdoms postdomlist brnchblk joinblk =
  Printf.printf "Post Doms for blkids <%s , %s> :-\n" (Vine_cfg.bbid_to_string brnchblk) (Vine_cfg.bbid_to_string joinblk);
  List.iter (fun x -> Printf.printf " %s " (Vine_cfg.bbid_to_string x)) postdomlist;
  Printf.printf "\n"
;;


(** 
    Finds the join point of a branch instruction, as the first
    instruction in the trace that is a post-dom of the branch insn.
 **)
 let get_join_point cjmpaddr execinsn_list statcfg =

   let cjmp_blklist = (find_addrlbl_in_cfg statcfg (addr_to_label cjmpaddr)) in
   let branchblk = List.hd cjmp_blklist in
   let {POSTDOM.dominators=get_postdoms} = POSTDOM.compute_all statcfg Vine_cfg.BB_Exit in
   let first_point = ref (Int64.of_int 0) in
   let () = List.iter (fun (x, x_entry) -> 
			 let jpt_blklist = (find_addrlbl_in_cfg statcfg (addr_to_label x)) in

			   List.iter 
			     (fun joinblk ->
				let blk = (statcfg#get_id joinblk) in
				let postdom_list = get_postdoms (statcfg#get_id branchblk) in
				let _ = print_postdoms postdom_list (statcfg#get_id branchblk) blk in 
				  if (List.exists (fun x -> 
						      if ((String.compare (Vine_cfg.bbid_to_string x) (Vine_cfg.bbid_to_string blk)) == 0)
						      then true else false) postdom_list)
				  then ( 
				    first_point := x 
				  ) 
				  else ()	
		      ) jpt_blklist
		      ) execinsn_list
   in 
     !first_point 
 ;;


 let print_cjmppart cjmpaddr combined_execlist = 
   Printf.printf "Cjmp %08Lx :: Processing insns in order \n" cjmpaddr;
   List.iter (fun (x,y) -> Printf.printf "%08Lx (%d)\n" x y) combined_execlist
 ;;

 let read_instruction trace n =
   let old_tid = trace#insn_counter in
     trace#seek_instruction n;
     let inst = trace#read_instruction in
       trace#seek_instruction old_tid;
       inst
 ;;

 let print_cjmplist cjmplist cjmps_entries execinsn_list execinsn_entries statcfg =


   Printf.printf "CJMP Addresses : \n";
   let combined_cjmplist = List.combine cjmplist cjmps_entries in
   let combined_execlist = List.combine execinsn_list execinsn_entries in
   let _ =  List.iter (fun (x, x_entry) ->
			 let filtered_execlist = 
			   List.filter (fun (i, i_entry) -> if (i_entry > x_entry) then true else false)
			     combined_execlist in
			   print_cjmppart x filtered_execlist;

			   let jpt = get_join_point x filtered_execlist statcfg in
			     Printf.printf "<%08Lx , %08Lx> \n" x jpt) combined_cjmplist in
     Printf.printf "\n";
     ()
 ;;

 let parseallfiles args =
   let do_elffile (f,d,s) file =
     Printf.printf "Parsing Elf file %s ... \n" file;
     let (prog,finfos) = Vine_tovine.from_elf true file in 
     let (dl,sl) = Vine_tovine.replace_calls_and_returns prog finfos in 
       (finfos@f, dl@d, sl@s)
   in
   let do_idafile (f,d,s) file =
     Printf.printf "Parsing IDA db file %s ... \n" file;
     let (prog,finfos) = Vine_tovine.from_ida true file 1 in 
     let (dl,sl) = Vine_tovine.replace_calls_and_returns prog finfos in 
       (finfos@f, dl@d, sl@s)
   in
   let (funinfos1, dl1, sl1) =  List.fold_left do_elffile ([],[],[]) args.elf_list in
     List.fold_left do_idafile (funinfos1, dl1, sl1) args.ida_list 
 ;;
 
 let args = parsecmdline in
 let (funinfos, dl, sl) =  parseallfiles args in
 let () = List.iter (fun x -> print_it x)  funinfos in
 let allocfile = if (args.allocations_file <> "") then Some (open_out_bin args.allocations_file) else None in
 let (activ_stack, retaddr_stack, activ_history) = build_activation_tree args funinfos sl allocfile in
(* let act_stack = Stack.copy activ_stack in*)

 let trace= Trace.open_trace args.trace_file in
(* let func_by_activ_number tofind =
   let arr_insnranges = Hashtbl.find activ_history tofind in
   let (a,b) = Array.get arr_insnranges 0 in
   let inst = read_instruction trace (a) in
     Printf.printf "func_by_activ_number :: (trace no :%Ld) %s\n" (a) (find_function_name_by_eip inst#address funinfos);
     find_function_start_by_eip inst#address funinfos

 in
*)
   (*let func_insnrange_by_activ_number tofind =
     let arr_insnranges = Hashtbl.find activ_history tofind in
     arr_insnranges
     in
   *)
(*let (active_function_starts_stack : int64 Stack.t) = Stack.create () in *)
(*   Printf.printf "Active activations : \n";     *)
(*   Stack.iter (fun x ->  *)
(* 		Stack.push (func_by_activ_number x) active_function_starts_stack ; *)
(* 		Printf.printf "%08Lx\n" (Stack.top active_function_starts_stack); ) act_stack; *)
  Printf.printf "\nActive Return Addresses : \n";    
  Stack.iter (fun (x, (y,ty), z) -> Printf.printf "%08Lx in Function %08Lx(ESP :%lx)\n"  x y z) retaddr_stack;
  
  
(*    let prog =  *)
(*      (\* build ir trace from execution trace *\) *)
(*      let filters =  *)
(*        [new disasm_all; *)
(*        ]  *)
(*      in *)
(*      let handle_one_activ x = ( *)
(*        let insnarr = func_insnrange_by_activ_number x in *)
(*        let trace_prog, trace_insns, trace_entries = disasm_trace_range args.trace_file filters insnarr in *)
(*        let (cjmpslist, cjmps_entries) = trace_to_list_of_cjmps trace_prog trace_insns trace_entries in  *)
(*        let (exec_insn_list, exec_insn_entries) = trace_to_list_of_exec_insns trace_prog trace_insns trace_entries in  *)
(*        let staticcfg = (get_statcfg_from_addr (func_by_activ_number x) funinfos sl exe) in  *)
(* 	 (match staticcfg with *)
(* 	      Some (statcfg) ->  *)
(* 		let _ = print_endline "Printing CFG as dot file" in *)
(* 		let fd = open_out "tmp.dot" in *)
(* 		let _ =  Vine_cfg.print_dot_cfg statcfg "tmp" Vine_cfg.stmt_printer fd in   *)
		  
(* 		let () = (print_cjmplist cjmpslist cjmps_entries exec_insn_list exec_insn_entries statcfg)   *)
(* 		in () *)
(* 	    | _ -> () *)
(* 	 )) in *)
(*        Stack.iter (fun x -> handle_one_activ x) activ_stack; *)
(*    in *)
   Trace.close_trace trace;
   match allocfile with
       Some (f) -> close_out f
     | None -> ()
	 
	 
