(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
open Digest

let tracepool = ("127.0.0.1", 12001);;
let inputpool = ("127.0.0.1", 12002);;
let db_controller = ("127.0.0.1", 12666);;
let input_controller = ("127.0.0.1", 12777);;

let tmp_prefix = "/tmp/tmpfiles/";;

Random.self_init ();;

let rec sockread sock buf ofs len = 
  let _ = Unix.select [sock] [] [] (float (0-1)) in
  let chars_read = Unix.read sock buf ofs len in
  if chars_read < len then 
    sockread sock buf (ofs + chars_read) (len - chars_read);;

let rec retry_connect attempts sock sock_addr =
  let _ = try Unix.connect sock sock_addr 
     with e -> if attempts < 10 then
         let _ = print_string "Retrying connection...\n" in
         let _ = flush stdout in
	 Unix.sleep(5);
	 retry_connect 0 sock sock_addr
     else
        raise e
    in
    ();;

let connect addr_str port = 
  let sd = Unix.socket Unix.PF_INET Unix.SOCK_STREAM 0 in
  let server_addr =
    try Unix.inet_addr_of_string addr_str
    with _ -> failwith "Invalid IP address in connect"
  in
  let sock_addr = Unix.ADDR_INET (server_addr, port) in
  let _ = retry_connect 0 sd sock_addr in
  sd;;

let shutdown sd = Unix.shutdown sd Unix.SHUTDOWN_ALL;;

let read_byte sd =
  let buf = String.create 1 in
  let _ = sockread sd buf 0 1 in
  Char.code buf.[0];;

let write_byte sd i =
  let buf = String.create 1 in
  let ord = Char.chr i in
  let _ = buf.[0] <- ord in
  Unix.write sd buf 0 1;;

let read_i32 sd =
  let buf = String.create 4 in
  let _ = sockread sd buf 0 4 in
  let result = IO.read_i32 (IO.input_string buf) in
  result;;

let write_i32 sd i =
  let os = IO.output_string () in
  let () = IO.write_i32 os i in
  let buf = IO.close_out os in
    Unix.write sd buf 0 4;;

let read_real_i32 sd =
  let buf = String.create 4 in
  let _ = sockread sd buf 0 4 in
    IO.read_real_i32 (IO.input_string buf);;

let write_real_i32 sd i =
  let os = IO.output_string () in
  let () = IO.write_real_i32 os i in
  let buf = IO.close_out os in
    Unix.write sd buf 0 4;;

let read_double sd =
    let buf = String.create 8 in
    let _ = sockread sd buf 8 in
	IO.read_double (IO.input_string buf);;

let write_double sd d =
    let os = IO.output_string () in
    let () = IO.write_double os d in
    let buf = IO.close_out os in
	Unix.write sd buf 0 8;;

let read_string sd = 
  let len = read_i32 sd in
  let buf = String.create len in 
  let _ = sockread sd buf 0 len in
  buf;;

let write_string sd str = 
  let len = String.length str in
  let _ = write_i32 sd len in
  Unix.write sd str 0 len;;

let read_file sd = read_string sd;;

let write_file sd filepath = write_string sd;;

