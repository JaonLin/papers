(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
let addr = (Unix.inet_addr_of_string "127.0.0.1", 12002);;

type input_info = {
  ii_id : int;
  ii_priority: int;    (* priority for this input *)
  ii_input : string;     (* input used to generate this trace *)
}

type t = input_info

let should_print = true;;

let key t =
  t.ii_priority;;

let name = "input";;
let key_name = "priority";;

let digests = ref [];;

let m = Mutex.create ()

let compare a b =
  let comp = Pervasives.compare a.ii_priority b.ii_priority in
  if (comp <> 0) then comp
  else Pervasives.compare b.ii_input a.ii_input;;

let marshal_object sd ii =
  let _ = Netcomm.write_i32 sd ii.ii_id in
  let _ = Netcomm.write_i32 sd ii.ii_priority in
  let _ = Netcomm.write_string sd ii.ii_input in
  ();;

let unmarshal_object sd =
  let a0 = Netcomm.read_i32 sd in
  let a1 = Netcomm.read_i32 sd in
  let a2 = Netcomm.read_string sd in
    { ii_id = a0;
      ii_priority = a1;
      ii_input = a2
    };;

let cond_func item = true;;

let print ii =
    Printf.printf " %s, " ii.ii_input;;

let reject ii = (ii.ii_input = "") or (
  let () = Mutex.lock m in
  let this_digest = Digest.to_hex (Digest.string ii.ii_input) in
  let find_item found list_item =
    (found || (list_item = this_digest)) 
  in
  let in_list = List.fold_left find_item false !digests in
  let () = 
    if not in_list then (digests := this_digest :: !digests) else () 
  in
  let () = Mutex.unlock m in
    in_list
);;
