(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
open Msg
open Prototree
module D = Debug.Make(struct let name = "protoloops" and default=`Debug end)
open Trace_loops 
open Vine_util
module Int = struct type t = int let compare = compare end
module FieldIDLenPair = struct type t = (int * int) let compare = Int.compare end
module SetOfFieldData = Set.Make(FieldIDLenPair);;   
module SetOfInt = Set.Make(Int);;

type cmdargs_t = {
  mutable in_tree_l : Prototree.prototree list;
  mutable in_trace_filename : string;
  mutable in_loop_filename : string;
  mutable out_protoloop_file : string;
  mutable in_protoloop_file : string;
} ;;



(* Walk the tree elements make a list of fields ranges *)

let make_field_ranges fldtbl tree =
  let iter_leaves (elem :Msg.element) = 
    match elem.content with 
      | Msg.Fld (f) -> (
	  match f.fld_type with
	    | Msg.VarLen (_) ->
		Printf.printf " [%d %d] " elem.pos.rstart elem.pos.rend;
		Hashtbl.add fldtbl elem.el_id (elem.el_name, elem.pos.rstart, elem.pos.rend);
	    | _ -> ())
      | _ -> ()
  in Prototree.iter iter_leaves tree
;;

let serialize file (info : (loop * SetOfFieldData.t) list) = 
  Marshal.to_channel file info [] 
;;

let unserialize : in_channel -> (loop * SetOfFieldData.t) list =
  fun file -> Marshal.from_channel file
;;

let default_protoloops = []

let print_protoloops oc info =
  List.iter (
    fun (l,s) ->
      Printf.fprintf oc "Loop: \n";
      print_loop oc l;
      Printf.fprintf oc "Set: { ";
      SetOfFieldData.iter (fun (i1,i2) -> Printf.printf "(%d,%d) " i1 i2) s;
      Printf.fprintf oc "}\n";
  ) info
;;

let get_bkedges loop_info_l =
  List.fold_left (
    fun acc1 l ->
      List.fold_left (fun acc2 be -> (be, l.header_eip) :: acc2)
	acc1 l.back_edges
  ) [] loop_info_l
;;

let get_bkedges_from_file file =
  let readfile fname openfn =
    let cin = openfn fname in
    let rec aux acc = try aux ((input_line cin)::acc)
    with End_of_file -> close_in cin; List.rev acc
    in aux []
  in
  let contentlist = readfile file open_in in
  let doline h t = (h,t) in
    List.map (fun line -> Scanf.sscanf line "%Lx %Lx" doline) contentlist
;;
