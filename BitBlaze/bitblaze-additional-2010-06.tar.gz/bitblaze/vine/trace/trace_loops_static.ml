(*
 Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
  Methods to extract loops from a trace using the Affine loop detection module
    It requires: 
      a) identifying all modules (dll and exe files) present in the trace, 
      b) extracting IDAPro DB files for those modules,
      c) generating an IR for those modules,
      d) extracting loops in those IRs
      e) find loops in trace using information from step e)
*)

module Trace = Temu_trace
open Trace
open Vine
open Vine_util
open Insn_classifier
open Trace_loops
module D = 
  Debug.Make(struct let name = "traceloops_static" and default=`NoDebug end)


(* Get module load address from Sqlite3 DB *)
let get_mod_load_addr_from_db db_filename =
    let db = Sqlite3.db_open db_filename in
    let infos = Vine_idadb.get_idainfos db in
    let num_infos = List.length infos in
    if (num_infos > 1) then failwith "More than one fileid in DB!";
    let info_node = List.hd infos in
    let (file_id,_,_,_,load_addr,_,_,_,_,_,_,_) = info_node in
    load_addr

(* Get BBID string from BB *)
let bbid_str_from_bb cfg bb = 
  let bbid = cfg#get_id bb in
  try Vine_cfg.bbid_to_string bbid
  with _ -> "unknown"

(* Determine if a string is a PC label *)
let is_pc_label_str label_str =
  if (String.length label_str < 5) then false
  else (String.sub label_str 0 5 = "pc_0x")

(* Get eip from label *)
let get_eip_from_label s =
  try
    let header =  Scanf.sscanf s "pc_%s" (fun y-> y) in
    let len =
      try String.index header '_'
      with Not_found -> String.length header
    in
    let pc = String.sub header  0 len in
      Scanf.sscanf pc "0x%Lx" (fun x -> x) 
  with _ ->  0L
    

(* Find labels in a Basic Block. Useful to identify EIPs in BB *)
let get_labels_in_bb 
    ?(ignore_jmp_targets=true) ?(ignore_internal_labels=true) cfg bb =
  let bb_sl = cfg#get_info bb in
  let process_stmt l stmt =
    match stmt with
      | Vine.Label(s) when (is_pc_label_str s) -> s :: l
      | Vine.Label(s) ->
          if (not ignore_internal_labels)
            then s :: l
            else l
      | Vine.Jmp(Vine.Name(s)) when (is_pc_label_str s) -> 
	  if (not ignore_jmp_targets) then s :: l else l
      | _ -> l
  in
  let l = List.fold_left process_stmt [] bb_sl in
  List.rev l


module LoopHelper(Lang : sig type t end) =
struct
  type t = Lang.t Vine_cfg.cfg
  module G = Vine_cfg.MakeG(Lang)
  module DOM = Dominator.Make (G)
  module PDOM = Dominator.Make (
    struct
      type t = G.t
      module V = G.V
      let pred = G.succ
      let succ = G.pred
      let fold_vertex = G.fold_vertex
      let iter_vertex = G.iter_vertex
      let nb_vertex = G.nb_vertex
    end
  )

  let get_dom cfg entry =
    let {DOM.dom=dom} = DOM.compute_all cfg entry in
      dom

  let get_pdom cfg exit_node =
    let {PDOM.dom=dom} = PDOM.compute_all cfg exit_node in
      dom

  let get_doms cfg entry =
    let {DOM.dominators=dominators} = DOM.compute_all cfg entry in
      dominators

  let check_if_back_edge cfg (s,e) =
    let dominators_func = get_doms cfg Vine_cfg.cfg_entry in
    let doms_of_s = dominators_func s in
      List.exists (fun x -> (x = e)) doms_of_s (* back_edge *)

end
module LH = LoopHelper(struct type t = stmt list end);;


(* Backedges may sometimes have nodes that do not have PC labels.
   This function tries to identify the appropriate PC label for the src
   and the dst of the edge by traversing the CFG starting from the src/dst
   node.

   Param [src flag] controls whether to locate pc for src(true) or dst(false).
   Specifically: To locate the src, we start from the bottom of src BB and
   do backward traversal. To locate the dst, we start from the top of dst BB
   and do forward traversal.

   Algorithm: Perform breadth-first traversal in the direction explained
   above, from the starting node [bb_id]. Whenever the visiting node dominate
   (src_flag=true) or post-dominate (src_flag=false) the starting node [bb_id],
   try to locate pc label in that BB node. If found, stop traversal and 
   report the found label. Otherwise, keep on traversal until finish.

   Explanation: The first dominator/post-dominator found along the
   breadth-first traversal is always the immediate dominator/post-dominator.

   Assumption: The appropriate pc node should always be found quickly so
   the traversal is rarely split to 2 paths. However, if it does, there must 
   be no pc label along those paths, before they merge.

   Important: This function assume a perfect VinE CFG with pc labels.
   Perfect means there is no edge to "BB_Error". Such edges can occur
   when we miss "function chunks" in IDA Pro DB.
   
   Important2: Edges to "BB_Indirect" would cause this function return
   no pc label for dst node. This is obviously a correct behavior.
*)
let first_reachable_pc src_flag cfg dom pdom bb_id =
  (* get a pc from a basic block, if possible *)
  let get_pc this_bb_id =
    let this_bb_labels = get_labels_in_bb cfg (cfg#find this_bb_id) in
      if this_bb_labels <> []
      then Some ( if src_flag 
		  then ExtList.List.last this_bb_labels
		  else List.hd this_bb_labels )
      else None
  in
  let get_next_bbids = 
    if src_flag 
    then fun bbid -> List.map cfg#get_id (cfg#pred (cfg#find bbid))
    else fun bbid -> List.map cfg#get_id (cfg#succ (cfg#find bbid))
  in
  let is_candidate =
    let has_only_dom_so_far = ref true in
      if src_flag
      then fun x q -> 
	(if not (Queue.is_empty q) then has_only_dom_so_far := false);
	!has_only_dom_so_far || dom x bb_id
      else fun x q -> 
	(if not (Queue.is_empty q) then has_only_dom_so_far := false);
	!has_only_dom_so_far || pdom x bb_id
  in
  let h = Hashtbl.create cfg#length in
  let q = Queue.create () in
  let found = ref None in
  let push v =
    if not (Hashtbl.mem h v) then begin
      Hashtbl.add h v ();
      Queue.add v q
    end
  in
    push bb_id;
    while not (!found <> None || Queue.is_empty q) do
      let v = Queue.pop q in
	if is_candidate v q then (* this node is (post)-dominator *)
	  found := get_pc v;
	List.iter push (get_next_bbids v);
    done;
    !found

(* Get statement from block, given the index in the block. 
In addition it returns the EIP that contains that statement *)
let get_stmt_in_bb ssacfg bb_id pos =
  let bb = ssacfg#find bb_id in
  let bb_sl = ssacfg#get_info bb in
  let iv_stmt = List.nth bb_sl pos in
  let iv_stmt_str = Ssa.stmt_to_string iv_stmt in
  let process_ssa_stmt lab ssa_stmt =
    match ssa_stmt with
        | Ssa.Label(s) when (is_pc_label_str s) ->
            let addr = get_eip_from_label s in
            addr
        (* Special case for instructions with rep prefix *)
        | Ssa.CJmp(_,Ssa.Name(s),_) when (lab=0L) ->
            let addr = get_eip_from_label s in
            addr
        | _ -> lab
  in
  let eip = List.fold_left process_ssa_stmt 0L bb_sl in
  (eip,iv_stmt_str)

(* Print loop info *)
let print_loop_info oc info =
  Printf.fprintf oc "%s %s 0x%08Lx "
    info.module_name info.fun_name info.header_eip;
  (* Print back edges *)
  let num_backs = List.length info.back_edges in
  Printf.fprintf oc "%d " num_backs;
  let print_exit s =
    Printf.fprintf oc "0x%08Lx " s
  in
  List.iter print_exit info.back_edges;
  (* Print exit edges *)
  let num_exits = List.length info.exit_edges in
  Printf.fprintf oc "%d " num_exits;
  let print_exit (s,e) =
    Printf.fprintf oc "0x%08Lx->0x%08Lx " s e
  in
  List.iter print_exit info.exit_edges;
  (* Print induction variables *)
  let num_ivs = List.length info.iv_info_l in
  Printf.fprintf oc "%d " num_ivs;
  let print_iv iv_info =
    let (eip,stmt_str) = iv_info in
    Printf.fprintf oc "IV: 0x%08Lx %s" eip stmt_str
  in
  List.iter print_iv info.iv_info_l;
  Printf.fprintf oc "\n"

let read_ijmps_from_file filename =
  let scanbuf = Scanf.Scanning.from_file filename in
  let unique_htbl = Hashtbl.create 13 in
  let rec parse_file () =
    let eof =
      try
	Scanf.bscanf scanbuf "0x%Lx 0x%Lx " 
	  (fun h t -> Hashtbl.replace unique_htbl (h,t) ());
	false
      with End_of_file -> true
    in
      if eof then () else parse_file ()
  in
    parse_file ();
    Hashtbl.fold (fun a _ c -> a :: c) unique_htbl []

(* Read loop info file *)
let read_loop_info_from_file filename =
  let ic = open_in filename in
  let loop_info_l = ref [] in
  let rec read_all_instructions () =
    let line = input_line ic in
    let token_list = Str.split (Str.regexp " ") line in
    let num_tokens = List.length token_list in
    if (num_tokens < 5) then failwith "Incorrect format in loop file";
    let entry_eip = Int64.of_string (List.nth token_list 2) in
    let num_be = int_of_string (List.nth token_list 3) in
    let num_ee = int_of_string (List.nth token_list (num_be + 4)) in
    let num_ivs = int_of_string (List.nth token_list (num_ee + num_be + 5)) in
    let be_l =
      List.rev (
	let l = ref [] in
	  for i = 4 to 4 + (num_be-1) do
	  let be_label = Int64.of_string (List.nth token_list i) in
	    l := be_label :: !l
	  done;
	  !l
      )
    in
    let ee_l =
      List.rev (
        let l = ref [] in
          for i = (num_be+5) to (num_be+5) + (num_ee-1) do
          let exit_edge_str = List.nth token_list i in
          let token_list_edge = Str.split (Str.regexp "->") exit_edge_str in
          let src_label = Int64.of_string (List.nth token_list_edge 0) in
          let dst_label = Int64.of_string (List.nth token_list_edge 1) in
            l := (src_label,dst_label) :: !l
          done;
          !l
      )
    in
    let iv_l =
      List.rev (
        let l = ref [] in
          for i = 0 to (num_ivs - 1) do
          let iv_st_idx = num_ee + num_be + 6 + 9*i in
          let iv_eip = Int64.of_string (List.nth token_list (iv_st_idx + 1)) in
            l := (iv_eip,"") :: !l
        done;
        !l
      )
    in
  let info =
      {
        module_name = List.nth token_list 0;
        fun_name = List.nth token_list 1;
        header_eip = entry_eip;
        exit_edges = ee_l;
	back_edges = be_l;
        iv_info_l = iv_l;
      }
  in
    loop_info_l := info :: !loop_info_l;
    read_all_instructions ()
  in
  let _ =
    try
      read_all_instructions ()
    with
      End_of_file -> close_in ic
  in
  List.rev !loop_info_l

(* Extract loops statically from IR using Affine code *)
let get_loop_info_from_ir ?(do_dot=false) ?(ijmps=[]) 
    start_addr module_name ir_filename = 
  (* Get IR program from file *)
  let prog = Trace_slice.get_ir_from_file ir_filename in
  let (dl,sl) = prog in

  (* Get loops for all functions in IR *)
  let prog_loop_l =
    let vis =
      object(self)
        inherit nop_vine_visitor

        val mutable loop_l = []

        method get_loop_l = loop_l

        method visit_stmt stmt =
          match stmt with 
            Function (name,ret_t,arg_l,is_ext,fun_sl_opt) ->
              (match fun_sl_opt with 
                | Some(Block(fun_dl,fun_sl)) -> (
                  try (
                    let fun_dl = Trace_slice.get_dl_from_sl fun_sl in
                    let fun_prog = (fun_dl,fun_sl) in

                    D.dprintf "In function: %s\n" name;

                    (* Get the CFG *)
                    D.pdebug "Extracting CFG";
                    let fun_cfg = Vine_cfg.prog_to_cfg fun_prog in

		    (* Add known indirect jump edges to CFG *)
		    D.pdebug "Adding known indirect jump edges";
		    let _ =
		      Vine_cfg.add_indirect_jumps fun_cfg ijmps
		    in

                    (* Remove unreachable nodes from CFG *)
                    D.pdebug "Removing unreachable nodes";
                    let _ =
                      Vine_cfg.remove_unreachable ~consider_ind:false fun_cfg
                    in

                    (* Make CFG reducible *)
                    D.pdebug "Making CFG reducible";
                    let fun_rcfg = Vine_loop.get_reducible fun_cfg in

                    (* Coalesce the CFG *)
                    D.pdebug "Coalescing CFG";
                    Vine_cfg.coalesce_bb fun_rcfg;

                    (* Extract loops *)
                    D.pdebug "Extracting loops";
                    let fun_loop_l = Vine_loop.get_loops ~combine_method:Vine_loop.UniqueHeader fun_rcfg in

		    (* Extract dom/pdom *)
		    let fun_dom = LH.get_dom fun_rcfg Vine_cfg.BB_Entry in
		    let fun_pdom = 
		      try
			LH.get_pdom fun_rcfg Vine_cfg.BB_Exit 
		      with Not_found -> fun _ _ -> false (* no path to exit *)
		    in

		    (* Print CFG as dot file *)
		    if (do_dot) then (
                      let dot_filename = Printf.sprintf "%s.dot" name in
		      let oc = open_out dot_filename in
		      let _ = 
			Vine_cfg.print_dot_cfg fun_rcfg name 
			  Vine_cfg.stmt_printer oc 
		      in
		      close_out oc
		    );

                    D.dprintf "Found %d loops\n" (List.length fun_loop_l);

                    (* Iterate through loops in function *)
                    let process_loop loop =
                      let header_bb = Vine_loop.get_loop_header loop in
                      (* let body_bb_l = Vine_loop.get_loop_body loop in *)
		      let back_edges_l = Vine_loop.get_loop_back_nodes loop in
                      let exit_edges_l =
                        Vine_loop.get_loop_exit_edges loop fun_rcfg
                      in

		      (* Debug printouts *)
		      if (D.debug) then (
			(* Debug header printout *)
			let header_bbid = fun_rcfg#get_id header_bb in
			D.dprintf "\tHead BBID: %s\n" 
			  (Vine_cfg.bbid_to_string header_bbid);

			(* Debug back edges printout *)
			let print_backedge bb =
			  let backedge_str =
			    try
			      let backedge_bbid = fun_rcfg#get_id bb in
			      Vine_cfg.bbid_to_string backedge_bbid
			    with _ -> "unknown"
			  in
			  D.dprintf "\tBack BBID: %s\n" backedge_str;
			in
			List.iter print_backedge back_edges_l;

			(* Debug exit edges printout *)
			let print_exitedge (bb,_) =
			  let exitedge_str =
			    try
			      let backedge_bbid = fun_rcfg#get_id bb in
			      Vine_cfg.bbid_to_string backedge_bbid
			    with _ -> "unknown"
			  in
			  D.dprintf "\tExit BBID: %s\n" exitedge_str;
			in
			List.iter print_exitedge exit_edges_l;
		      );

                      let header_labels =
                        get_labels_in_bb fun_rcfg header_bb
                      in
                      let back_labels =
                        let add_labels l bb =
			  let src_label =
			    let src_bbid = fun_rcfg#get_id bb in
			    let src_lab = first_reachable_pc true fun_rcfg 
			      fun_dom fun_pdom src_bbid
			    in
			      match src_lab with
				  None -> 
				    failwith "cannot find backedge's label"
				| Some x -> x
			  in
                            src_label :: l
                        in
                          List.fold_left add_labels [] back_edges_l
                      in
                      let exit_labels =
                        let add_label l (src,dst) =
			  let src_bbid = fun_rcfg#get_id src in
			  let dst_bbid = fun_rcfg#get_id dst in
			    if dst_bbid = Vine_cfg.BB_Indirect
			    then (
			      D.dprintf "Indirect loop exit edge found.\n";
			      l (* don't include indirect edge *)
			    )
			    else (
			      let src_lab = match 
				first_reachable_pc true fun_rcfg 
				  fun_dom fun_pdom src_bbid 
			      with None ->
				failwith "cannot find exit edge's src label"
				| Some x -> x
			      in
			      let dst_lab = match 
				first_reachable_pc false fun_rcfg 
				  fun_dom fun_pdom dst_bbid
			      with None ->
				let msg = 
				  "cannot find exit edge's dst pc label. " ^
				    "possibly the dst bb does not belong to " ^
				    "this function ("^name^"). this usually " ^
				    "appear in the old idadb ir due to " ^
				    "missing function chunks. note that the " ^
				    "src bb is around the label ("^src_lab^")."
				in
				  failwith msg
				| Some x -> x
			      in
				( src_lab , dst_lab ) :: l
			    )
                        in
                          List.fold_left add_label [] exit_edges_l
                      in
                      let entry_eip_str =
                        try List.hd header_labels
                        with _ -> "unknown"
                      in
                      D.dprintf "At loop start %s\n" entry_eip_str;

                      let iv_l = [] in

		      (* Extract the loop exit edges *)
		      let exit_edge_l = 
			let process_str (s,e) =
			  let s_addr =
			    Int64.sub (get_eip_from_label s)
			     start_addr 
			  in
			  let d_addr =
			    Int64.sub (get_eip_from_label e)
			     start_addr 
			  in
			  (s_addr,d_addr)
			in
			List.map process_str exit_labels
		      in

                      (* Extract the loop back edges *)
                      let back_edge_l = 
                        let process_str s = 
			  Int64.sub (get_eip_from_label s)
			   start_addr
                        in
                        List.map process_str back_labels
                      in

		      (* Create new object with loop information *)
                      let info =
                        {
                          module_name = module_name;
                          fun_name = name;
                          header_eip =
                            Int64.sub (get_eip_from_label entry_eip_str)
                              start_addr;
                          exit_edges = exit_edge_l;
			  back_edges = back_edge_l;
                          iv_info_l = iv_l;
                        }
                      in
                      (* Add loops to loop_list *)
                      loop_l <- info :: loop_l;
                    in
                    List.iter process_loop fun_loop_l;
                    SkipChildren
                  )
                  with Vine.TypeError _ -> (
                    D.wprintf "Found Type error at function: %s\n" name;
                    SkipChildren
                  )
		)
                | _ -> SkipChildren
             )
            | _ -> SkipChildren
      end
    in
    List.iter (fun stmt -> ignore(stmt_accept vis stmt)) sl;
    vis#get_loop_l
  in
  prog_loop_l


(* Extract loops in trace using static loop info *)
let add_statloop_insn_info gctx inst instr_ctr = 
    let curr_eip = inst#address in
    let curr_eip32 = Int64.to_int32 inst#address in
    let curr_line = instr_ctr in
    let in_loop = (gctx.sc_curr_loop <> empty_loop) in
    let last_inst_addr =
      match gctx.sc_last_inst with
	Some(insn) -> Int64.to_int32 insn#address
	| None -> 0l
    in

    (* Store offsets for the eflags *)
    if (sets_eflags inst) then (
      let taint_l = get_insn_taint inst in
      let addr32 = Int64.to_int32 inst#address in
      gctx.sc_eflags_info <- (addr32,instr_ctr,taint_l)
    );

    let is_loop_entry_addr = Hashtbl.mem gctx.sc_entry_map curr_eip in
    let is_loop_cond_addr = Hashtbl.mem gctx.sc_exit_cond_map curr_eip in
    let is_loop_exit_addr = Hashtbl.mem gctx.sc_exit_map curr_eip in
    let is_iv_addr = Hashtbl.mem gctx.sc_iv_map curr_eip in

    (* If loop entry point, determine if same loop, new loop or child loop *)
    if (is_loop_entry_addr) then (
      (* If in_loop and same start address as current loop, 
        then we found a new iteration of current loop *)
      if ((in_loop) && (gctx.sc_curr_loop.lstart = curr_eip32))
        then (
           D.dprintf ("Found loop iteration for loop %d @ " ^^
            "instruction %Ld (0x%08Lx)\n")
            gctx.sc_curr_loop.id curr_line curr_eip;

	  (* Update information of previous iteration *)
	  let prev_iter = List.hd gctx.sc_curr_loop.iter_list in
	  prev_iter.iend <- last_inst_addr;
	  prev_iter.iend_line <- Int64.pred curr_line;
	  prev_iter.iec_l <- (List.rev prev_iter.iec_l);

	  (* Create new iteration *)
          let iter = 
          {
            istart = curr_eip32;
            iend = 0l; 
            istart_line = curr_line;
            iend_line = 0L;
            iec_l = [];
	    itaint_data = [];
          }
	  in

          (* Add iteration and update number of iterations and loop type *)
          gctx.sc_curr_loop.num_iter <- gctx.sc_curr_loop.num_iter + 1;
	  gctx.sc_curr_loop.iter_list <- iter :: gctx.sc_curr_loop.iter_list;
          if (gctx.sc_curr_loop.ltype = Trace_loops.Unknown)
            then (gctx.sc_curr_loop.ltype <- get_loop_type gctx.sc_last_inst)
        )

      (* If in loop but different start address, then we found a child loop *)
      else if ((in_loop) && (gctx.sc_curr_loop.lstart <> curr_eip32))
        then (
           D.dprintf "Found child for loop %d @ instruction %Ld (0x%08Lx)\n"
            gctx.sc_curr_loop.id curr_line curr_eip;
          (* Save current loop *)
          gctx.sc_loop_open_l <- gctx.sc_curr_loop :: gctx.sc_loop_open_l;

          (* Store iteration information *)
          let iter =
          {
            istart = curr_eip32;
            iend = 0l;
            istart_line = curr_line;
            iend_line = 0L;
            iec_l = [];
	    itaint_data = [];
          }
          in

	  (* Create new child loop *)
          let new_loop =
            {
              id = gctx.sc_loop_idx;
              ltype = Trace_loops.Unknown;
              lstart = curr_eip32;
              lend = 0l;
              num_iter = 1;
              lstart_line = curr_line;
              lend_line = 0L;
              iter_list = [iter];
              nest_depth = gctx.sc_curr_loop.nest_depth + 1;
              nest_inner = None;
              nest_outer = Some(gctx.sc_curr_loop.id);
            }
          in
          gctx.sc_loop_idx <- gctx.sc_loop_idx + 1;
          gctx.sc_curr_loop <- new_loop
        )
      (* If not in a loop, then we found a new loop *)
      else if (gctx.sc_curr_loop = empty_loop)
        then (
          (* Found new loop *)
           D.dprintf "Found new loop (%d) @ instruction %Ld (0x%08Lx)\n"
            gctx.sc_loop_idx curr_line curr_eip;

          (* Store iteration information *)
          let iter =
          {
            istart = curr_eip32;
            iend = 0l;
            istart_line = curr_line;
            iend_line = 0L;
            iec_l = [];
	    itaint_data = [];
          }
          in

          let new_loop =
            {
              id = gctx.sc_loop_idx;
              ltype = Trace_loops.Unknown;
              lstart = Int64.to_int32 inst#address;
              lend = 0l;
              num_iter = 1;
              lstart_line = curr_line;
              lend_line = 0L;
              iter_list = [iter];
              nest_depth = 0;
              nest_inner = None;
              nest_outer = None;
            }
          in
          gctx.sc_loop_idx <- gctx.sc_loop_idx + 1;
          gctx.sc_curr_loop <- new_loop
        )
    )

    (* If loop exit point then add loop to loop list *)
    else if (is_loop_exit_addr) then (
      if (in_loop) then (
        D.dprintf "Exitted loop %d @ instruction %Ld (0x%08Lx)\n"
          gctx.sc_curr_loop.id curr_line curr_eip;

        (* Out of the loop. Update loop and store *)
	let prev_iter = List.hd gctx.sc_curr_loop.iter_list in
	prev_iter.iend <- last_inst_addr;
	prev_iter.iend_line <- Int64.pred curr_line;
	prev_iter.iec_l <- (List.rev prev_iter.iec_l);
        gctx.sc_curr_loop.lend_line <- Int64.pred curr_line;
        gctx.sc_curr_loop.lend <- last_inst_addr;
        gctx.sc_curr_loop.iter_list <- (List.rev gctx.sc_curr_loop.iter_list);
        gctx.sc_loop_found_l <- gctx.sc_curr_loop :: gctx.sc_loop_found_l;
        (* Recover parent loop, if any *)
        match gctx.sc_loop_open_l with
          h :: t -> gctx.sc_curr_loop <- h; gctx.sc_loop_open_l <- t
          | _ -> gctx.sc_curr_loop <- empty_loop; gctx.sc_loop_open_l <- []
      )
      else D.wprintf "Exit of unseen loop\n"
    )

    (* If loop exit condition, check if tainted *)
    else if ((in_loop) && (is_loop_cond_addr)) then (

      let (sets_flags_eip,sets_flags_ctr,sets_flags_taint_l) = 
        gctx.sc_eflags_info
      in

      (* Print taint information *)
      if (D.debug) then (
        let print_pair pair = 
          let (origin,offset) = pair in
          D.dprintf "Origin: %ld Offset: %d\n" origin offset;
        in
        List.iter print_pair sets_flags_taint_l
      );

      let ec = 
      {
	ec_addr = curr_eip32;
	ec_line = curr_line;
	ec_taint_l = sets_flags_taint_l;
        ec_setflags_addr = sets_flags_eip;
        ec_setflags_line = sets_flags_ctr;
      }
      in
      let is_tainted_ec = (List.length sets_flags_taint_l) > 0 in

      (* Add EC to iteration *)
      let _ = 
	match gctx.sc_curr_loop.iter_list with 
	  | h :: t -> (h.iec_l <- ec :: h.iec_l)
	  | _ -> failwith "No iterations found"
      in

      if (is_tainted_ec) then (
        D.dprintf ("Found loop %d tainted exit condition @ instruction %Ld " ^^
          "(0x%08Lx)\n") gctx.sc_curr_loop.id curr_line curr_eip;
      )
      else (
        D.dprintf ("Found loop %d exit condition @ instruction %Ld " ^^
          "(0x%08Lx)\n") gctx.sc_curr_loop.id curr_line curr_eip;
      )
    )


    (* If IV ... *)
    else if ((in_loop) && (is_iv_addr)) then (
      D.dprintf "Found IV for loop %d @ instruction %Ld (0x%08Lx)\n"
        gctx.sc_curr_loop.id curr_line curr_eip;
    );

    (* Update list of taint offsets accessed in iteration *)
    if (in_loop) then (
      try (
	let curr_iter = 
	  List.hd gctx.sc_curr_loop.iter_list in
	let taint_data_l =
	  add_taint_info_in_insn_to_list curr_iter.itaint_data inst
	in
	curr_iter.itaint_data <- taint_data_l
      )
      with _ -> ()
    );

    (* Update last instruction *)
    gctx.sc_last_inst <- Some(inst);
    gctx.sc_last_inst_ctr <- curr_line;
    gctx

(* Create a static loop context *)
let create_statloops_ctx module_map loop_info_l = 
  let num_loops = List.length loop_info_l in
  let stat_loop_ctx = 
    {
      sc_module_map = module_map;
      sc_entry_map = Hashtbl.create num_loops;
      sc_exit_cond_map = Hashtbl.create num_loops;
      sc_exit_map = Hashtbl.create num_loops;
      sc_iv_map = Hashtbl.create num_loops;
      sc_eflags_info = (0l,0L,[]);
      sc_loop_idx = 0;
      sc_loop_found_l = [];
      sc_loop_open_l = [];
      sc_curr_loop = empty_loop;
      sc_last_inst = None;
      sc_last_inst_ctr = 0L;
    }
  in
  (* Load loop information to context *)
  let add_loop_info info =
    (* Add loop entry point to entry map *)
    let mod_load_addr =
      try (
        let (base,_) = Hashtbl.find stat_loop_ctx.sc_module_map info.module_name
        in
        base
      )
      with _ -> (
        (* D.wprintf "Could not find module %s" info.module_name;
        failwith "\n" *)
        0L
      )
    in
    let loaded_addr = Int64.add info.header_eip mod_load_addr in
    Hashtbl.replace stat_loop_ctx.sc_entry_map loaded_addr info;
    (* Add IVs to iv_map *)
    let process_iv (iv_eip,_) =
      let loaded_iv_addr = Int64.add iv_eip mod_load_addr in
      Hashtbl.replace stat_loop_ctx.sc_iv_map loaded_iv_addr info
    in
    List.iter process_iv info.iv_info_l;
    (* Add exit conditions and exit points to exit_cond_map,exit_map *)
    let process_edge (s,d) =
      let loaded_s = Int64.add s mod_load_addr in
      let loaded_d = Int64.add d mod_load_addr in
        Hashtbl.replace stat_loop_ctx.sc_exit_cond_map loaded_s info;
        Hashtbl.replace stat_loop_ctx.sc_exit_map loaded_d info;
    in
    List.iter process_edge info.exit_edges
  in
  List.iter add_loop_info loop_info_l;
  stat_loop_ctx

(* Extract list of loops from static loops context *)
let get_loops_from_static_ctx st_ctx = 
  if (st_ctx.sc_curr_loop <> empty_loop) 
    then (
      let last_inst_addr =
	match st_ctx.sc_last_inst with
	  Some(insn) -> Int64.to_int32 insn#address
	  | None -> 0l
      in
      let prev_iter = List.hd st_ctx.sc_curr_loop.iter_list in
      prev_iter.iend <- last_inst_addr;
      prev_iter.iend_line <- Int64.pred st_ctx.sc_last_inst_ctr;
      prev_iter.iec_l <- (List.rev prev_iter.iec_l);
      st_ctx.sc_curr_loop.lend_line <- Int64.pred st_ctx.sc_last_inst_ctr;
      st_ctx.sc_curr_loop.lend <- last_inst_addr;
      st_ctx.sc_curr_loop.iter_list <- (List.rev st_ctx.sc_curr_loop.iter_list);
      st_ctx.sc_curr_loop :: st_ctx.sc_loop_found_l
    )
    else st_ctx.sc_loop_found_l


(* Extract all loops from trace using static method *)
let extract_statloops_from_trace ?(ignore_reps=false) 
  loop_info_l trace_filename =

  (* Open the trace *)
  let trace = Trace.open_trace trace_filename in

  (* Get module map from trace *)
  let module_map = Callstack.read_module_addresses trace in

  (* Create static loops context *)
  let gctx = create_statloops_ctx module_map loop_info_l in

  (* Iterate over all the instructions in the trace *)
  let gctx = Trace.trace_fold add_statloop_insn_info gctx trace in
  let _ = Trace.close_trace trace in

  (* Get loop list from context *)
  let loop_l = get_loops_from_static_ctx gctx in
  List.rev loop_l

