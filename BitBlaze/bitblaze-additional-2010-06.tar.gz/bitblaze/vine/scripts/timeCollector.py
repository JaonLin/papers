#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
import os, pdb
import socket, time, sqlite3, random, math
import netcomm, threading, getopt, sys
from SocketServer import StreamRequestHandler, ThreadingMixIn, TCPServer
from argparse import ArgumentParser

dbPath = None

dbLock = threading.Lock()

def connectToDBController(signal):
    c_db = netcomm.Connection(addr=DB_CONTROLLER[0], port=DB_CONTROLLER[1])
    c_db.write_int(signal)
    return c_db
'''
class futureDBRecord:
    def __init__(self):
	self.stage = 0
	self.path = None
	self.run_num = None
	self.return_code = None
	self.coverage = None
	self.argv = None
	self.input = None
	self.trace_gen_time = None
	self.num_inputs = None
	self.num_nontrivial_inputs = None
	self.input_gen_time = None

    def dumpToDB(self, db_conn):
	writeTuple = (self.path, self.run_num, self.return_code,\
			self.coverage, self.argv, self.input, \
			self.trace_gen_time, self.newBlocks, self.newInsts,
			self.cov_calc_time, self.num_inputs, \
			self.num_nontrivial_inputs, self.input_gen_time)
	valid = True
	for item in writeTuple:
	    if item == None:
		valid = False
	if valid:
	    print "Entering data for run %d into DB!" % (self.run_num)
	    with dbLock:
		db_conn.execute("insert into traceInfo values (?,?,?,?,?,?,?,?,?,?,?,?,?,?)", writeTuple)
	    db_conn.commit()
	else:
	    print "Something went wrong with entering the data."
'''
def dictIntoDB(newRecord, dbPath, table):
    print "Begin insert to table %s, row %d" % (table, newRecord["id"])
    sys.stdout.flush()
    questionString = ""
    for item in newRecord:
	questionString += "?, "
    questionString = questionString[:-2]
    if "input" in newRecord:
	newRecord["input"] = buffer(newRecord["input"])
    fieldString = str(tuple(newRecord.keys())).replace("'", "")
    db_conn = sqlite3.connect(dbPath)
    with dbLock:
	db_conn.execute("INSERT INTO %s %s VALUES (%s)" % (table, fieldString, questionString), newRecord.values())
	db_conn.commit()
    db_conn.close()
    print "Finish insert to table %s, row %d" % (table, newRecord["id"])
    sys.stdout.flush()

def dictUpdateDB(upRecord, dbPath, id, minExpectedStage, table):
    print "Begin updating table %s, row %d" % (table, id)
    sys.stdout.flush()
    # TODO: Check how the DB is locked. I believe Sqlite3 library has already taken care of locking for you and there is no need to use dbLock by ourself!
    db_conn = sqlite3.connect(dbPath)
    upCursor = db_conn.cursor()
    ready = False
    while not ready:
        upCursor.execute(("SELECT stage FROM %s WHERE id=?" % table), (id, ))
	entry = upCursor.fetchone()
	if entry == None:
	    ready = False
            time.sleep(1)
	    continue
	stage = entry[0]
	ready = (stage >= minExpectedStage)
	if not ready:
	    print "!!!ALERT!!!: Row %d of table %s has stage = %d which is lower than the minimum expected stage:%d. Will keep waiting (loop)." % (id, table, stage, minExpectedStage)
            sys.stdout.flush()
            time.sleep(1)
    fieldString = ""
    for key in upRecord.keys():
	fieldString += ("%s=?, " % key)
    fieldString = fieldString[:-2]
    valuesList = upRecord.values() + [id]
    with dbLock:
	upCursor.execute("UPDATE %s SET %s WHERE id=?" % (table, fieldString), valuesList)
	db_conn.commit()
    upCursor.close()
    db_conn.close()
    print "Finish updating table %s, row %d" % (table, id)
    sys.stdout.flush()

class DataUpdateHandler(StreamRequestHandler):
    def generatorHandler(self, dbPath, sw, oreFormat, ingotFormat, oreTable, ingotTable):
	while True:
	    signal = sw.read_byte()
	    if signal == 1:
		oreInfo = sw.recv_format(oreFormat)
		id = oreInfo["id"]
		oreInfo["stage"] = 2
		if id <= 0:
		    dictIntoDB(oreInfo, dbPath, oreTable)
		else:
		    del oreInfo["id"]
		    dictUpdateDB(oreInfo, dbPath, id, 1, oreTable)
	    elif signal == 2:
		ingotInfo = sw.recv_format(ingotFormat)
		ingotInfo["stage"] = 1
		dictIntoDB(ingotInfo, dbPath, ingotTable)
	    else:
		print "!!!ALERT!!!: Bad signal %d in generatorHandler" % signal
                sys.stdout.flush ()

    def traceGenHandler(self, dbPath, sw):
	print "Now serving the Trace Generator!"
	oreFormat = netcomm.Formats.traceGenInputDBInfo
	ingotFormat= netcomm.Formats.traceGenTraceDBInfo

	self.generatorHandler(dbPath, sw, oreFormat, ingotFormat, "inputInfo", "traceInfo")

    def inputGenHandler(self, dbPath, sw):
	print "Now serving the Input Generator!"
	oreFormat = netcomm.Formats.inputGenTraceDBInfo
	ingotFormat = netcomm.Formats.inputGenInputDBInfo

	self.generatorHandler(dbPath, sw, oreFormat, ingotFormat, "traceInfo", "inputInfo")

    def handle(self):
	sw = netcomm.Connection(rf = self.rfile, wf = self.wfile)
	typeSignal = sw.read_byte()
	if typeSignal == 1:
	    self.traceGenHandler(dbPath, sw)
	elif typeSignal == 2:
	    self.inputGenHandler(dbPath, sw)
	else:
	    print "!!!ALERT!!!: Unrecognized signal %d in handle" % typeSignal
            sys.stdout.flush ()

class DatabaseControlServer(ThreadingMixIn, TCPServer):
    pass

def getComArgs():
    parser = ArgumentParser()
    parser.add_argument("-t", "--startTime", type=int, help="If this is \
        specified, the \
        database will be placed in /tmp/trace_generator with a name and \
        directory of the current time in seconds.")
    parser.add_argument("-p", "--path", help="If specified, this will be used \
                    as the database's path on the file system.")
    parser.add_argument("-b", "--bindAddr", default=":12666", help="The address:port to which \
                            the database will bind.")
    argNS = parser.parse_args()
    return argNS.__dict__
    

def main():
    global dbPath
    argDict = getComArgs() 
    print "DB's argument dict is: " + str(argDict)
    startTime = int(time.time())
    if argDict["startTime"]:
        startTime = int(argDict["startTime"])
    if argDict["path"]:
        dbPath = argDict["path"]
    else:
        dbPath = "/tmp/trace_generator/%d/%d.db" % (startTime, startTime)
    if not os.path.exists(os.path.dirname(dbPath)):
        try:
            os.makedirs(os.path.dirname(dbPath))
        except OSError:
            pass
    print "DBPath is %s" % dbPath
    with dbLock:
        db_conn = sqlite3.connect(dbPath)
	db_conn.execute("create table if not exists traceInfo \
			(id integer, return_code integer,\
			priority integer, argv text, input blob, parent_id integer, trace_gen_time real, timestamp real,\
			gen_inputs integer, non_trivial_inputs integer,\
			proc_time real, stage integer, child_inputs string, gen_addr string, comment string)")
	db_conn.execute("create table if not exists inputInfo (id integer,\
			insn string, eip string, input blob, skipped integer, \
			gen_time real, timestamp real, random integer, stp_crash integer, priority integer, parent_id integer, child_trace integer, \
			stage integer, gen_addr string, comment string)")
        db_conn.commit()
        db_conn.close()
    bound = False
    DB_CONTROLLER = netcomm.addrStringToTuple(argDict["bindAddr"])
    print "Binding to address %s %d" % DB_CONTROLLER
    while not bound:
	try:
	    myServer = DatabaseControlServer(DB_CONTROLLER, DataUpdateHandler)
	    bound = True
	    print "Serving!"
	except socket.error, e:
	    print "Couldn't bind, trying again..."
	    time.sleep(5)
    myServer.serve_forever()

if __name__ == "__main__":
    main()
