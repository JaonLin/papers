#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import socket, pickle, sys, time, random, getopt, os, os.path, select
import netcomm
from netcomm import Connection
from samate_config import *
from subprocess import Popen

try:
    import replay_server
except ImportError:
    pass

import logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger()

iniInfo = {}

EXITCODE_TIMEOUT = 2
EXITCODE_USER_EXCEPTION = -0xdead
EXITCODE_PROCESS_EXIT = -0xd
EXITCODE_NORMAL = 0

class TimeoutError(Exception):
    pass

class TemuConnection(Connection):
    def __init__(self, addr, port):
        super(self.__class__, self).__init__(addr=addr, port=port)

    def write_command(self, command):
	self.write_string(command)

    def blockOnStatus(self, blockCommand):
        temu_sw.write_command(blockCommand)
        status = temu_sw.read_int()
        if status == 2:
            raise TimeoutError

    def blockOnTaint(self):
        print "Waiting for taint to occur..."
        self.blockOnStatus("block_taint")

    def blockOnProcess(self, name=None, pid=None):
        assert name == None or pid == None, \
            "Error: Blocking on a name with a particular process ID \
            is not currently supported. Pick one."
        if name:
            self.blockOnStatus("block_name %s" % name)
        elif pid:
            self.blockOnStatus("block_pid %d" % pid)

    def blockOnTracing(self):
        print "Blocking on the start of tracing!"
        self.blockOnStatus("block_tracing") 

    def blockOnEmulation(self):
        print "Blocking on the start of emulation!"
        self.blockOnStatus("block_emulation")

    def write_sync_command(self, command):
	self.write_string("notify")
	self.write_string(command)
	self.read_int()

def writeTagMsgPair(tags, msg, clean_sw, taint_sw):
    clean_sw.send_tag_pairs(tags)
    print "Writing Message %s!" % msg
    write_tainted_string(taint_sw, clean_sw, msg)

def write_tainted_string(tainted_sw, clean_sw, theStr):
    clean_sw.write_int(len(theStr))
    tainted_sw.write(theStr)

def sendStopAddrs(stopAddr, temu_sw):
    if stopAddr != None and stopAddr != "":
	addrs = stopAddr.split(",")
	for addr in addrs:
	    temu_sw.write_command(('''tc_address_stop 0x%s 0''' % addr))

def targetTraceOnProcess(pid, procName, trace_filename, temu_sw):
    if not procName:
	logger.info("Tracing pid #%d to %s" % (pid, trace_filename))
        temu_sw.blockOnProcess(pid=pid)
	temu_sw.write_sync_command(('''trace %d "%s"''' % (pid, trace_filename)))
        temu_sw.write_sync_command('''cont''')
    else:
	logger.info("Tracing process name %s to %s" % (procName, trace_filename))
        temu_sw.write_sync_command('''cont''')
#        temu_sw.blockOnProcess(name=procName)
	temu_sw.write_sync_command(('''tracebyname %s %s''' % (procName, trace_filename)))
    temu_sw.blockOnTracing()

def startProcess(clean_sw):
    #The program starts executing when it receives the 1 and stops
    #right before it sends the return code. Our measured time, then,
    # will be the actual time plus twice the amount of time it takes
    # to send an integer over the connection. Should be a decent estimation.

    clean_sw.write_int(1)

def endProcess(clean_sw, temu_sw, postTaintTimeout):
    temu_sw.blockOnTaint()
    if postTaintTimeout > -1:
        readList, dummy, dummy2 = select.select([clean_sw.rf], [],[], postTaintTimeout)
        retcode = EXITCODE_TIMEOUT
        stdout = "<NOT READ>"
        stderr = "<NOT READ>"
    else:
        readList = ["this is here to make sure we block on the return \
            values when there is no timeout"]
    if len(readList) != 0:     
        retcode = clean_sw.read_int()
    temu_sw.write_sync_command('''trace_stop''')
    if len(readList) != 0:
        #This write int was part of an attempt to limit the number of 
        #instructions in .trace files. It didn't work and was based on a
        #misunderstanding of how such traces are made. We did not remove
        #it because to do so would mean putting a new version of wincontrol
        #on all images with the monitor on them.
        clean_sw.write_int(1)
        stdout = clean_sw.read_string()
        stderr = clean_sw.read_string()
    return retcode, stdout, stderr

def recordInputsAndOutputs(stdin, stdout, stderr, trace_filename):
    stdin_filename = trace_filename.replace(".trace", ".input")
    stdout_filename = trace_filename.replace(".trace", ".stdout")
    stderr_filename = trace_filename.replace(".trace", ".stderr")
    open(stdin_filename, "w").write(stdin)
    open(stdout_filename, 'w').write(stdout)
    open(stderr_filename, 'w').write(stderr)

def restoreImage(dontreload, temu_sw):
    if not dontreload:
	temu_sw.write_command("reset")
    signal = temu_sw.read_int()
    return signal == 1

def setUpTemu(temu_sw):
    temu_sw.write_sync_command(("""load_plugin %s""" % iniInfo["plugin_so_file"]))
    if "plugin_ini" in iniInfo:
        temu_sw.write_sync_command(("""load_config %s""" % iniInfo["plugin_ini"]))
    temu_sw.write_sync_command("guest_ps")
    temu_sw.write_command('load_hooks "" ""')
    logger.info("Sending Temu commands")
    temu_sw.write_command("""enable_emulation""")
    temu_sw.blockOnEmulation()
    temu_sw.write_command("""action stoptracing""")
    temu_sw.write_command("""detect exception on""")
    temu_sw.write_command("""detect processexit on""")
    if iniInfo["taint_nic"]:
        temu_sw.write_sync_command("taint_nic 1")
    else:
        temu_sw.write_sync_command("taint_nic 0")

def setUpMonitor(command, run_number, taintPairs, msg, clean_sw, taint_sw):
    clean_sw.write_int(run_number)
    clean_sw.write_string(command)
    writeTagMsgPair(taintPairs, msg, clean_sw, taint_sw)
    pid = clean_sw.read_int()
    return pid


def doNet(netDest, taintPairs, msg, postTaintTimeout, netProtocol):
    offset = 0
    netPair = None
    netDest = netcomm.addrStringToTuple(netDest)
    netCon = netcomm.Connection(addrpair=netDest, protocol = netProtocol)

    # When the replay server is on, this part is done by the server
    if not iniInfo["replay"]:
        for item, length in taintPairs:
            if item == "netIn":
                netPair = (item, length)
                break
            else:
                offset += length
        netMsg = msg[offset:offset+length]
        print "Sending message of length:%d" % length
        netCon.write(netMsg)

    temu_sw.write_command("block_t_or_t")
    block_status = temu_sw.read_int()
    if 1 == 0: # FIXME: This should be a configurable option.
        stop_on_reply = [netCon.rf, temu_sw.rf]
    else:
        stop_on_reply = [temu_sw.rf]

    if block_status == 2: # Pre-taint timeout
        raise TimeoutError
    elif block_status == 1: # Tainting started
        temu_sw.write_command("block_tstop") # if tstop, it will receive exit status. otherwise, nothing.
        if postTaintTimeout < 0:
            readList, dummy, dummy2 = select.select(stop_on_reply, [], [])
        else:
            readList, dummy, dummy2 = select.select(stop_on_reply, [], [], postTaintTimeout) 
        if temu_sw.rf in readList:
            exit_status = temu_sw.read_int()
        elif netCon.rf in readList:
            temu_sw.write_sync_command('''trace_stop''')
            exit_status = temu_sw.read_int() # consume block_stop reply
        else:
            temu_sw.write_sync_command('''trace_stop''')
            temu_sw.read_int() # consume block_stop reply
            exit_status = EXITCODE_TIMEOUT
        netCon.close()
        return exit_status
    else: # Tracestop occured
        netCon.close()
        return block_status # exit status

temu_sw = None

def runServerCycle(msg, temu_sw, trace_filename, procName, stopAddr, \
        taintPairs, netDest, postTaintTimeout, pidGiven, pid, netProtocol): 
    retcode = EXITCODE_TIMEOUT
    stdout = "<NOT READ>"
    stderr = "<NOT READ>"
    temu_sw.write_sync_command('''guest_ps''')
    sendStopAddrs(stopAddr, temu_sw)
    targetTraceOnProcess(pid, procName, trace_filename, temu_sw)
#ccy: START OF INSERT
    if iniInfo["replay"]:
        replay_server.start()
#ccy: END OF INSERT
    start = time.time()
    print "Entring doNet"
    retcode = doNet(netDest, taintPairs, msg, postTaintTimeout, netProtocol)
    print "Finished doNet"
    end = time.time()
    trace_gen_time = end-start
    timestamp = start
    recordInputsAndOutputs(msg, stdout, stderr, trace_filename)
    return retcode, trace_gen_time, timestamp

def runOnce(msg, run_number, trace_filename, guest_ip, guest_taint_port, \
        guest_clean_port, snapshotName, passedIniInfo, command="", procName="", \
        stopAddr="", dontreload=False, \
        taintPairs=[], serverMode = False, netDest="127.0.0.1:52", \
        postTaintTimeout=-1, pidGiven=False, pid=0, \
        netProtocol="tcp"):
    global temu_sw
    global iniInfo
    iniInfo = passedIniInfo
    tapId = iniInfo["tap"]
    print ("SHELL:> sudo tcpdump -p -s 0 -i %s -w %s.pcap" % (tapId, trace_filename))
    tcpProc = Popen (["sudo", "tcpdump", "-p" , "-s", "0", "-i", tapId, "-w", "%s.pcap" % trace_filename])
    return_code = EXITCODE_TIMEOUT
    trace_gen_time = 0
    timestamp = 0
    if temu_sw == None:
	temu_sw = TemuConnection('localhost', iniInfo["temu_port"]) 
    try:
        setUpTemu(temu_sw)
        print "Server mode is " + str(serverMode)
        if serverMode:
            return_code, trace_gen_time, timestamp = runServerCycle(msg, \
                temu_sw, trace_filename, procName , \
                stopAddr, taintPairs, netDest, postTaintTimeout, pidGiven, pid, \
                netProtocol)
        else:
            return_code, trace_gen_time, timestamp = runMonitorCycle(msg, \
                temu_sw, run_number, trace_filename, guest_ip, \
                guest_taint_port, guest_clean_port, command, procName, stopAddr,\
                taintPairs, postTaintTimeout, pidGiven, pid)
        print "Finished temu run."
    except TimeoutError:
        pass
    # We might lost some packets between killing tcpdump and restoring the image. Ignoring this unfortunate case for now. 
    print ("SHELL:> sudo kill -2 %d" % tcpProc.pid)
    Popen ("sudo kill -2 %d" % tcpProc.pid, shell=True);
    print "Restoring the image."
    finishedRun = restoreImage(dontreload, temu_sw)
    if not finishedRun:
        print "Error: Timeout expired before the run could be finished."
    return return_code, trace_gen_time, timestamp, finishedRun

def runMonitorCycle(msg, temu_sw, run_number, trace_filename, guest_ip, \
        guest_taint_port, guest_clean_port, command, \
        procName, stopAddr, taintPairs, postTaintTimeout, pidGiven, pid):
    print "Connecting to %s on port %d." % (guest_ip, guest_taint_port)
    taint_sw = Connection(addr=guest_ip, port=guest_taint_port)
    print "Connecting to %s on port %d." % (guest_ip, guest_clean_port)
    clean_sw = Connection(addr=guest_ip, port=guest_clean_port)
    logger.info("Connection to guest established")
    newPid = setUpMonitor(command, run_number, taintPairs, msg, clean_sw, taint_sw)
    if not pidGiven:
        pid = newPid
    sendStopAddrs(stopAddr, temu_sw)
    targetTraceOnProcess(pid, procName, trace_filename, temu_sw)
    start = time.time()
    startProcess(clean_sw)
    retcode, stdout, stderr = endProcess(clean_sw, temu_sw, postTaintTimeout)
    end = time.time()
    trace_gen_time = end - start
    timestamp = start
    logger.info("Finishing trace")
    temu_sw.write_command("""disable_emulation""")
    clean_sw.close()
    taint_sw.close()
    recordInputsAndOutputs(msg, stdout, stderr, trace_filename)
    logger.info("Exited with return code %d [%d bytes stdout, %d bytes stderr]" % (retcode, len(stdout), len(stderr)))
    return retcode, trace_gen_time, timestamp
