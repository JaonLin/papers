# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
import hashlib
import threading
import random
import socket
import struct
import time
import os
import pdb

connInfo = {"local":False, "temp_file_prefix":"/tmp/tmpfiles", \
    "cleanup":True}

class Formats(object): 
    inputFormat = [("id", "int"), ("priority", "int"), \
		    ("input", "string")]
    traceFormat = [("trace", "file"), \
		    ("input", "string"), ("id", "int"), \
		    ("return_code", "int"), ("priority", "int")]
    inputGenInputDBInfo = [("id", "int"), ("insn", "string"), ("eip", "string"), \
                ("input", "string"), ("skipped", "int"), ("gen_time", "double"), \
                ("timestamp", "double"), ("stp_crash", "int"), \
                ("parent_id", "int"), ("priority", "int"),  \
                ("gen_addr", "string")]

    inputGenTraceDBInfo = [("id", "int"), ("gen_inputs", "int"), \
		("child_inputs", "string"), \
		("non_trivial_inputs", "int"), ("proc_time", "double")]

    traceGenInputDBInfo =[("id", "int"), ("child_trace", "int")] 
    
    traceGenTraceDBInfo = [("id", "int"), ("return_code", "int"), \
                ("input", "string"), ("trace_gen_time", "double"), \
                ("timestamp", "double"), ("parent_id", "int"), \
                ("priority", "int"), ("gen_addr", "string")]

    traceGenReport = [("trace", "file"), ("return_code", "int"), \
		    ("trace_gen_time", "double"), \
		    ("timestamp", "double"), ("input", "string"),\
                    ("finished", "bool")]

    inputGenReport =[("input", "string"), ("insn", "string"), \
                        ("eip", "string"), ("skipped", "int"), \
                        ("gen_time", "double"), ("timestamp", "double"), \
                        ("stp_crash", "int"), ("prior_labels", "int")]

    traceOptionsReport =[("command", "string"), ("procName", "string"),\
                ("stopAddr", "string"), ("startTime", "int"), \
                ("dontreload", "byte"), ("testKey", "string"),\
                ("taintPairs", "tagpairs"), ("serverMode", "bool"), \
                ("netDest", "string"), ("timeout", "int"), \
                ("postTaintTimeout", "int"), \
                ("pidGiven", "bool"), ("pid", "int"), \
                ("netProtocol", "string")]

def setConnInfo(newInfo):
    global connInfo
    connInfo = newInfo

class Connection(object):
    def __init__(self, addr=None, port=None, wf=None, rf=None, sock=None, \
            listen=False, addrpair=None, protocol="tcp"):
        self.conLock = threading.RLock()
	if not wf and not rf:
	    if addr and port:
		addrpair = (addr, port)
	    if sock == None:
                if protocol == "tcp":
		    self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                elif protocol == "udp":
                    self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                else:
                    print "Error: Unknown protocol %s" % protocol
	    else:
		self.sock = sock
	    if listen:
		self.sock.bind(addrpair)
		self.sock.listen(1)
		self.sock, otherAddr = self.sock.accept()
	    else:
		successfullyConnected = False
		while not successfullyConnected:
		    try:
			self.sock.connect(addrpair)
			successfullyConnected = True
		    except socket.error, e:
			if type(e.message) == type("str"):
			    print "Error was ", e
			print "Retrying destination %s:%d..."% addrpair
			time.sleep(5)
	    self.wf = self.sock.makefile('wb', 0)
	    self.rf = self.sock.makefile('rb', 0)
	else:
	    self.wf = wf
	    self.rf = rf

    def flush(self):
	if self.wf:
	    self.wf.flush()

    def write(self, writeString):
        with self.conLock:
            self.wf.write(writeString)
            self.wf.flush()

    def read(self, readlen):
        readString = self.rf.read(readlen)
	return readString

    def pack(self, fmt, *args):
	packString = struct.pack(fmt, *args)
        self.write(packString)

    def unpack(self, fmt):
        buf = self.read(struct.calcsize(fmt))
        return struct.unpack(fmt, buf)

    def write_int(self, i, verbose=False):
        with self.conLock:
            if verbose:
                print "Sending int %d" % i
            self.pack('i', i)

    def read_int(self, verbose=False):
        receivedInt = self.unpack('i')[0]
        if verbose:
            print "Received int %d" % receivedInt
        return receivedInt

    def read_double(self):
	return self.unpack("d")[0]
   
    def write_double(self, f):
	self.pack("d", f)

    def read_byte(self):
	c = self.read(1)
	return ord(struct.unpack("c", c)[0])
	
    def write_byte(self, i):
        with self.conLock:
	    self.write(struct.pack('c', chr(i)))

    def write_string(self, s, verbose=False):
        with self.conLock:
            if verbose:
                print "Length of string being written: %d bytes" % len(s)
            self.write_int(len(s))
            self.write(s)

    def read_string(self, verbose=False):
        i = self.read_int()
        if verbose:
            print "Length of string being read: %d bytes" % i
	return str(self.read(i))

    def write_bool(self, boolVar):
        with self.conLock:
            if boolVar:
                self.write_byte(1)
            else:
                self.write_byte(0)
	
    def read_bool(self):
	return self.read_byte() == 1

    def write_file(self, filepath, cleanup=None, verbose=False):
        with self.conLock:
            self.write_string(filepath)

    def read_file(self):
        filepath = self.read_string()
	return filepath

    def close(self):
        self.rf.close()
        self.wf.close()
	if self.sock:
	    self.sock.close()
    
    def get_input(self):
	self.write_byte(5)
	return self.recv_input()

    def read_format(self, formatItem):
	if formatItem == "int":
	    return self.read_int()
	elif formatItem == "string":
	    return self.read_string()
	elif formatItem == "double":
	    return self.read_double()
        elif formatItem == "byte":
            return self.read_byte()
        elif formatItem == "tagpairs":
            return self.recv_tag_pairs()
        elif formatItem == "bool":
            return self.read_bool()
        elif formatItem == "file":
            return self.read_file()
        else:
            assert False, "Bad format %s" % str(formatItem)
        
    def write_format(self, formatItem, outItem, cleanup=None):
        if formatItem == "int":
            self.write_int(outItem)
        elif formatItem == "string":
            self.write_string(outItem)
        elif formatItem == "double":
            self.write_double(outItem)
        elif formatItem == "byte":
            self.write_byte(outItem)
        elif formatItem == "tagpairs":
            self.send_tag_pairs(outItem)
        elif formatItem == "bool":
            self.write_bool(outItem)
        elif formatItem == "file":
            self.write_file(outItem, cleanup)
        else:
            assert False, "Bad format %s" % formatItem

    def get_format(self, format):
        with self.conLock:
	    self.write_byte(5)
	return self.recv_format(format)

    def recv_format(self, format):
	retDict = {}
	for (key, readType) in format:
	    retDict[key] = self.read_format(readType)
	return retDict

    def put_format(self, format, items):
        with self.conLock:
            self.send_format(format, items, signal=10)

    def send_format(self, format, items, signal=None, cleanup=None):
        with self.conLock:
            if signal != None:
                self.write_byte(signal)
            for (key, writeType) in format:
                self.write_format(writeType, items[key], cleanup)

    def recv_input(self):
	return self.recv_format(Formats.inputFormat)

    def put_input(self, putDict):
        with self.conLock:
            self.write_byte(10)
            self.send_input(putDict)

    def send_input(self, putDict):
        with self.conLock:
            self.send_format(Formats.inputFormat, putDict)

    def get_trace(self):
	self.write_byte(5)
	return self.recv_trace()

    def recv_trace(self):
	return self.recv_format(Formats.traceFormat)

    def put_trace(self, traceDict):
        with self.conLock:
            self.write_byte(10)
            self.send_trace(traceDict)

    def send_trace(self, traceDict):
        with self.conLock:
            self.send_format(Formats.traceFormat, traceDict)

    def send_tag_pairs(self, tagPairs):
        with self.conLock:
            self.write_int(len(tagPairs))
            for tag, length in tagPairs:
                self.write_string(tag)
                self.write_int(length)
            self.flush()

    def recv_tag_pairs(self):
	tagPairs = []
	tagLen = self.read_int()
	for idx in range(tagLen):
	    tag = self.read_string()
	    length = self.read_int()
	    tagPairs.append((tag, length))
	return tagPairs

def addrStringToTuple(addrString):
    assert addrString.count(":") == 1, "Error: Malformed address."
    addrPieces = addrString.split(":")
    assert addrPieces[1].isdigit(), "Error: Need an integer port"
    addrTuple = (addrPieces[0], int(addrPieces[1]))
    return addrTuple
