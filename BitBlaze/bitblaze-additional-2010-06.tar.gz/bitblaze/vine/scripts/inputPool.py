# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import pool

class InputPool(pool.Pool):
    def __init__(self):
        super(self.__class__, self).__init__()
        self.seenInputs = set([])

    def reject(self, putDict, rePut = False):
        print "Entered InputPool's Reject."
        if putDict["input"] == "" or \
            (hash(putDict["input"]) in self.seenInputs and not rePut) or \
            (hash(putDict["input"]) not in self.seenInputs and rePut):
            return True
        else:
            self.seenInputs.add(hash(putDict["input"]))
            return False
        
                    
