#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
import threading
import time
import os
from SocketServer import TCPServer, StreamRequestHandler, ThreadingMixIn
from netcomm import Connection
import netcomm
import pdb
from gen_controller import GenController
import inputPool
from argparse import ArgumentParser
from iniReader import setConnectionIniArgs

class InputGenController(GenController):
    def __init__(self, GenHandlerClass, GenInfoClass, controllerAddr, orePair,
                    oreFormat, ingotFormat, dbCon, dbOreFormat, dbIngotFormat, \
		                    ingotBundleFormat, poolAddr):
	super(self.__class__, self).__init__(GenHandlerClass, GenInfoClass, controllerAddr, orePair, \
	                oreFormat, ingotFormat, dbCon, dbOreFormat, dbIngotFormat, \
			ingotBundleFormat, poolAddr)
	self.seenBlocks = set([])
	self.seenBlocksLock = threading.Lock()
	self.seenEIPs = set([])
	self.seenEIPLock = threading.Lock()
        self.pool = inputPool.InputPool()
        self.poolServer.pool = self.pool

    class InputGenInfo(GenController.GeneratorInfo):
	def isIngotValuable(self, inputDict):
	    return ((input != None) and (input != ""))

	def makeSendDict(self):
	    sendDict = super(self.__class__, self).makeSendDict()
	    childIngotString = ""
	    for item in self.generatedIngots:
		childIngotString += ("%d,"%item)
	    childIngotString = childIngotString[:-1]
	    sendDict["gen_inputs"] = sendDict["child_ingots"]
	    del sendDict["child_ingots"]
	    sendDict["non_trivial_inputs"] = sendDict["non_trivial_ingots"]
	    del sendDict["non_trivial_ingots"]
	    sendDict["child_inputs"] = childIngotString
	    return sendDict
	
    class InputGeneratorHandler(GenController.IngotGeneratorHandler):
	def additionalSignalHandler(self, signal, generatorCon, thisGenInfo):
	    if signal == 12:
		#print "Answering a 'seen' query..."
		blockHash = generatorCon.read_int()
		with self.seenBlocksLock:
		    if blockHash in self.seenBlocks:
			print "%d has been seen before." % blockHash
			generatorCon.write_byte(1)
		    else:
			#print "%d has not been seen before." % blockHash
			self.seenBlocks.add(blockHash)
			generatorCon.write_byte(0)
	    elif signal == 14:
		emailSubject = generatorCon.read_string()
		emailBody = generatorCon.read_string()
		p = os.popen("%s -t" % EMAIL_SENDMAIL, "w")
		p.write("From: %s\n" % EMAIL_FROM_FIELD)
		p.write("To: %s\n" % EMAIL_TO_FIELD)
		p.write("Subject: %s\n" % emailSubject)
		p.write("\n") # blank line separating headers from body
		p.write("%s" % emailBody)
		p.write("\n")
		p.close()
	    else:
		print "Bad signal %d." % signal

	def getIngotPriority(self, inputDict, thisGenInfo):
            # We're limiting priority to have upper bound = 2**30-2
	    priority = inputDict['prior_labels']
            priority = -1 * priority + (2**29-1)
	    with self.seenEIPLock:
		if inputDict['eip'] not in self.seenEIPs:
		    priority += (2**29-1)
		    self.seenEIPs.add(inputDict['eip'])
	    return priority

def getComArgs():
    parser = ArgumentParser()
    parser.add_argument("-b", "--bindAddr", default=":12777", help="The address to which the input controller will try to bind.")
    parser.add_argument("--dbAddr", default="127.0.0.1:12666", help="The address at which the input controller will try to find the database controller")
    parser.add_argument("--tracePoolAddr", default="127.0.0.1:12001", help="The address at which the input controller will try to find the trace pool")
    parser.add_argument("--inputPoolAddr", default=":12002", help="The address at which the input controller will bind for the input pool")
    parser.add_argument("--connIniPath", default="connection.ini", help="The\
        path at which the input controller will look for the ini file that \
        sets connection options")
    argNS = parser.parse_args()
    return argNS.__dict__
	
def main():
    print "Starting the Input Controller..."
    argDict = getComArgs()
    netcomm.setConnInfo(setConnectionIniArgs(argDict["connIniPath"]))
    INPUT_CONTROLLER = netcomm.addrStringToTuple(argDict["bindAddr"])
    TRACE_POOL = netcomm.addrStringToTuple(argDict["tracePoolAddr"])
    INPUT_POOL = netcomm.addrStringToTuple(argDict["inputPoolAddr"])
    DB_CONTROLLER = netcomm.addrStringToTuple(argDict["dbAddr"])
    dbIngotFormat = netcomm.Formats.inputGenInputDBInfo

    dbOreFormat = netcomm.Formats.inputGenTraceDBInfo
    
    ingotBundleFormat = netcomm.Formats.inputGenReport
    dbCon = Connection(addrpair=DB_CONTROLLER)
    dbCon.write_byte(2)
    thisController = InputGenController(InputGenController.InputGeneratorHandler, 
		    InputGenController.InputGenInfo, INPUT_CONTROLLER, \
		    TRACE_POOL, netcomm.Formats.traceFormat, \
		    netcomm.Formats.inputFormat, dbCon, dbOreFormat, \
                    dbIngotFormat, ingotBundleFormat, INPUT_POOL)
    thisController.start()


main()
