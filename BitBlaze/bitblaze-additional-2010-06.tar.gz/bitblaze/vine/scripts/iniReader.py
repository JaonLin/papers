# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from ConfigParser import SafeConfigParser
import os

def interpretBool(item, default=False):
    if type(item) == type(True):
        return item
    assert type(item) == type("string"), \
        "Error: Unexpected type in interpretBool: " + str(type(item))
    item = item.lower()
    if item == "yes" or item == "true":
        return True
    if item == "no" or item == "false":
        return False
    if item == "":
        return default
    else:
        assert False, \
            "Error: Can't interpret value as true or false: " + item

def setTraceGenIniArgs(iniFile):
    retDict = {"replay":False, "use_x":True, "delete_traces":False, \
        "output_dir":"/tmp/trace_generator", "taint_nic":True, \
        "post_iteration_script":None, "server_mode":True, \
        "tap_macaddr":"9a:50:7c:1d:ef:6d"}
    parser = SafeConfigParser()
    parser.read(iniFile)
    sectionOptionPairs = []
    optionList = []
    for section in parser.sections():
        for option in parser.options(section):
            optionList.append(option)
            sectionOptionPairs.append((section, option))
    assert set(["plugin_so_file", "bitfuzz_path", "temu_path", "temu_port",\
        "tap", "key_file"]) <= set(optionList), "Error: options temu_path, \
        temu_port, tap, and key_file must all be specified. Options \
        specified were " + str(optionList)
    for section, option in sectionOptionPairs:
        retDict[option] = parser.get(section, option)
    retDict["temu_port"] = int(retDict["temu_port"])
    retDict["replay"] = interpretBool(retDict["replay"], False)
    retDict["use_x"] = interpretBool(retDict["use_x"], True)
    retDict["delete_traces"] = interpretBool(retDict["delete_traces"], False)
    retDict["taint_nic"] = interpretBool(retDict["taint_nic"], True)
    retDict["server_mode"] = interpretBool(retDict["server_mode"], True)
    print "Trace Gen Ini dict is :" + str(retDict)
    return retDict

def getIfThere(parser, section, option):
    if parser.has_option(section, option):
        return parser.get(section, option)
    else:
        return ""

def getItems(fillDict, parser, section, requiredItems, optionalItems=[]):
    assert parser.has_section(section), "Error: Missing section %s" % \
        section
    for item in requiredItems:
        assert item in parser.options(section), \
            "Error: %s required in section %s." % (item, section)
        fillDict[item] = parser.get(section, item)
    for item in optionalItems:
        fillDict[item] = getIfThere(parser, section, item)

def convertTo(initDict, conversionList, convType):
    conversionTable = {"bool":interpretBool, "int":int}
    assert convType in conversionTable, \
        "Do not know how to convert to type %s." % convType
    convFunc = conversionTable[convType]
    for item in conversionList:
        initDict[item] = convFunc(initDict[item])
    return initDict

def rename(origDict, renameDict):
    newDict = {}
    for key in origDict:
        if key in renameDict:
            newDict[renameDict[key]] = origDict[key]
        else:
            newDict[key] = origDict[key]
    return newDict

def setConnectionIniArgs(configFile):
    retDict = {}
    parser = SafeConfigParser()
    if os.path.exists(configFile):
        parser.read(configFile)
    else:
        print "Cannot open %s, using default connection options." % configFile
        return {"local":False, "cleanup":True, \
            "temp_file_prefix":"/tmp/tmpfiles"}
    print "Opening %s for connection options." % configFile
    getItems(retDict, parser, "files", [], ["local", "cleanup", \
        "temp_file_prefix"])
    convertTo(retDict, ["local", "cleanup"], "bool")
    return retDict

def setTraceControlIniArgs(configFile):
    parser = SafeConfigParser()
    renameDict = {"test_key":"testKey", "server_mode":"serverMode", \
        "net_input_file":"netIn", "net_dest":"netDest", \
        "net_protocol":"netProtocol", "taint_files":"taintFiles", \
        "guest_paths":"outPaths", "post_taint_timeout":"postTaintTimeout", \
        "name":"procName", "stdin_file":"input", "stop_addrs":"stopAddr", \
        "net_input_dir":"netInDir"} 
    parser.read(configFile)
    retDict = {"command":"", "stdin_file":"", "argv":"", "timeout":-1, \
        "post_taint_timeout":-1, "stop_addrs":"", "taint_files":"", \
        "guest_paths":"", "name":"", "pid":0, "pidGiven":False, \
        "net_protocol":"tcp", "server_mode":False, "net_input_file":"", \
        "net_dest":"10.0.0.2:53", "net_input_dir":""}
    getItems(retDict, parser, "startup", ["test_key", "server_mode"])
    retDict["server_mode"] = interpretBool(retDict["server_mode"])
    if retDict["server_mode"]:
        getItems(retDict, parser, "net", \
            ["net_input_file", "net_dest", "net_protocol"], \
            ["net_input_dir"])
        assert retDict["net_protocol"] == "tcp" or \
            retDict["net_protocol"] == "udp", \
            "Illegal protocol, must be tcp or udp."
    else:
        getItems(retDict, parser, "setup", ["command"], \
            ["argv", "stdin_file", "taint_files", "guest_paths"])
        assert retDict["argv"] or retDict["stdin_file"] or \
            retDict["taint_files"], \
            "Error: Without an argv, stdin_file, or taint_files, there is \
            nothing to taint. Fill in one or more of these fields."
        assert retDict["taint_files"].count(",") == \
            retDict["guest_paths"].count(","), "Error: Number of comma \
            separated taint_files and guest_paths do not match."
    if parser.has_section("stopping"):
        getItems(retDict, parser, "stopping", [], \
            ["timeout", "post_taint_timeout", "stop_addrs"])
        convertTo(retDict, ["timeout", "post_taint_timeout"], "int")
    if parser.has_section("process"):
        getItems(retDict, parser, "process", [], ["name", "pid"])
        if "pid" in retDict:
            if retDict["pid"] == "":
                retDict["pid"] = 0
                retDict["pidGiven"] = False
            else:
                retDict["pid"] = int(retDict["pid"])
                retDict["pidGiven"] = True
        else:
            retDict["pid"] = None
            retDict["pidGiven"] = False
    if parser.has_section("path"):
        if parser.has_option("path", "bitfuzz_path"):
            retDict["bincovpath"] = os.path.join(parser.get("path", \
                "bitfuzz_path"), "src/coverage")
        else:
            retDict["bincovpath"] = "../../src/coverage"
    if retDict["server_mode"]:
        assert retDict["pid"] or retDict["name"], \
            "Error: When in server mode, you must specify either the name \
            or the pid of the process under test in the [process] section."
    retDict = rename(retDict, renameDict)
    print "retDict is " + str(retDict)
    return retDict

