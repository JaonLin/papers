#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import socket
import pickle, sys, random, struct, re
from subprocess import Popen, PIPE, STDOUT
from samate_config import *
from netcomm import Connection

import os, os.path
SHARED_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    
def setWithTags(tags, message):
    lastIdx = 0
    argv = ""
    stdin = ""
    for tag, length in tags:
	endIdx = lastIdx + length
	field = message[lastIdx:endIdx]
	lastIdx = endIdx
	if tag == "argv":
	    argv = field
	elif(tag == "stdin"):
	    stdin = field
	else:
	    winPath = tag.replace("/", "\\")
	    outFile = open(winPath, "w")
	    outFile.write(field)
	    outFile.close()
    return argv, stdin

def getTags(clean_sw):
    tagList = []
    numTags = clean_sw.read_int()
    print "Num Tags: %d" % numTags
    for i in range(numTags):
	tag = clean_sw.read_string()
	length = clean_sw.read_int()
	tagList.append((tag, length))
    print "Tag list is " + str(tagList)
    return tagList

def read_tainted_msg(tainted_sw, clean_sw):
    msg_len = clean_sw.read_int()
    msg = tainted_sw.read(msg_len)
    return msg

def handle(tainted_sw, clean_sw):
    while True:
        num = clean_sw.read_int()
        command = clean_sw.read_string()
	
	argv = ""
	stdin = ""
	tagList = getTags(clean_sw)
	taintedMsg = read_tainted_msg(tainted_sw, clean_sw)
	argv, stdin = setWithTags(tagList, taintedMsg)
	print "Tainted msg is %s" % taintedMsg
	
        print "[%.8d] Executing: \"%s\" " % (num, command.replace("/","\\"))

        invoked = Popen(command.replace("/", "\\") + " " + argv, stdin=PIPE, stdout=PIPE, stderr=PIPE)
            # send argv to invoker
        clean_sw.write_int(invoked.pid)

            # wait for signal that tracing has started
        go = clean_sw.read_int()
        if go != 1:
            print "[%.8d] Command received was not 1!" % num
            return
	
        out, err = invoked.communicate(stdin)
        print "[%8d] Tracing has started!" % num

            # write to invoked's stdin, signalling it to execute the program
        print "[%.8d] Command Invoked" % num

             # see the return code of the process
        retcode = invoked.poll()

        print "[%.8d] Returned %d [%d bytes stdout, %d bytes stderr]" % (num, retcode, len(out), len(err))

            # copy the return code to the network

        #Note the read_int here. This was put here to try to limit the 
        #number of instructions in the .trace files. This was based on
        #an erroneous mental model for how these instructions enter the
        #trace file, and did not help. We kept it, however, because it
        #doesn't do any harm and we didn't want to re-do past images.
        clean_sw.write_int(retcode)
	clean_sw.read_int()
        clean_sw.write_string(out)
        clean_sw.write_string(err)

def main():
    print "Listening..."
    tainted_sw = Connection(addr="", port=TAINT_PORT, listen=True)
    clean_sw = Connection(addr="", port=CLEAN_PORT, listen=True)
    print "Connected!"
    handle(tainted_sw, clean_sw)
    

if __name__ == "__main__":
    main()
