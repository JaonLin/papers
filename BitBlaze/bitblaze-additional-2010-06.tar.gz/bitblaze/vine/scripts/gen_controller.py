# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
import threading
from pool import PoolServer
import time
import os
from SocketServer import TCPServer, StreamRequestHandler, ThreadingMixIn
from netcomm import Connection
import weakref, new
import pdb
from Queue import Queue, PriorityQueue


class ThreadingTCPServer(ThreadingMixIn, TCPServer):
    pass

def setOuterObj(innerClass, obj):
    setattr(innerClass, "__outerObj__", obj)

class GenController(object):

    def __init__(self, GenHandlerClass, GenInfoClass, controllerAddr, oreAddr,\
		oreFormat, ingotFormat, dbCon, dbOreFormat, dbIngotFormat, \
		ingotBundleFormat, poolAddr):
        self.poolServer = PoolServer(poolAddr, ingotFormat)
	self.idleGenerators = Queue(0)
	self.genInfos = []
	self.genInfoLock = threading.Lock()
	self.currentID = 1
	self.idLock = threading.Lock()
	setOuterObj(GenHandlerClass, self)
	self.GenHandlerClass = GenHandlerClass
	setOuterObj(GenInfoClass, self)
	self.GenInfoClass = GenInfoClass
	self.controllerAddr = controllerAddr
	self.oreAddr = oreAddr 
        self.oreCon = None 
	self.oreFormat = oreFormat
	self.ingotFormat = ingotFormat
	self.dbCon = dbCon
	self.dbOreFormat = dbOreFormat
	self.dbIngotFormat = dbIngotFormat
	self.ingotBundleFormat=ingotBundleFormat
        self.pool = self.poolServer.pool 

    def stopCondition(self):
	return False

    def handleIdleGenerators(self):
	while not self.stopCondition():
            currentGeneratorIdx = self.idleGenerators.get()
            print "Getting for an idle generator..."
            oreDict = self.oreCon.get_format(self.oreFormat)
            print "Got data from the other generator..."
            with self.genInfoLock:
                currentGeneratorInfo = self.genInfos[currentGeneratorIdx]
            currentGeneratorInfo.reset(oreDict["id"])
            currentGeneratorInfo.setOreDict(oreDict)
            print "Sending to the generator"
            currentGeneratorInfo.genCon.send_format(self.oreFormat, oreDict)
            print "Item sent."
        print "Stop condition reached, idle generator handler terminating."

    def reject(self, ingotDict):
        return False

    def getIngotID(self):
	with self.idLock:
	    retID = self.currentID
	    self.currentID += 1
	return retID


    def start(self):
	serveIdleThread = threading.Thread(target=self.handleIdleGenerators)
	generatorServer = ThreadingTCPServer(self.controllerAddr, self.GenHandlerClass)
        serverThread = threading.Thread(target=generatorServer.serve_forever)
        self.poolServer.start()
        print "Binding to an ore address of %s:%d" % self.oreAddr
        self.oreCon = Connection(addrpair=self.oreAddr)
	serveIdleThread.start()
        serverThread.start()
        
    class GeneratorInfo(object):
	def __init__(self, genID, genCon, client_addr):
	    self.genCon = genCon
            self.oreDict = {}
	    self.oreID = -1
	    self.nontrivialIngots=0
	    self.generatedIngots = []
	    self.gen_addr = "%s:%d" % client_addr
	    self.startTime = time.time()

        def setOreDict(self, oreDict):
            self.oreDict = oreDict

	def makeSendDict(self):
	    sendDict = {}
	    sendDict["id"] = self.oreID
	    sendDict["child_ingots"] = len(self.generatedIngots)
	    sendDict["non_trivial_ingots"] = self.nontrivialIngots
	    sendDict["proc_time"] = time.time() - self.startTime
	    return sendDict

	def report(self):
	    if self.oreID < 0:
		return
	    sendDict = self.makeSendDict()
		#pdb.set_trace()
            self.dbCon.send_format(self.dbOreFormat, sendDict, signal=1)


	def reset(self, ore):
	    self.oreID = ore
            self.oreDict = {}
	    self.nontrivialIngots = 0
	    self.generatedIngots = []
	    self.startTime = time.time()

	def isIngotValuable(self, ingotDict):
	    raise NotImplementedError

	def addIngot(self, ingotDict):
	    self.generatedIngots.append(ingotDict["id"])
	    if self.isIngotValuable(ingotDict):
		self.nontrivialIngots += 1


	def __getattr__(self, attrName):
	    if attrName in self.__dict__:
		return object.__getattribute__(self, attrName)
	    else:
		return self.__outerObj__.__getattribute__(attrName)

    class IngotGeneratorHandler(StreamRequestHandler):

	def additionalSignalHandler(self, signal, generatorCon):
	    print "Error: Unknown signal %d" % signal

	def handle(self):
	    newCon = Connection(rf=self.rfile, wf=self.wfile)
            print "Received a connection from a Generator"
            self.generatorCycle(newCon)

        def generatorCycle(self, generatorCon):
	    with self.genInfoLock:
		thisGeneratorID = len(self.genInfos)
		thisGenInfo = self.GenInfoClass(thisGeneratorID, generatorCon, self.client_address)
		self.genInfos.append(thisGenInfo)
	    while not self.stopCondition():
		signal = generatorCon.read_byte()
		print "Got signal %d" % signal
		if signal == 5:
		    print "Adding the generator to the idle generators..."
		    thisGenInfo.report()
                    self.idleGenerators.put(thisGeneratorID)
		elif signal == 10:
		    print "Processing ingot sent..."
		    retDict = self.recvIngotBundle(generatorCon)
                    print "Got bundle..."
                    if not self.reject(retDict):
                        retDict["id"] = self.getIngotID()
                        print "Starting prioritization..."
                        retDict['priority'] = self.getIngotPriority(retDict, \
                            thisGenInfo)
                        print "Finished prioritization."
                        retDict["parent_id"] = thisGenInfo.oreID
                        retDict["gen_addr"] = thisGenInfo.gen_addr
                        thisGenInfo.addIngot(retDict)
                        print "Updating DB..."
                        self.updateIngotDB(retDict)
                        print "Updated DB..."
                        self.pool.put(retDict)
                        print "Pool size is now %d" % self.pool.getsize()
                    else:
                        thisGenInfo.oreDict["priority"] = thisGenInfo.oreDict["priority"]/1.189 #2^(1/4) -- Give it 4 tries if loadvm fails -- PP
                        self.oreCon.send_format(self.oreFormat, thisGenInfo.oreDict, signal=9)
		else:
		    self.additionalSignalHandler(signal, generatorCon, \
                            thisGenInfo)

	def getIngotPriority(self, ingotDict, thisGenInfo):
	    raise NotImplementedError, "The priority calculation must be overridden \
		  by subclasses."

	def updateIngotDB(self, retDict):
            self.dbCon.send_format(self.dbIngotFormat, retDict, signal=2)

	def recvIngotBundle(self, ingotGenCon):
	    return ingotGenCon.recv_format(self.ingotBundleFormat)

	def __getattr__(self, attrName):
	    if attrName in self.__dict__:
		return object.__getattr__(self, attrName)
	    else:
		return self.__outerObj__.__getattribute__(attrName)
