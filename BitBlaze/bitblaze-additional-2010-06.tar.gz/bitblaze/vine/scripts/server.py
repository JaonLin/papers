#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
import os, sys, time, SocketServer, types, select, re
import threading, sys, socket
from AsyncSubprocess import Popen, PIPE
from netcomm import Connection
from ConfigParser import SafeConfigParser
from config import PIDFILE, PROCCMD 
from iniReader import setTraceGenIniArgs
import argparse

seenPIDs = set([])
seenPIDLock = threading.Lock()
seenProcNames = set([])
seenProcNameLock = threading.Lock()

argDict = {}
iniInfo = {}

def start_temu_server(temu):
    """
    Start the server that listens on localhost port PORT.
    
    Accepts connections and executes the commands sent to it on TEMU. Works by
    copying the command to TEMU's stdin.
    """
    temuInputLock = threading.Lock()
    while not is_temu_running():
        time.sleep(1)

    notifyThreads = []
    notifyThreadLock = threading.Lock()
    tainting = threading.Event()
    pluginLoaded = threading.Event()
    emulating = threading.Event()
    tracing = threading.Event()
    commandConsumed = threading.Event()
    tracestop = threading.Event()
    cycleEnd = threading.Event()
    traceUserException = threading.Event()
    traceProcessExit = threading.Event()

    def startNotificationThread(notifyEvent, notifyConn):
        def threadContents():
            while not cycleEnd.isSet() and not notifyEvent.isSet(): 
                time.sleep(1)
            if notifyEvent.isSet():
                notifyConn.write_int(1)
            else:
                notifyConn.write_int(2)
        notifyThread = threading.Thread(target=threadContents)
        with notifyThreadLock:
            notifyThreads.append(notifyThread)
        notifyThread.start()

    def startTstopThread(notifyEvent, notifyConn):
        def threadContents():
            while not cycleEnd.isSet() and not notifyEvent.isSet():
                time.sleep(1)
            if traceUserException.isSet():
                notifyConn.write_int(-0xdead)
            elif traceProcessExit.isSet():
                notifyConn.write_int(-0xd)
            else:
                notifyConn.write_int(0)
        notifyThread = threading.Thread(target=threadContents)
        with notifyThreadLock:
            notifyThreads.append(notifyThread)
        notifyThread.start()

    def startDoubleNotificationThread(notifyEvent1, notifyEvent2, notifyConn):
        def threadContents():
            while not cycleEnd.isSet() and not notifyEvent1.isSet() and not notifyEvent2.isSet():
                time.sleep(1)
            if notifyEvent1.isSet():
                if traceUserException.isSet():
                    notifyConn.write_int(-0xdead)
                elif traceProcessExit.isSet():
                    notifyConn.write_int(-0xd)
                else:
                    notifyConn.write_int(0)
            elif notifyEvent2.isSet():
                notifyConn.write_int(1)
            else:
                notifyConn.write_int(2)
        notifyThread = threading.Thread(target=threadContents)
        with notifyThreadLock:
            notifyThreads.append(notifyThread)
        notifyThread.start()

    def waitForMembership(item, memberList, listLock):
        while not cycleEnd.isSet():
            with listLock:
                if item in memberList:
                    break
            with temuInputLock:
                temu.send("guest_ps\n")
                commandConsumed.wait()
                if not cycleEnd.isSet():
                    commandConsumed.clear()
            time.sleep(1)
        return
    
    class TemuCommandHandler(SocketServer.StreamRequestHandler):
        def handle(self):
	    client_conn = Connection(rf=self.rfile, wf = self.wfile)
            inThread = \
                threading.Thread(target=handle_stdin_thread).start()
            while True:
                self.resetState()
                print "State Reset."
                sys.stdout.flush()
                self.clearTemuOut()
                print "Cleared temu's output"
                sys.stdout.flush()
                select.select([self.rfile], [], [])
                commandConsumed.clear()
                outThread = \
                    threading.Thread(target=handle_out_thread)
                outThread.start()
                cycleThread = threading.Thread(target=self.handleOneCycle, \
                    args=(client_conn,))
                cycleThread.start()
                print "Starting run with timeout %d" % argDict["timeout"] # pre-taint timeout
                cycleThread.join(argDict["timeout"]) # pre-taint timeout
                if cycleThread.isAlive():
                    if tainting.isSet(): # taint seen, but tracing not complete
                        cycleThread.join() # let it run until complete (either post-taint timeout or really complete)
                    else:
                        print "Timeout hit, killing the cycle."
                else:
                    print "Cycle ended naturally."
                cycleEnd.set()
                cycleThread.join()
                outThread.join()
                cycleEnd.clear()

        def resetState(self):
            global seenPIDs
            global seenProcNames
            global notifyThreads
            tainting.clear()
            pluginLoaded.clear()
            emulating.clear()
            tracing.clear()
            tracestop.clear()
            seenPIDs = set([])
            seenProcNames = set([])
            traceUserException.clear()
            traceProcessExit.clear()
            notifyThreads = []
            if iniInfo["server_mode"]:
                temu.send("stop\n")
            temu.send("loadvm %s\n" % argDict["snapshot"])
        
        def clearTemuOut(self):
            while True:
                outChar = temu.recv(1)
                if outChar == None or len(outChar) == 0:
                    break
            return
        
        def handleOneCycle(self, client_conn):
            global seenPIDs
            global seenPIDLock
            global seenProcNames
            global seenProcNameLock
	    try:
		notify = False
		while True:
		    command = client_conn.read_string()
		    print "Handling command %s!" % command
                    sys.stdout.flush()
                    if command.startswith("loadvm") or command == "reset":
                        if cycleEnd.isSet():
                            client_conn.write_int(2)
                        else:
                            client_conn.write_int(1)
                        break
		    if command == "notify":
			print "Incrementing notify..."
			notify = True
                    elif command == "block_taint":
                        startNotificationThread(tainting, client_conn)
                    elif command == "block_tstop":
                        startTstopThread(tracestop, client_conn)
                    elif command == "block_t_or_t":
                        startDoubleNotificationThread(tracestop, tainting, client_conn)
                    elif command.startswith("block_name"):
                        name = command[10:].strip()
                        print "Blocking on name %s" % name
                        waitForMembership(name, seenProcNames, seenProcNameLock)
                        if not cycleEnd.isSet():
                            client_conn.write_int(1) 
                            print "Name seen!"
                        else:
                            client_conn.write_int(2)
                    elif command.startswith("block_pid"):
                        pid = command[9:].strip()
                        print "Blocking on pid %s" % pid
                        waitForMembership(pid, seenPIDs, seenPIDLock)
                        if not cycleEnd.isSet():
                            client_conn.write_int(1)
                            print "PID seen!"
                        else:
                            client_conn.write_int(2)
                    elif command == "block_plugin":
                        print "Blocking on plugin..."
                        startNotificationThread(pluginLoaded, client_conn)
                    elif command == "block_emulation":
                        print "Blocking on emulation..."
                        startNotificationThread(emulating, client_conn)
                    elif command == "block_tracing":
                        print "Blocking on the start of tracing."
                        startNotificationThread(tracing, client_conn)
		    elif command == "trace_stop":
                        tracing.clear()
                        if not cycleEnd.isSet():
                            with temuInputLock:
                                if not cycleEnd.isSet():
                                    commandConsumed.clear()
                                    temu.send(command + "\n")
                                    commandConsumed.wait()
                                    if not cycleEnd.isSet():
                                        commandConsumed.clear()
			if notify:
			    print "Notifying..."
			    client_conn.write_int(1)
			    client_conn.flush()
			    notify = False
                    else:
                        if not cycleEnd.isSet():
                            with temuInputLock:
                                if not cycleEnd.isSet():
                                    temu.send(command + "\n")
                                    commandConsumed.wait()
                                    if not cycleEnd.isSet():
                                        commandConsumed.clear()
			if notify:
			    print "Notifying..."
			    client_conn.write_int(1)
			    client_conn.flush()
			    notify = False
	    except KeyboardInterrupt:
		pass
            for notifyThread in notifyThreads:
                notifyThread.join()
            print "Cleaned up all threads for a run, exiting the runCycle \
                    thread"

    def handle_stdin_thread():
	command = ""
	while command.strip() != "quit":
	    rlist, dummy, dummy = select.select([sys.stdin],[],[])
	    command = sys.stdin.readline()
	    with temuInputLock:
		temu.send(command)
	sys.exit()

    def nonBlockingReadline(timeout):
        startTime = time.time()
        currentString = ""
        while time.time() < startTime + timeout:
            newChar = temu.recv(1)
            currentString += newChar
            if newChar == "\n":
                break
        return currentString
                
    def handle_out_thread():
        global seenPIDs
        global seenPIDLock
        global seenProcNames
        global seenProcNameLock
        while not cycleEnd.isSet():
            readyOuts, dummy, dummy2 = \
                select.select([temu.stdout],[], [], 2)
            for readyOut in readyOuts:
                temuOut = ""
                while "(qemu)".find(temuOut) != -1 \
                    and len(temuOut) < 6 and not cycleEnd.isSet():
                        temuOut += temu.recv(6-len(temuOut))
                if temuOut == "(qemu)":
                    commandConsumed.set()
                restOfLine = ""
                while restOfLine.find("\n") == -1 and not cycleEnd.isSet():
                    restOfLine += nonBlockingReadline(3)
                temuOut = temuOut + restOfLine
                sys.stdout.write(temuOut)
                sys.stdout.flush()                
                if temuOut.find("Time of first tainted data:") != -1:
                    print "Tainting recognized."
                    tainting.set()
                elif temuOut.find("Stop tracing process") != -1:
                    print "Tracestop recognized."
                    tracestop.set()
                elif temuOut.find("is loaded successfully!") != -1:
                    print "Plugin loaded."
                    pluginLoaded.set()
                elif temuOut.find("Emulation is now enabled") != -1:
                    print "Emulation started."
                    emulating.set()
                elif temuOut.find("Emulation has been already enabled!") != -1:
                    print "Emulation started."
                    emulating.set()
                elif temuOut.find("User exception detected") != -1:
                    print "Traced process crashed due to user exception."
                    traceUserException.set()
                elif re.search(r"Process\s[0-9]+\sexitted.", temuOut):
                    traceProcessExit.set()
                elif temuOut.find("Waiting for process") != -1:
                    tracing.set()
                elif re.search(r"PID:\s[0-9]+\sCR[0-9]+:\s0x[0-9a-fA-F]+", \
                        temuOut): 
                    tracing.set()
                else:
                    psItemMatch = re.match(\
                    r"([0-9]+)\s+cr[0-9]+=0x[0-9a-fA-F]+\s+([a-zA-Z0-9.]+)",
                    temuOut)
                    if psItemMatch:
                        with seenPIDLock:
                            seenPIDs.add(psItemMatch.group(1))
                        with seenProcNameLock:
                            seenProcNames.add(psItemMatch.group(2))
                sys.stdout.flush()
        commandConsumed.set()
        print "Exiting the handle_out thread"
        sys.stdout.flush()
    
    bound = False
    while not bound:
	try:
	    server = SocketServer.TCPServer(("localhost", iniInfo["temu_port"]), TemuCommandHandler)
	    bound = True
	except socket.error, e:
	    print "Couldn't bind, retrying..."
	    time.sleep(5)

    print "[pytemu] Listening for commands..."
    try:
	server.serve_forever()
    except KeyboardInterrupt:
	sys.exit()

def is_temu_running():
    """
    Checks if TEMU is running by looking in /tmp for the pid file and ensuring
    that the specified pid is indeed TEMU.

    It checks the PID by reading the appropriate file from /proc
    """
    try:
        f = open(PIDFILE)
    except IOError:
        return False
    fileText = f.read().strip()
    if fileText[-1] == 0 and fileText[-2] == '\n':
	fileText = fileText[:-1].strip()
    pid = int(fileText)
    try:
        f = open(PROCCMD % pid)
    except IOError:
        return False
    cmdline = f.read().strip()
    return cmdline.find("temu") != -1

def start_temu():
    """
    Starts TEMU and the command-listen server.

    command is a list of arguments, or [] for default.
    """

    if is_temu_running():
        sys.stderr.write("Temu already running!\n")
        sys.exit()
    
#    start_network()

    vmTap = iniInfo["tap"]
    print "Using tap %s" % vmTap
    command = [iniInfo["temu_bin"]]
    d = {}
    d['-pidfile'] = PIDFILE
    d['-load-plugin'] = iniInfo["plugin_so_file"]
    d['-net'] = ('nic,vlan=0', 'tap,vlan=0,ifname=%s,script=no,downscript=no' % vmTap)
    d['-monitor'] = 'stdio'
    #d['-loadvm'] = argDict["snapshot"]
    if "guest_memory" in iniInfo:
        d['-m'] = iniInfo["guest_memory"]

    d['-L'] = iniInfo["temu_path"] + "/pc-bios"

    for k, v in d.items():
        if type(v) == types.TupleType:
            for v1 in v:
                command.append(k)
                command.append(v1)
        else:
            command.append(k)
            command.append(v)

    if not iniInfo["use_x"]:
        command.append("-nographic")

    command.append(iniInfo["temu_extra_options"])

    for v in ['-kernel-kqemu', argDict["imagePath"]]:
        command.append(v)

    print "Running command: %s" % " ".join(command)
    bitfuzzLLP = os.getenv("BITFUZZLLP")
    if bitfuzzLLP != None:
        os.environ["LD_LIBRARY_PATH"] = bitfuzzLLP
    temu = Popen(" ".join(command), stdin=PIPE, stdout=PIPE, shell=True)

    start_temu_server(temu)
    temu.send("\n")

def getComArgs():
    global argDict
    parser = argparse.ArgumentParser()
    parser.add_argument("iniPath", help="The path to the config file for trace_generator and server")
    parser.add_argument("imagePath", help="The path to the image to be run")
    parser.add_argument("snapshot", help="The name of the snapshot to be used")
    parser.add_argument("timeout", type=int, help="The max amount of time after seeing a command which the server will allow before reporting failure and resetting the VM.")
    parsed_ns = parser.parse_args()
    argDict = parsed_ns.__dict__

def main():
    global iniInfo
    getComArgs()
    iniInfo = setTraceGenIniArgs(argDict["iniPath"])
    start_temu()

if __name__ == "__main__":
    main()
