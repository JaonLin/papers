#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

from __future__ import with_statement
from subprocess import Popen, PIPE
import os
import netcomm
import time
from netcomm import Connection
from argparse import ArgumentParser
from gen_controller import GenController
import threading
from ConfigParser import SafeConfigParser
from iniReader import setTraceControlIniArgs, setConnectionIniArgs

class TraceGenController(GenController):
    def __init__(self, GenHandlerClass, GenInfoClass, controllerAddr, orePair, \
                    oreFormat, ingotFormat, dbCon, dbOreFormat, dbIngotFormat, \
                                    ingotBundleFormat, poolAddr, commandOptions, initInput, covProgramPath):
        super(self.__class__, self).__init__(GenHandlerClass, GenInfoClass, controllerAddr, orePair,\
                        oreFormat, ingotFormat, dbCon, dbOreFormat, dbIngotFormat, \
                        ingotBundleFormat, poolAddr)
        self.seenBlocks = set([])
        self.seenBlocksLock = threading.Lock()
	self.commandOptions = commandOptions
        self.initInput = initInput
        self.initInputDir = commandOptions["netInDir"]
        self.covProgramPath = covProgramPath

    def start(self):
        super(self.__class__, self).start()
        seedInitInput(self.initInput, self.initInputDir, self.oreCon)        

    def reject(self, traceReportDict):
        return ((not traceReportDict["finished"]) or \
            (os.stat(traceReportDict["trace"]).st_size == 0))

    class TraceGenInfo(GenController.GeneratorInfo):
	def isIngotValuable(self, inputDict):
	    return True

	def makeSendDict(self):
	    sendDict = {}
	    sendDict["id"] = self.oreID
            if len(self.generatedIngots) > 0:
	        sendDict["child_trace"] = self.generatedIngots[0]
            else:
                sendDict["child_trace"] = -1
	    return sendDict

    class TraceGeneratorHandler(GenController.IngotGeneratorHandler):
	def additionalSignalHandler(self, signal, generatorCon, thisGenInfo):
	    if signal == 7:
		generatorCon.write_int(thisGenInfo.oreID)
	    elif signal == 2:
		print "Sending command options: " + str(self.commandOptions)
		generatorCon.send_format(netcomm.Formats.traceOptionsReport, self.commandOptions)
	    else:
		print "Error: Bad signal %d" % signal

	def calculateScore(self, outText):
	    newBlocks = 0
	    for addr in outText.strip().split("\n"):
		with self.seenBlocksLock:
		    if addr not in self.seenBlocks:
			newBlocks += 1
			self.seenBlocks.add(addr)
	    return newBlocks
	

	def getIngotPriority(self, ingotDict, thisGenInfo):
	    blockCovPath = self.covProgramPath
	    traceFile = ingotDict["trace"]
            print "Running command: %s %s" % (blockCovPath, traceFile)
	    procObj = Popen("%s %s" % (blockCovPath, traceFile),  stdout=PIPE, stdin=PIPE, shell=True)
            outText, dummy = procObj.communicate()
            if ingotDict["return_code"] == -0xdead:
                return -1
            else:
                return self.calculateScore(outText)

def seedInitInput(initInput, initInputDir, inputPoolCon):
    print "Seeding an initial input"
    inputDict = {}
    inputDict["id"] = 0
    inputDict["priority"] = 2000000
    inputDict["input"] = initInput
    inputPoolCon.put_input(inputDict)

    if initInputDir != None and os.path.exists(initInputDir):
        dirList = os.listdir(initInputDir)
        id = 0
        for inputFile in dirList:
            id = id + 1
            print "Reading %s" % os.path.join(initInputDir, inputFile)
            content = open(os.path.join(initInputDir, inputFile), "r").read()
            inputDict = {}
            inputDict["id"] = id
            inputDict["priority"] = 2000000
            inputDict["input"] = content
            inputPoolCon.put_input(inputDict)

def packageTaint(input, argv, outPath, taintFile, serverMode, netIn):
    taintPairs = []
    msg = ""
    if serverMode:
        netInContents = open(netIn, "r").read()
        taintPairs.append(("netIn", len(netInContents)))
        msg += netInContents
    else:
        if input:
            input = open(input, "r").read()
            taintPairs.append(("stdin", len(input)))
            msg += input
        if argv != "" and argv != None:
            taintPairs.append(("argv", len(argv)))
            msg += argv
        if outPath and taintFile:
            paths = outPath.split(",")
            taintFiles = taintFile.split(",")
            assert len(paths) == len(taintFiles), "Mismatched outPaths and taintFiles"
            for path, taintFile in zip(paths, taintFiles):
                contents = open(taintFile, "r").read()
                taintPairs.append((path, len(contents)))
                msg += contents
    return taintPairs, msg

def getComArgs():
    parser = ArgumentParser()
    parser.add_argument("--startTime", required=True, type=int, help="The time at which the test was started, in an integer number of seconds from the epoch.")
    parser.add_argument("--dontreload", action="store_true", help="Causes the VM not to reload, useful for seeing debugging output in the guest machine")
    parser.add_argument("-b", "--bindAddr", default=":12888", help="The address to which the trace controller will bind. Default is 127.0.0.1:12888.")
    parser.add_argument("--dbAddr", default="127.0.0.1:12666", help="The address at which the trace controller will try to find the database controller. Default is 127.0.0.1:12666.")
    parser.add_argument("--tracePoolAddr", default=":12001", help="The address at which the trace controller will try to bind to make the trace pool. Default is 127.0.0.1:12001.")
    parser.add_argument("--inputPoolAddr", default="127.0.0.1:12002", help="The address at which the trace controller will look for the input pool. Default is 127.0.0.1:12002.")
    parser.add_argument("--iniPath", default="trace_controller.ini", help="The path at which the trace controller will look for its ini config file.")
    parser.add_argument("--connIniPath", default="connection.ini", help="The\
        path at which the controller will look for the config file for \
        connections")
    argNS = parser.parse_args()
    return argNS.__dict__

def main():
    global connInfo
    print "Starting the Trace Controller..."
    argDict = getComArgs()
    print argDict["iniPath"]
    argDict.update(setTraceControlIniArgs(argDict["iniPath"]))
    argDict["taintPairs"], initInput = packageTaint(argDict["input"],\
        argDict["argv"], argDict["outPaths"], argDict["taintFiles"], \
        argDict["serverMode"], argDict["netIn"])
    netcomm.setConnInfo(setConnectionIniArgs(argDict["connIniPath"]))
    dbIngotFormat = netcomm.Formats.traceGenTraceDBInfo
    dbOreFormat = netcomm.Formats.traceGenInputDBInfo
    ingotBundleFormat = netcomm.Formats.traceGenReport
    TRACE_CONTROLLER = netcomm.addrStringToTuple(argDict["bindAddr"])
    INPUT_POOL = netcomm.addrStringToTuple(argDict["inputPoolAddr"])
    TRACE_POOL = netcomm.addrStringToTuple(argDict["tracePoolAddr"])
    DB_CONTROLLER = netcomm.addrStringToTuple(argDict["dbAddr"])
    BLOCKCOVBIN = argDict["bincovpath"]
    dbCon = Connection(addrpair=DB_CONTROLLER)
    dbCon.write_byte(1)
    thisController = TraceGenController(TraceGenController.TraceGeneratorHandler,
		TraceGenController.TraceGenInfo, TRACE_CONTROLLER, \
                INPUT_POOL, netcomm.Formats.inputFormat, \
		netcomm.Formats.traceFormat, dbCon, dbOreFormat, \
		dbIngotFormat, ingotBundleFormat, TRACE_POOL, argDict, initInput, BLOCKCOVBIN)
    thisController.start()

main()
