#!/usr/bin/env python

# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import os, os.path, sys, logging, time, subprocess
from timeCollector import connectToDBController

CUR_DIR = os.path.abspath(os.path.dirname(__file__))
sys.path.append(CUR_DIR)

try:
    import replay_server
except ImportError:
    pass
import argparse
from netcomm import Connection
from subprocess import Popen, PIPE
import netcomm
import hostcontrol
from ConfigParser import SafeConfigParser
from iniReader import setTraceGenIniArgs, setConnectionIniArgs
TRACE_POOL = ("127.0.0.1", 12003)
INPUT_POOL = ("127.0.0.1", 12002)
DB_CONTROLLER=("127.0.0.1", 12666)

from pysamate import samate_config

logger = logging.getLogger()
logger.setLevel(logging.INFO)

SAMATE_PATH = os.path.join("samate", "programs", "%.6d", "samate.exe")

iniInfo = {}
    
def updateDB(db_conn, run_counter, path, retcode, argv, input, trace_gen_time, timestamp, input_id):
    db_conn.write_int(run_counter)
    db_conn.write_string(path)
    db_conn.write_int(retcode)
    db_conn.write_string(argv)
    db_conn.write_string(input)
    db_conn.write_double(trace_gen_time)
    db_conn.write_double(timestamp)
    db_conn.write_int(input_id)
    print "Finished updating DB."

def getNumFromProc(command):
    countProc = Popen(command, stdout=PIPE)
    stdout, dummmy = countProc.communicate()
    stdout = stdout.strip()
    if stdout.isdigit():
	numInstructions = int(stdout)
    else:
	print "Error in getting number of instructions"
	numInstructions = 0
    return numInstructions

def sendInfoRequest(controllerCon):
    controllerCon.write_byte(2)
    return controllerCon.recv_format(netcomm.Formats.traceOptionsReport)

#This function defines the generator's cycle: It has an intial lead-in where
#it takes an initial command and input, and gets the trace. From there, it
#enters an endless cycle, wherein it requests an input, sends it to be run,
#and uses it to generate a trace.

def makeTraceFilename(startTime):
    timeDir = "%s/%d" % (iniInfo["output_dir"], startTime)
    if not os.path.exists(timeDir):
	try:
	    os.mkdir(timeDir)
	except OSError:
	    pass
    trace_filename = timeDir + "/run_%.5d.trace"
    return trace_filename, timeDir, "run_%.5d"

def reportTrace(controllerCon, **traceDict):
    reportFormat = netcomm.Formats.traceGenReport
    controllerCon.write_byte(10)
    controllerCon.send_format(reportFormat, traceDict, \
        cleanup=iniInfo["delete_traces"])

def getID(controllerCon):
    controllerCon.write_byte(7)
    return controllerCon.read_int()

def getTestInfo(testKey):
    configPath = iniInfo["key_file"]
    imagePath = ""
    snapshot = ""
    if configPath == None:
	print "No config file found for trace generation!"
	sys.exit(1)
    configFile = open(configPath, "r")
    for entry in configFile:
	entry = entry.strip()
	if entry == "" or entry[0] == "#":
	    continue
	assert entry.find(":") != -1, "Malformed config file!"
	entryPieces = entry.split(":")
	if entryPieces[0] == testKey:
	    assert entryPieces[1].count(",") == 1, "Malformed config file!"
	    imagePath, snapshot = entryPieces[1].split(",")
	    break
    if not imagePath or not snapshot:
	print "Image Path and/or snapshot not found."
	sys.exit(1)
    return imagePath.strip(), snapshot.strip()

def startTemuServer(imagePath, snapshotName, pcapDir, iniPath, timeout):
    iniPath = os.path.abspath(iniPath)
    startupPath = iniInfo["bitfuzz_path"]
    if startupPath == None:
        print "Error: Bad Bitfuzz Path!"
    startupPath += "/src/shellScripts"
    noX = (not iniInfo["use_x"])
    subprocess.Popen("./qemu-ifdown %s" % iniInfo["tap"], shell=True, \
        cwd=startupPath).wait()
    subprocess.Popen("./qemu-ifup %s %s" % \
        (iniInfo["tap"], iniInfo["tap_macaddr"]), shell=True, \
        cwd=startupPath).wait()
    subprocess.Popen("sudo tcpdump -i %s -w %s/tapCapture.pcap -s 0" % \
        (iniInfo["tap"], pcapDir),  shell=True)
    bitfuzzLLP = os.getenv("BITFUZZLLP")
    if bitfuzzLLP == None:
        bitfuzzLLP = ""
    os.environ["LD_LIBRARY_PATH"] = bitfuzzLLP
    startupString = "%s/src/trace_generator/pytemu/server.py %s %s %s %d 2>&1 | tee temu_server.log" %\
        (iniInfo["bitfuzz_path"], iniPath, imagePath, snapshotName, timeout) 
    if noX:
        procObj = subprocess.Popen(startupString, shell=True)
    else:
        procObj = subprocess.Popen("xterm -sb -hold -title temu_server -e \
            \"%s\"" % startupString, shell=True)

def cycle(guest_ip=None, clean_port=None, taint_port=None, controller_addr=None, iniPath=""):
    controllerCon = Connection(addrpair=controller_addr) 
    controlInfo = sendInfoRequest(controllerCon)
    trace_filename, traceDir, run_name = makeTraceFilename(controlInfo["startTime"])
    del controlInfo["startTime"]
    imagePath, snapshotName = getTestInfo(controlInfo["testKey"])
    del controlInfo["testKey"]
    startTemuServer(imagePath, snapshotName, traceDir, iniPath, controlInfo["timeout"])    
    del controlInfo["timeout"]
    while True:
        logger.info("Getting input for run")
	retDict = controllerCon.get_input()
	currentID = getID(controllerCon)
	this_trace_filename = trace_filename % currentID
        initOpen = open(this_trace_filename, "w")
        initOpen.close()
	msg = retDict["input"]
        if iniInfo["replay"]:
           replay_server.write(msg)
	logger.info("%d: Got input %s" % (currentID, msg))
        logger.info("%d: Executing run" % currentID)
        print "Control info is " + str(controlInfo)
	return_code, trace_gen_time, timestamp, finishedRun = hostcontrol.runOnce(\
            msg, currentID, this_trace_filename, guest_ip, taint_port, \
            clean_port, snapshotName, iniInfo, **controlInfo)
        logger.info("%d: Running the post iteration script" % currentID)
        post_iteration_script = iniInfo["post_iteration_script"]
        if post_iteration_script != None and os.path.exists(post_iteration_script):
            subprocess.Popen("%s %d %s %s" % (post_iteration_script, currentID, traceDir, (run_name % currentID)), shell=True).wait()
        else:
            logger.info("%d: No post iteration script. Skipping." % currentID)
        logger.info("%d: Recording trace for run" % currentID)
	reportTrace(controllerCon, trace=this_trace_filename, return_code=return_code, \
	    trace_gen_time=trace_gen_time, timestamp=timestamp, input=msg, \
            finished=finishedRun)

def getCommandArgs():
    parser = argparse.ArgumentParser("Connects to a Trace Controller and \
		generates traces based upon the inputs and other info \
		provided to it. Runs forever.")
    parser.add_argument("-i", "--guest-ip", default = "10.0.0.2", help="The IP at which the guest \
			    OS resides. Defaults to 10.0.0.2")
    parser.add_argument("--iniPath", default="trace_generator.ini", \
        help="This option specifies the path at which the trace generator \
        will look for its ini options file.")
    parser.add_argument("-c", "--clean-port", type=int, default=12346, \
		help="The port on the guest machine to which clean data will \
		be sent. Defaults to 12346")
    parser.add_argument("-t", "--taint-port", type=int, default=12345, \
		help="The port on the guest machine to which tainted data will \
		be sent. Defaults to 12345")
    parser.add_argument("--controller-addr", default="127.0.0.1:12888", \
		    help="The address of the controller to which the trace \
		    generator will attempt to connect. Specify it as ip:port.")
    parser.add_argument("--connIniPath", default="connection.ini",help="The\
        address at which the trace_generator will look for the connection \
        ini file.")
    #parser.add_argument("--local", action="store_true")
    parserDict = parser.parse_args().__dict__
    assert parserDict["controller_addr"].count(".") == 3 and parserDict["controller_addr"].count(":") == 1, "Malformed controller_addr"

    parserDict["controller_addr"] = netcomm.addrStringToTuple(parserDict["controller_addr"])
    return parserDict

def main():
    global iniInfo
    argDict = getCommandArgs()
    iniInfo = setTraceGenIniArgs(argDict['iniPath'])
    netcomm.setConnInfo(setConnectionIniArgs(argDict['connIniPath']))
    del argDict['connIniPath']
    cycle(**(argDict))

if __name__ == "__main__":
    main()
