# Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

import SocketServer
from SocketServer import TCPServer, StreamRequestHandler, ThreadingMixIn
import netcomm
from netcomm import Connection
import threading
from Queue import Queue, PriorityQueue

def setOuterObj(innerClass, obj):
    setattr(innerClass, "__outerObj__", obj)

class ThreadingTCPServer(ThreadingMixIn, TCPServer):
   pass

class Pool(object):
    def __init__(self):
       self.pool = PriorityQueue(0)

    def get(self):
        return self.pool.get()[1]

    def reject(self, putDict, rePut):
        return False

    def put(self, putDict, rePut=False):
        print "Putting " + str(putDict)
        if not self.reject(putDict, rePut):
            self.pool.put((-putDict["priority"], putDict))

    def getsize(self):
        return self.pool.qsize()


class PoolServer(object):
    def __init__(self, poolAddr, itemFormat):
        self.poolHandler = handlerFactory(self)
        self.poolAddr = poolAddr
        self.pool = Pool()
        self.itemFormat = itemFormat

    def start(self):
       poolServer = ThreadingTCPServer(self.poolAddr, self.poolHandler)
       serverThread = threading.Thread(target=poolServer.serve_forever)
       serverThread.start()

    def get(self):
        return self.pool.get()

    def put(self, item, rePut=False):
        self.pool.put(item, rePut)

    def getsize(self):
        return self.pool.getsize()

def handlerFactory(outerObj):
    class PoolRequestHandler(StreamRequestHandler):
        def handle(self):
            reqCon = Connection(wf=self.wfile, rf=self.rfile) 
            while True:
                signal = reqCon.read_byte()
                if signal == 5:
                    def requestGet():
                        print "Serving get request..."
                        getDict = self.get()
                        reqCon.send_format(self.itemFormat, getDict)
                        print "Get request finished, pool size is now %d" % self.getsize()
                    getThread = threading.Thread(target=requestGet)
                    getThread.start()
                elif signal == 10:
                    print "Serving put request..."
                    putDict = reqCon.recv_format(self.itemFormat)
                    self.put(putDict)
                    print "Put finished, pool size is now %d" % self.getsize()
                elif signal == 9:
                    print "Serving re-put request..."
                    putDict = reqCon.recv_format(self.itemFormat)
                    self.put(putDict, True)
                elif signal == 15:
                    print "Serving getsize request..."
                    reqCon.write_int(self.getsize())
                else:
                    print "Invalid signal %d" % signal
        
        def __getattr__(self, attrName):
            if attrName in self.__dict__:
                return object.__getattr__(self, attrName)
            else:
                return self.__outerObj__.__getattribute__(attrName)
    PoolRequestHandler.__outerObj__ = outerObj
    return PoolRequestHandler
