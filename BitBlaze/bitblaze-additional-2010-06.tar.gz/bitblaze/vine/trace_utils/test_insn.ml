(*
  Copyright (C) BitBlaze, 2009-2010, and copyright (C) 2010 Ensighta
  Security Inc.  

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)

module SRFM = Sym_region_frag_machine.SymRegionFragMachineFunctor
  (Symbolic_domain.SymbolicDomain)

let main argv = 
  let bytes_arg = ref [] in
    Arg.parse
      (Arg.align (Exec_set_options.cmdline_opts
		  @ Exec_set_options.concrete_state_cmdline_opts
		  @ Exec_set_options.symbolic_state_cmdline_opts
		  @ Options_solver.solver_cmdline_opts
		  @ Exec_set_options.trace_replay_cmdline_opts))
      (fun s -> bytes_arg := (int_of_string s) :: !bytes_arg)
      "test_insn [options]* 0xfe 0xed 0x42 ...\n";
    let dt = ((new Linear_decision_tree.linear_decision_tree)
		:> Decision_tree.decision_tree) in
    let fm = ((new SRFM.sym_region_frag_machine dt)
	      :> Fragment_machine.fragment_machine) in
    let dl = Asmir.decls_for_arch Asmir.arch_i386 in
    let asmir_gamma = Asmir.gamma_create 
      (List.find (fun (i, s, t) -> s = "mem") dl) dl
    in
      fm#init_prog (dl, []);
      Exec_set_options.apply_cmdline_opts_early fm dl;
      Exec_set_options.apply_cmdline_opts_nonlinux fm;
      Options_solver.apply_solver_cmdline_opts fm;
      Exec_set_options.apply_cmdline_opts_late fm;
      let bytes_l = List.map Char.chr (List.rev !bytes_arg) in
      let code_addr = 0x08048000L in
      let bytes_a = Array.of_list bytes_l in
	Array.iteri
	  (fun i b -> fm#store_byte_conc (Int64.add code_addr (Int64.of_int i))
	     (Char.code b)) bytes_a;
	let next_eip = 
	  Exec_run_common.run_one_insn fm asmir_gamma code_addr bytes_a in
	  if !Exec_options.opt_trace_eip then
	    Printf.printf "Next instruction would be at 0x%08Lx\n" next_eip
;;

main Sys.argv;;
