/* Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE. */
#include "debug.h"
#include <set>
#include <string>
#include <iostream>
using namespace std;

static set<string> debugKeys;

bool is_debug_on(const char *key)
{
  return (debugKeys.find(string(key)) != debugKeys.end());
}

void debug_on(const char *key)
{
  debugKeys.insert(string(key));
}

void _print_debug(const char *key, const char *fmt, ...)
{
  va_list args;
  char buf[8192];
  if(!is_debug_on(key))
	return;
  
  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf)-1, fmt, args);
  va_end(args);
  buf[8191] = 0;

  cerr << "++ " << string(key) << ": " << string(buf) << endl;
  cerr.flush();
}

void fatal(const char *funcname, const char *fmt, ...)
{
  va_list args;
  char buf[1024];

  va_start(args, fmt);
  vsnprintf(buf, sizeof(buf)-1, fmt, args);
  va_end(args);
  buf[1023] = 0;
  cerr << "fatal err in " << string(funcname) << ": ";
  cerr << string(buf) << endl;
  cerr.flush();
  exit(-1);
}

