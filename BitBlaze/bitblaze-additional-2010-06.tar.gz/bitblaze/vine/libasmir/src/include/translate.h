/* Copyright (C) BitBlaze, 2009-2010. 

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef   	TRANSLATE_H_
#define   	TRANSLATE_H_

#ifdef __cplusplus
#include <sqlite3.h>
#include <vector>
#include "asm_program.h"
#include "stmt.h"
#include "exp.h"
#include "common.h"
#include "irtoir.h"

using namespace std;

typedef struct instmap_s {
  asm_program_t *prog;
  map<address_t, Instruction *> imap;
} instmap_t;

#else
typedef struct _instmap_t instmap_t;

#endif // __cplusplus

typedef struct _cflow_t { int ctype; address_t target; } cflow_t;


#ifdef __cplusplus
extern "C" {
#endif

   extern asm_program_t *instmap_to_asm_program(instmap_t *map);

  // we pass a filename because I don't know how to pass an ocaml
  // sqlite3 db handle.
  extern instmap_t *sqlite3_fileid_to_instmap(char *filename, int fileid);



  extern instmap_t * filename_to_instmap(const char *filename);

  extern vine_blocks_t *instmap_translate_address_range(instmap_t *insts,
							address_t start,
							address_t end);

  extern vine_block_t *instmap_translate_address(instmap_t *insts,
						 address_t addr);

  extern int instmap_has_address(instmap_t *insts,
				 address_t addr);

  extern cflow_t *instmap_control_flow_type(instmap_t *insts,
					    address_t addr);
  extern address_t get_last_segment_address(const char *filename, 
					    address_t addr);


#ifdef __cplusplus
}
#endif

#endif 	    /* !TRANSLATE_H_ */
