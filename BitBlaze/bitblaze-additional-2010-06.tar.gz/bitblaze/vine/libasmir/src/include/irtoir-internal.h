/* Copyright (C) BitBlaze, 2009-2010. 

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#ifndef __IRTOIR_INTERNAL_H
#define __IRTOIR_INTERNAL_H

#include "irtoir.h"

// functions internal to irtoir.cpp and irtoir-*.cpp

void panic( string msg );

reg_t IRType_to_reg_type( IRType type );

reg_t get_exp_type( Exp *exp );

inline int get_type_size(reg_t typ) {
  return Exp::reg_to_bits(typ);
}


Temp *mk_temp( string name, IRType ty );
Temp *mk_temp( reg_t type, vector<Stmt *> *stmts );
Temp *mk_temp( IRType ty, vector<Stmt *> *stmts );

Stmt *mk_assign_tmp(IRTemp tmp, Exp *rhs_e, IRSB *irbb,
		    vector<Stmt *> *irout );

Exp *translate_expr( IRExpr *expr, IRSB *irbb, vector<Stmt *> *irout );

string get_op_str(asm_program_t *prog, Instruction *inst );

int match_mux0x(vector<Stmt*> *ir, unsigned int i,
		Exp **cond, Exp **exp0,	Exp **expx, Exp **res);

extern bool use_eflags_thunks;
extern Exp * count_opnd;


//
// arch specific functions used in irtoir.cpp
//

// defined in irtoir-i386.cpp
vector<VarDecl *> i386_get_reg_decls();
Exp  *i386_translate_get( IRExpr *expr, IRSB *irbb, vector<Stmt *> *irout );
Stmt *i386_translate_put( IRStmt *stmt, IRSB *irbb, vector<Stmt *> *irout );
Exp  *i386_translate_ccall( IRExpr *expr, IRSB *irbb, vector<Stmt *> *irout );
Stmt *i386_translate_dirty( IRStmt *stmt, IRSB *irbb, vector<Stmt *> *irout );
void  i386_modify_flags( asm_program_t *prog, vine_block_t *block );

// defined in irtoir-arm.cpp
vector<VarDecl *> arm_get_reg_decls();
Exp  *arm_translate_get( IRExpr *expr, IRSB *irbb, vector<Stmt *> *irout );
Stmt *arm_translate_put( IRStmt *stmt, IRSB *irbb, vector<Stmt *> *irout );
Exp  *arm_translate_ccall( IRExpr *expr, IRSB *irbb, vector<Stmt *> *irout );
void  arm_modify_flags( asm_program_t *prog, vine_block_t *block );


#endif
