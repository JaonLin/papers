/* Copyright (C) BitBlaze, 2009-2010. 

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#warning "disasm-pp.h is deprecated"
#define _DISASM_PP_H
#ifndef _DISASM_PP_H
#define _DISASM_PP_H

#include <disasm.h>
#include <stdint.h>
#include <libiberty.h>
#include <irtoir.h>

#ifdef __cplusplus

#include <iostream>
#include <sstream>

using namespace std;

void ostream_i386_register(int regnum, ostream &out);

void
ostream_i386_mnemonic(Instruction *inst, ostream &out);

void ostream_i386_insn(Instruction *inst, ostream &out);

extern "C" {
#endif

  extern char* string_i386_blockinsn(vine_block_t *block);

#ifdef __cplusplus
}
#endif

#endif
