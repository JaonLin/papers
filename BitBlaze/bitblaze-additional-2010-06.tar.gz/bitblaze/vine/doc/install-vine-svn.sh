#!/bin/bash
# Instructions for installing Vine from SVN on Ubuntu 9.04 Linux 32-bit

# Commands that require root access are preceded with "sudo".

# The prerequisite packages are about 300MB of downloads, and require
# 1.1GB once installed; Vine itself requires about 500MB.

# Last tested 2010-06-13

# This script will build Vine in a "$HOME/ensighta" directory
cd ~
mkdir ensighta
cd ensighta

# Prerequisite: Valgrind VEX r1982
# Vine uses the VEX library that comes with Valgrind to interpret the
# semantics of instructions. (Note we don't even bother to fetch
# Valgrind itself). The code should work with a pretty broad ragne of
# VEX versions, though the VEX build process is a bit less stable.
# 1982 just happened to be the latest version when last updated these
# instructions.

# We need SVN to download VEX:
sudo apt-get install subversion
svn co -r1982 svn://svn.valgrind.org/vex/trunk vex

# Make VEX static library
(cd vex && make -f Makefile-gcc libvex.a)

# Other prerequisite packages:

# To generate configure and Makefiles:
sudo apt-get install automake

# For compiling C++ code:
sudo apt-get install g++

# For OCaml support:
sudo apt-get install ocaml ocaml-findlib camlidl \
                     libextlib-ocaml-dev ocaml-native-compilers

# Ocamlgraph >= 0.99c is required; luckily the version in Ubuntu 9.04
# is now new enough.
sudo apt-get install libocamlgraph-ocaml-dev

# For the BFD library:
sudo apt-get install binutils-dev

# For the SQLite database:
sudo apt-get install libsqlite3-dev sqlite3 libsqlite3-0 libsqlite3-ocaml-dev

# For building documentation:
sudo apt-get install texlive texlive-latex-extra transfig hevea

# Vine itself:
# Trunk:
svn co https://svn.ensighta.com/vine/trunk vine
(cd vine && ./autogen.sh)
(cd vine && ./configure --with-vex=$HOME/ensighta/vex)
(cd vine && make)
(cd vine/doc && make doc)

