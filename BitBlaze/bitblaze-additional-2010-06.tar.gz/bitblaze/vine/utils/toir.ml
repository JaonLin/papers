(*
  Copyright (C) BitBlaze, 2009-2010. 

#Permission to use, copy, modify, and/or distribute this software for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies.

#THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
*)
(**
 * Translate a binary to the IR. This handles idapro
 * databases and elf. It could be extended if there is enough desired
 *  to handle traces as well.
*)

open Vine_util;;
open Vine;;
open Vine_tovine;;

module D = Debug.Make(struct let name = Sys.argv.(0) and default=`Debug end)
open D

module List = ExtList.List 
let version = "$Id$";;

(* statistics *)
let total_x86 = ref 0L;;
let flag_nodemangle = ref false;;

type transaction = 
    TransRange of int64 * int64
  | TransFun of string
  | TransFunBySAddr of int64
  | TransFunByBAddr of int64
  | SetFile of exeType
  | DoAll 
;;

let normalize_info_name info = 
  let copy_str_from str i =
    String.sub str i (String.length str - i)
  in
  let method_name = 
    try 
      let regex = Str.regexp "::" in 
      let i = Str.search_forward regex info.name 0 in 
      let i = i + 2 in 
	String.sub info.name i (String.length info.name - i)
    with
	Not_found -> info.name 
  in
  let regex = Str.regexp "[@|(|)\\.]" in
  let strlist = Str.split regex method_name in 
    { info with name = List.hd strlist }
;;


let translate_files worklist = 
  let total_x86 = ref 0L in 
  let exe = (match worklist with
      [] -> failwith "no exe specified."
     | SetFile((Elf _) as a)::ys -> new exe a
     | SetFile((IdaDB _) as a)::ys -> new exe a
     | _ -> failwith ("must specify executable before ranges or"^
			" functions to translate")
  ) in
  let rec f ((exe:Vine_tovine.exe),(dl:decl list),(sl:stmt list list)) lst = 
    match lst with
	[] -> (dl,List.flatten (List.rev sl))
      | TransRange(i,j)::ys -> 
	  f (exe,dl,(exe#tr_range i j)::sl) ys
      | TransFun(name)::ys ->
	  let info = exe#get_funinfo_by_name name in 
	  let info = normalize_info_name info in 
	    f (exe,dl,[(exe#tr_function info)]::sl) ys
      | TransFunBySAddr(a)::ys ->
	  let info = exe#get_funinfo_by_start_address a in 
	  let info = normalize_info_name info in 
	    f (exe,dl,[(exe#tr_function info)]::sl) ys
      | TransFunByBAddr(a)::ys ->
	  let info = exe#get_funinfo_by_any_address a in 
	  let info = normalize_info_name info in 
	    f (exe,dl,[(exe#tr_function info)]::sl) ys
      | SetFile(typ)::ys ->
	  let () = total_x86 := Int64.add !total_x86 exe#x86translated  
	  in 
	  let exe = new exe typ in 
	    f (exe,(Vine_util.list_union dl (exe#globals)), sl) ys
      | DoAll::ys ->
	  let funs = exe#get_funinfos in
	  let funs =
	    if !flag_nodemangle then
	      (* Ignore bad demangled function names *)
	      List.filter (
		fun i -> not (String.contains i.name '=')
	      ) funs 
	    else funs
	  in
	  let rest = List.map (fun i -> TransFun(i.name)) funs in
	    f (exe,dl,sl) (rest @ ys)
  in
    (!total_x86, f (exe,exe#globals,[]) (List.tl worklist)) 
;;

let usage = "toir [options]* : translate to IR. Use ./toir -help for options." in
let infile = ref "" in
let infile_set = ref false in 
let flag_idadb_file = ref "" in 
let flag_use_thunks = ref false in 
let flag_use_calls = ref true in 
let flag_descope = ref true in 
let outfile = ref stdout in 
let flag_translate = ref [] in 
let trans_add item = flag_translate := item :: !flag_translate in
let arg_name s = infile := s; infile_set := true in
let print_version () = 
  Printf.printf "Version: %s\n%!" version
in
let start = ref "" in
let speclist =  [
  ("-elf", 
   Arg.String (fun s -> trans_add (SetFile(Elf(s)))),
   "Set input source to be elf"
  );
  ("-ida",
   Arg.Tuple [Arg.Set_string(flag_idadb_file);
	      Arg.Int (fun i -> 
			 trans_add (SetFile(IdaDB(!flag_idadb_file,i))));
	     ],
   ("<idadb> <file_id> Process executable with file id <fileid>"^
      " in IDA database <idadb>.")
  );
  ("-range",
   Arg.Tuple([Arg.String(fun s -> start := s);
	      Arg.String(fun e -> 
			   let si = Int64.of_string !start in
			   let ei = Int64.of_string e in 
			     trans_add (TransRange(si,ei)));
	     ]),
   " <start,end> translate range <start,end>"
  );
  ("-fun",
   Arg.String (fun s -> trans_add (TransFun(s))),
   " <function> translate function named <function>"
  );
  ("-funaddr",
   Arg.String (fun s -> let i = Int64.of_string s in 
		 trans_add (TransFunBySAddr(i))),
   "<addr> translate function with start address <addr>"
  );
  ("-funanyaddr",
   Arg.String (fun s -> let i = Int64.of_string s in 
		 trans_add (TransFunByBAddr(i))),
   "<addr> translate function with any address <addr> in the function"
  );
  ("-all",
   Arg.Unit (fun () -> trans_add DoAll),
   " translate everything in current file"
  );
  ("-o",
   Arg.String (fun s -> outfile := open_out s),
   " <outfile> set output file (default is stdout)"
  );
  ("-nodescope",
   Arg.Clear(flag_descope),
     " Do not perform descoping."
  );
  ("-thunks",
   Arg.Set (flag_use_thunks),
   " use eflags thunks when translating (default is not to)"
  );
  ("-nocall",
   Arg.Clear (flag_use_calls),
   " do not use call/ret when translating (default is to use them)"
  );
  ("-version",
   Arg.Unit (fun () -> print_version (); exit 0),
   " print version and exit"
  );
  ("-nodemangle",
   Arg.Set (flag_nodemangle),
   " Do not use demangled function names"
  );
] in
let () = Arg.parse speclist arg_name usage in 
let () = (match !flag_translate with
       [] -> Printf.printf "%s\n%!" usage; exit(0)
     | _ -> ()
  ) in 
let () = Libasmir.set_use_eflags_thunks !flag_use_thunks in 
let () = Libasmir.set_call_return_translation !flag_use_calls in 
let (totalx86,(dl,sl)) = translate_files (List.rev !flag_translate) in
let (dl,sl) = 
  if !flag_descope then Vine_alphavary.descope_program (dl,sl) 
  else (dl,sl) 
in 
  pp_program (output_string !outfile) (dl,sl);
  close_out !outfile
;;	
